# MoriPOS v3.2.1 — Staff Access UI, Staff Login, Public URL

## Thay đổi

1. **Nhân sự & quyền truy cập**: chỉ hiện danh sách ở Settings, bấm Thêm/Chỉnh sửa mở modal. Bố cục hai cột, chip nhỏ cho chi nhánh, checkbox 16px và trạng thái một dòng. Chủ hệ thống không thể bị khóa/đổi role qua UI.
2. **Staff Login**: `moriAuthStart(email)` kiểm tra `AccessControl` và `isActive` ngay trên backend trước khi phát sinh OTP. Email không được cấp quyền bị từ chối với thông báo rõ; tài khoản tạm khóa cũng bị từ chối. UI chỉ cho nhập mã ở bước 2 khi backend xác nhận gửi OTP thành công.
3. **Publish Site URL**: Settings → Publish · Đơn online có đường dẫn `/exec?view=shop`, nút sao chép, mở tab mới và QR. Publish · Booking có `/exec?view=shop&tab=booking`. URL lấy bằng `ScriptApp.getService().getUrl()`, chỉ trả cho Admin. Không lấy URL iframe Google, không lấy `/dev`, không gắn session/token vào link.

## File cần thay khi nâng cấp từ v3.2.0

- `Index.html` — giao diện/modal/login/link/QR.
- `Code.gs` — build + checksum + API `moriPublishLinks(token)`.
- `Security.gs` — kiểm tra quyền trước OTP.
- **Thêm** `MoriPreflight321.gs` — kiểm tra source. Có thể giữ `MoriPreflight320.gs` nhưng nên xóa file preflight cũ để tránh nhầm.

Các file khác không cần đổi. Không cần migrate hoặc khởi tạo lại workbook Google Sheets.

## Deploy

1. Backup Apps Script project trước khi thay.
2. Chép đúng cả 3 file sửa và thêm preflight vào **cùng project**. Giữ nguyên Script Properties và dữ liệu.
3. Save, chạy `moriFrontendCheck()` trong Apps Script Editor. Cần `build: 3.2.1`, `exactFileMatch: true`.
4. Chạy `moriPreflight321()` với owner; cần `ok:true`. Cài đặt Customer/Analytics hiện có không thay đổi.
5. **Deploy → Manage deployments → Edit → New version → Deploy** để giữ URL và Deployment ID đang dùng.
6. Đăng nhập owner, vào Cài đặt → Nhân sự & quyền truy cập để kiểm tra modal, thêm 1 nhân viên thử.
7. Trong một trình duyệt ẩn danh khác, nhập email chưa được cấp quyền: phải báo “Email này chưa được cấp quyền…”, không hiện OTP và không gửi email. Thử email đã được cấp quyền: nhận OTP rồi đăng nhập.
8. Vào Cài đặt → Publish · Đơn online và dùng nút **Mở thử** hoặc **Sao chép**. Mở link trên một trình duyệt ẩn danh để xác minh truy cập công khai.

### Quan trọng về Web App access

`?view=shop` là route trên **cùng Apps Script Web App**, không phải deployment mới. Nếu muốn người mua không có tài khoản Google truy cập được, cấu hình **Who has access = Anyone** trong deployment (nếu tổ chức cho phép). Quyền quản trị vẫn do backend `AccessControl` + OTP thực thi. Nếu deployment giới hạn domain hoặc tài khoản Google, khách ngoài phạm vi đó không mở được site dù URL đúng.

### QR

Nút QR chỉ tải ảnh sau khi người dùng bấm. Ảnh QR được tạo bởi `api.qrserver.com` từ **URL công khai**; không gửi dữ liệu khách, OTP hoặc token. Nếu không muốn phụ thuộc dịch vụ bên ngoài, sử dụng nút Sao chép và tạo QR bằng công cụ nội bộ.

## Rollback

Quay về deployment version v3.2.0 (Edit deployment, chọn previous version). Không xóa `POS_Master`, `POS_Customers` hoặc `POS_Dashboard`. Không có migration dữ liệu trong v3.2.1.

## Hạn chế kiểm thử

Các test chạy trong Node/VM mô phỏng, **chưa chạy end-to-end trên Apps Script production**. Kiểm tra quyền Web App access, gửi OTP bằng MailApp và mở URL từ môi trường Google thật trước khi dùng chính thức.
