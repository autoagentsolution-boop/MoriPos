/** Mori 3.2.0 C - incremental customer KPIs, never scan operational Bills on dashboard requests. */
var MORI_CUSTOMER_PENDING_=Object.create(null),MORI_CUSTOMER_QUEUE_SHARDS_=16;
function moriCustomerShard_(v){var h=0,s=String(v);for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;return h%MORI_CUSTOMER_QUEUE_SHARDS_;}
function moriCustomerQueueKey_(id){return 'CUSTOMER_QUEUE_'+moriCustomerShard_(id);}
function moriCustomerDayKey_(id){return 'CUSTOMER_DAY_'+moriCustomerShard_(id);}
function moriCustomerPropObject_(key){try{return JSON.parse(moriProp_(key)||'{}')||{};}catch(_){throw Error('Customer Analytics property damaged: '+key);}}
function moriCustomerWriteObject_(key,obj){var data=JSON.stringify(obj);moriEnsure_(data.length<8400,'Customer Analytics queue is full: '+key);moriSetProp_(key,data);}
function moriCustomerCaptureBill_(b){if(!moriCustomerReady_())return;MORI_CUSTOMER_PENDING_[String(b.id)]=String(b.version||1)+'@'+String(b.updatedAt||'');}
function moriCustomerFlushPending_(){var keys=Object.keys(MORI_CUSTOMER_PENDING_);if(!keys.length)return;var grouped={};keys.forEach(function(id){var key=moriCustomerQueueKey_(id);(grouped[key]||(grouped[key]={}))[id]=MORI_CUSTOMER_PENDING_[id];});Object.keys(grouped).forEach(function(k){var current=moriCustomerPropObject_(k);Object.assign(current,grouped[k]);moriCustomerWriteObject_(k,current);});MORI_CUSTOMER_PENDING_=Object.create(null);}
function moriCustomerQueued_(max){var out=[];for(var i=0;i<16&&out.length<max;i++){var key='CUSTOMER_QUEUE_'+i,obj=moriCustomerPropObject_(key);Object.keys(obj).slice(0,max-out.length).forEach(function(id){out.push({id:id,version:obj[id],key:key});});}return out;}
function moriCustomerMarkDays_(ids){var groups={};ids.forEach(function(id){if(!id)return;var key=moriCustomerDayKey_(id);(groups[key]||(groups[key]={}))[id]=1;});Object.keys(groups).forEach(function(k){var obj=moriCustomerPropObject_(k);Object.assign(obj,groups[k]);moriCustomerWriteObject_(k,obj);});}
function moriCustomerDirtyDays_(max){var out=[];for(var i=0;i<16&&out.length<max;i++){var key='CUSTOMER_DAY_'+i,obj=moriCustomerPropObject_(key);Object.keys(obj).slice(0,max-out.length).forEach(function(id){out.push({id:id,key:key});});}return out;}
function moriCustomerAckDays_(days){var groups={};days.forEach(function(x){(groups[x.key]||(groups[x.key]=[])).push(x.id);});Object.keys(groups).forEach(function(k){var o=moriCustomerPropObject_(k);groups[k].forEach(function(id){delete o[id];});moriCustomerWriteObject_(k,o);});}
function moriCustomerAckQueue_(entries){var groups={};entries.forEach(function(e){(groups[e.key]||(groups[e.key]=[])).push(e);});Object.keys(groups).forEach(function(k){var o=moriCustomerPropObject_(k);groups[k].forEach(function(e){if(o[e.id]===e.version)delete o[e.id];});moriCustomerWriteObject_(k,o);});}
function moriCustomerOrderKey_(b){if(Number(b.customerId)>0)return 'member|'+Number(b.customerId);return b.guestIdentityId?String(b.guestIdentityId):'';}
function moriCustomerDay_(b){return moriDate_(new Date(b.paidAt||b.createdAt||moriNow_()));}
function moriCustomerProcessBill_(b){
 var key=moriCustomerOrderKey_(b),id='BILL|'+String(b.id),old=moriFind_('CustomerOrderLinks',id),date=moriCustomerDay_(b);
 if(!key&&!old)return {linked:false};
 var isPaid=b.status!=='CANCELLED'&&(b.paymentStatus==='CONFIRMED'||b.status==='PAID');
 var doc=old?moriDeep_(old):{id:id,billId:b.id};
 Object.assign(doc,{billId:b.id,branchId:Number(b.branchId),email:key,status:b.status||'OPEN',orderStatus:b.orderStatus||'',day:date,
  customerId:Number(b.customerId)||0,identityId:b.guestIdentityId||'',no:b.no||'',channel:b.channel||'OFFLINE',total:Math.max(0,Number(b.finalTotal)||0),
  items:(b.items||[]).slice(0,50).map(function(x){return {name:String(x.name||'').slice(0,120),qty:Number(x.qty)||0};}),
  paid:isPaid,sourceVersion:Number(b.version)||1,active:!!key});
 if(old)moriPut_('CustomerOrderLinks',doc,old.version);else moriInsert_('CustomerOrderLinks',doc);
 if(old&&(String(old.branchId)!==String(doc.branchId)||old.day!==doc.day)){
  var previousId=String(old.branchId)+'|'+old.day+'|'+String(b.id),prior=moriFind_('CustomerDayIndex',previousId);
  if(prior){prior.active=false;moriPut_('CustomerDayIndex',prior,prior.version);}
 }
 var dayId=String(doc.branchId)+'|'+doc.day+'|'+String(b.id),oldIndex=moriFind_('CustomerDayIndex',dayId);
 var index={id:dayId,branchId:doc.branchId,email:doc.day,day:doc.day,billId:b.id,identityId:doc.identityId,customerId:doc.customerId,paid:doc.paid,total:doc.total,active:doc.active,status:doc.status};
 if(oldIndex)moriPut_('CustomerDayIndex',Object.assign(oldIndex,index),oldIndex.version);else moriInsert_('CustomerDayIndex',index);
 moriCustomerMarkDays_([old&&old.branchId+'|'+old.day,doc.branchId+'|'+doc.day]);
 if(isPaid&&key){
  var ref=key.indexOf('member|')===0?moriFind_('Customers',Number(key.slice(7))):moriFind_('GuestIdentities',key);
  if(ref&&(!ref.firstPaidDay||date<ref.firstPaidDay)){var oldFirst=ref.firstPaidDay;ref.firstPaidDay=date;moriPut_(key.indexOf('member|')===0?'Customers':'GuestIdentities',ref,ref.version);if(oldFirst)moriCustomerMarkDays_([doc.branchId+'|'+oldFirst]);}
 }
 return {linked:!!key,paid:isPaid};
}
/** Membership upgrade may reclassify past verified guest orders, never unverified orders. */
function moriCustomerMarkIdentityDays_(identityId){
 var link=moriFind_('CustomerIdentityLinks',identityId),memberId=link&&link.customerId;
 var keys=[identityId];if(memberId)keys.push('member|'+Number(memberId));
 var sh=moriSheet_('CustomerOrderLinks'),last=sh.getLastRow(),days=[];
 if(last>1)keys.forEach(function(key){sh.getRange(2,3,last-1,1).createTextFinder(key).matchEntireCell(true).matchCase(true).findAll().forEach(function(cell){try{var doc=JSON.parse(sh.getRange(cell.getRow(),8).getValue());days.push(doc.branchId+'|'+doc.day);}catch(_){}});});
 moriCustomerMarkDays_(days);
}
function moriCustomerRowsDay_(branchId,day){
 // The day index is maintained incrementally. A 7-day dashboard never scans raw Bills
 // or the full CustomerOrderLinks ledger, and one dirty day reads only matching rows.
 var sh=moriSheet_('CustomerDayIndex'),last=sh.getLastRow();if(last<2)return [];
 var positions=sh.getRange(2,3,last-1,1).createTextFinder(day).matchCase(true).matchEntireCell(true).findAll().map(function(c){return c.getRow();});
 return positions.map(function(row){try{return JSON.parse(sh.getRange(row,8).getValue());}catch(_){return null;}})
  .filter(function(x){return x&&x.active&&Number(x.branchId)===Number(branchId)&&x.day===day&&x.paid===true;});
}
function moriCustomerOwner_(doc){
 if(Number(doc.customerId)>0)return {key:'M|'+doc.customerId,member:true,id:Number(doc.customerId),identityId:doc.identityId||''};
 if(doc.identityId){var link=moriFind_('CustomerIdentityLinks',doc.identityId);if(link&&link.active!==false)return {key:'M|'+link.customerId,member:true,id:Number(link.customerId),identityId:doc.identityId};
  return {key:'G|'+doc.identityId,member:false,id:doc.identityId,identityId:doc.identityId};}
 return null;
}
function moriCustomerFirstPaid_(owner){
 var a=owner.identityId?moriFind_('GuestIdentities',owner.identityId):null,b=owner.member?moriFind_('Customers',owner.id):null;
 return [a&&a.firstPaidDay,b&&b.firstPaidDay].filter(Boolean).sort()[0]||'';
}
function moriCustomerRebuildDay_(id){
 var parts=String(id).split('|'),branch=Number(parts[0]),day=parts[1];moriEnsure_(branch>0&&/^\d{4}-\d{2}-\d{2}$/.test(day),'Customer day invalid');
 var src=moriCustomerRowsDay_(branch,day),results={GUEST:{orders:0,revenue:0,unique:0,newCustomers:0,returningCustomers:0},MEMBER:{orders:0,revenue:0,unique:0,newCustomers:0,returningCustomers:0}},groups={};
 src.forEach(function(doc){var owner=moriCustomerOwner_(doc);if(!owner)return;var key=owner.member?'MEMBER':'GUEST',r=results[key];r.orders++;r.revenue+=Number(doc.total)||0;groups[key+'|'+owner.key]=owner;});
 Object.keys(groups).forEach(function(k){var owner=groups[k],key=owner.member?'MEMBER':'GUEST',first=moriCustomerFirstPaid_(owner),r=results[key];r.unique++;if(first===day)r.newCustomers++;else if(first&&first<day)r.returningCustomers++;});
 ['GUEST','MEMBER'].forEach(function(key){var id=String(branch)+'|'+day+'|'+key,doc={id:id,branchId:branch,email:day,day:day,status:'ACTIVE',type:key,orders:results[key].orders,revenue:results[key].revenue,uniqueCustomers:results[key].unique,newCustomers:results[key].newCustomers,returningCustomers:results[key].returningCustomers},old=moriFind_('CustomerDaily',id);if(old)moriPut_('CustomerDaily',doc,old.version);else moriInsert_('CustomerDaily',doc);});
 return {day:day,branchId:branch,orders:src.length};
}
function moriCustomerBackfillBatch_(limit){
 var offset=Number(moriProp_('CUSTOMER_BACKFILL_CURSOR')||2),sh=moriSheet_('Bills'),last=sh.getLastRow();
 if(offset>last){moriSetProp_('CUSTOMER_BACKFILL_COMPLETE','1');return {read:0,complete:true};}
 var n=Math.min(limit,last-offset+1),docs=sh.getRange(offset,8,n,1).getValues();
 docs.forEach(function(row){if(!row[0])return;var doc=JSON.parse(row[0]);if(moriCustomerOrderKey_(doc))moriCustomerProcessBill_(doc);});
 moriSetProp_('CUSTOMER_BACKFILL_CURSOR',offset+n);if(offset+n>last)moriSetProp_('CUSTOMER_BACKFILL_COMPLETE','1');
 return {read:n,complete:offset+n>last};
}
function moriCustomerSyncCore_(){
 moriEnsure_(moriCustomerReady_(),'Customer storage chưa cài');
 return moriLock_(function(){
  var items=moriCustomerQueued_(30),done=0;
  items.forEach(function(e){var bill=moriFind_('Bills',e.id);if(bill){moriCustomerProcessBill_(bill);done++;}moriCustomerAckQueue_([e]);});
  var backfill=moriProp_('CUSTOMER_BACKFILL_COMPLETE')==='1'?{complete:true,read:0}:moriCustomerBackfillBatch_(120);
  var dirty=moriCustomerDirtyDays_(6);dirty.forEach(function(day){moriCustomerRebuildDay_(day.id);moriCustomerAckDays_([day]);});
  moriSetProp_('CUSTOMER_LAST_SYNC',moriNow_());
  if(!moriCustomerQueued_(1).length&&!moriCustomerDirtyDays_(1).length&&backfill.complete){moriSetProp_('CUSTOMER_REPAIR_REQUIRED','0');moriSetProp_('CUSTOMER_INITIAL_READY','1');}
  return {ok:true,processed:done,backfill:backfill,daysRebuilt:dirty.length,pending:moriCustomerQueued_(1000).length,dirtyDays:moriCustomerDirtyDays_(1000).length};
 });
}
function moriCustomerCanArchive_(){return moriCustomerReady_()&&moriProp_('CUSTOMER_BACKFILL_COMPLETE')==='1'&&moriProp_('CUSTOMER_REPAIR_REQUIRED')!=='1'&&!moriCustomerQueued_(1).length&&!moriCustomerDirtyDays_(1).length;}
function moriCustomerAnalyticsWorker_(){var owner=moriProp_('OWNER_EMAIL'),effective=Session.getEffectiveUser().getEmail().toLowerCase();moriEnsure_(owner&&owner.toLowerCase()===effective,'Chỉ Owner chạy đồng bộ Customer Analytics');return moriCustomerSyncCore_();}
function moriCustomerSyncNow(){moriEditorOnly_();return moriCustomerSyncCore_();}
/** Owner-only replay. Use after a queue overflow or interrupted import; already materialized bills are upserted idempotently. */
function moriCustomerRepairStart(){moriEditorOnly_();moriEnsure_(moriCustomerReady_(),'POS_Customers chưa được khởi tạo');return moriLock_(function(){
 moriSetProp_('CUSTOMER_INITIAL_READY','0');moriSetProp_('CUSTOMER_REPAIR_REQUIRED','1');
 moriSetProp_('CUSTOMER_BACKFILL_CURSOR','2');moriSetProp_('CUSTOMER_BACKFILL_COMPLETE','0');
 return {ok:true,message:'Đã lên lịch đối soát lại Bills. Gọi moriCustomerSyncNow hoặc để trigger chạy mỗi 5 phút.'};
});}
function moriCustomerStatus(){moriEditorOnly_();return {installed:moriCustomerReady_(),initialReady:moriProp_('CUSTOMER_INITIAL_READY')==='1',backfillComplete:moriProp_('CUSTOMER_BACKFILL_COMPLETE')==='1',backfillCursor:Number(moriProp_('CUSTOMER_BACKFILL_CURSOR')||2),lastSync:moriProp_('CUSTOMER_LAST_SYNC')||'',pending:moriCustomerQueued_(1000).length,dirtyDays:moriCustomerDirtyDays_(1000).length,repairRequired:moriProp_('CUSTOMER_REPAIR_REQUIRED')==='1'};}
function moriCustomerAnalyticsQuery(token,request){
 var actor=moriActor_(token),q=request||{},branch=Number(q.branchId),start=moriForecastDay_(q.startDate),end=moriForecastDay_(q.endDate);
 moriRequire_(actor,['ADMIN','MANAGER'],branch);moriEnsure_(moriCustomerReady_(),'Chưa cài Customer Analytics');
 var days=(Date.parse(end)-Date.parse(start))/86400000+1;moriEnsure_(days>=1&&days<=366,'Kỳ báo cáo tối đa 366 ngày');
 moriEnsure_(moriProp_('CUSTOMER_INITIAL_READY')==='1'&&moriProp_('CUSTOMER_BACKFILL_COMPLETE')==='1'&&moriProp_('CUSTOMER_REPAIR_REQUIRED')!=='1','Customer Analytics đang đồng bộ.');
 var sh=moriSheet_('CustomerDaily'),last=sh.getLastRow(),rows=last<2?[]:sh.getRange(2,8,last-1,1).getValues().map(function(x){try{return JSON.parse(x[0]);}catch(_){return null;}}).filter(function(x){return x&&Number(x.branchId)===branch&&x.day>=start&&x.day<=end;});
 var summary={guestOrders:0,memberOrders:0,guestRevenue:0,memberRevenue:0,newCustomers:0,returningCustomers:0};
 rows.forEach(function(x){var key=x.type==='MEMBER'?'member':'guest';summary[key+'Orders']+=Number(x.orders)||0;summary[key+'Revenue']+=Number(x.revenue)||0;summary.newCustomers+=Number(x.newCustomers)||0;summary.returningCustomers+=Number(x.returningCustomers)||0;});
 return {ok:true,branchId:branch,from:start,to:end,summary:summary,rows:rows.sort(function(a,b){return a.day.localeCompare(b.day);}),materializedAt:moriProp_('CUSTOMER_LAST_SYNC')||null,pendingChanges:moriCustomerQueued_(1).length>0||moriCustomerDirtyDays_(1).length>0,scope:'VERIFIED_CUSTOMERS_ONLY'};
}
