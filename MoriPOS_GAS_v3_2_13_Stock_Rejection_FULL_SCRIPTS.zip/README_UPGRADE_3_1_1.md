# Mori POS 3.1.1 — Forecast + UI Full Source

## Upgrade (from 3.1.0)

1. **Backup** the current Apps Script project and backing Google Sheets. This archive is a complete source tree; import all root `.gs`, `Index.html`, `appsscript.json` into the existing project (keeping current Script Properties). Do not import `tests/` / `docs/` / `Original_UI_Offline.html`.
2. **Do not rerun** `moriSetup()`, `moriInstallOnce()` or any seed functions. Existing `ForecastPlans` is reused; this release adds no spreadsheet columns.
3. Run `moriPreflight311()` and `moriFrontendCheck()` in Apps Script Editor. Expected `moriPreflight311().ok: true`, `exactFileMatch: true`, build `3.1.1`. If using old `Code.gs`, the checksum will be wrong, so update Code.gs and Index.html **together**.
4. Deploy > Manage deployments > Edit (pencil) > **New version** > Deploy. Keep existing access / execute-as. Open **/exec**, hard refresh, sign in; test sales, inventory, Forecast, print preview and user menu.
5. No automatic database migration needed. If you have not installed Forecast previously, run `moriUpgradePlanning()` **once** from the editor as Owner.

## Updated modules
- Account menu: icon, check mark and label on one line; no wrapped sign-out icon.
- A4 browser print preview: narrow receipt centered horizontally; 58/80 mm receipts maintain thermal width. PDF export is separate and unchanged.
- Forecast: fixed amount vs markup/margin/growth labels clarified; 3 scenario help embedded; no recommendation when all scenario quantities/prices identical.
- Forecast: server-calculated rent/other store overhead (equally allocated among active branches), branch rent/other, monthly salary forecast, inclusive-date proration. Expense breakdown available for Admin and Manager without employee-level salary disclosure.
- Forecast: confirmed stock purchase cash spending shown **separately**, not deducted again in profit because sold-material BOM costs are already included in COGS.
- Employee admin form stores `salaryBase` (monthly expected salary). If shift/hourly rate is set but no monthly estimate exists, Forecast warns and excludes that payroll item until the estimate is entered.

## Scope / caveats
- Main retail overhead allocation is equal per active branch (not a weighted cost-center split).
- Stock purchase cash summary reads 2,000 recent stock-in receipts; a warning appears if history exceeds this scan. Confirmed receipts are assigned by confirmation date.
- Forecast profit is **selected-item contribution after branch-level operating costs**, not a full audited company P&L. If you select just one product, overhead remains branch-level: use all relevant products for whole-branch profit.
- Monthly salaries are approximate, not actual payroll, and salaries for any missing `salaryBase` are not included. Note the report warnings.
- Client-side calculations are estimates; no Google Apps Script production runtime has been verified here.

See `FORECAST_HUONG_DAN_SU_DUNG.md` for a step-by-step Vietnamese example.
