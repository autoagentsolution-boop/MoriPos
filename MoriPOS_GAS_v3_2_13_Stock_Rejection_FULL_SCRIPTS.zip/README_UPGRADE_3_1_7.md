# MoriPOS 3.1.7 — Forecast UI Cleanup

## Phạm vi

Bản này chỉ chỉnh giao diện Forecast dựa trên v3.1.6 (POS_Dashboard). **Không sửa business logic, công thức tính, API, database, Google Sheets hoặc trigger.**

### Đã tinh gọn
- Bỏ subtitle dưới tiêu đề Forecast và dòng trạng thái kỹ thuật (cache, thời gian máy chủ, thời điểm tổng hợp Analytics).
- Bỏ các dòng tiền màu xanh lặp lại ngay dưới input; số tiền đã định dạng dấu chấm vẫn hiển thị trong input.
- Rút ngắn ví dụ/hint, font 11 px, nhạt hơn và không đậm.
- Giữ nút **Gợi ý số lượng 80% / 100% / 120%**; bỏ đoạn giải thích dài phía dưới. Tooltip vẫn có giải thích.
- Bỏ các đoạn mô tả và ghi chú dài ở vùng tồn nguyên liệu và cuối trang.
- Bỏ dòng tóm tắt tiền nhập kho dư thừa trong vùng nguyên liệu; **bảng lượng cần nhập, đơn giá và tiền cần mua vẫn giữ nguyên**.
- Giữ toàn bộ kịch bản, các control nhập liệu, cập nhật từ doanh số, lưu kế hoạch và chức năng Analytics.

## Triển khai nhanh từ v3.1.6

### Chỉ cập nhật 2 file
1. Sao lưu project Apps Script hiện tại và 2 file `Index.html`, `Code.gs`.
2. Từ gói PATCH, thay **toàn bộ nội dung** của `Index.html` và `Code.gs` trong cùng project.
3. Lưu, chọn `moriFrontendCheck()` và chạy ở Apps Script Editor. Kiểm tra `build: "3.1.7"`, `exactFileMatch: true`, `ok: true`.
4. `Deploy` → `Manage deployments` → chọn deployment đang dùng → `Edit` → `New version` → `Deploy`.
5. Mở URL `/exec`, reload, kiểm tra Forecast trên desktop và điện thoại.

**Vì sao phải đổi `Code.gs`?** MoriPOS kiểm tra SHA-256 của `Index.html` so với hash được lưu trong `Code.gs`. Nếu chỉ thay `Index.html`, `moriFrontendCheck()` sẽ báo `exactFileMatch: false`. Thay cả hai file đảm bảo metadata build/hash nhất quán.

### Triển khai full source
Bộ FULL chứa toàn bộ mã nguồn v3.1.6, với chỉ `Index.html` và `Code.gs` thay đổi về code vận hành. **Không chạy setup, install, migration hay backfill lại** cho bản UI này.

`moriPreflight316()` vẫn là kiểm tra các API/backend giữ nguyên của v3.1.6; để xác nhận frontend version 3.1.7 hãy dùng `moriFrontendCheck()`.

## Kiểm tra nhanh
- Forecast mở được, không còn subtitle và dòng server timing/cache ở góc phải.
- Ô nhập mục tiêu và phát sinh không còn dòng tiền trùng lặp phía dưới.
- Nút gợi ý số lượng 80/100/120 vẫn cập nhật ba cột.
- Nhập tiền ví dụ `3000000` → input `3.000.000` và kịch bản tính đúng như v3.1.6.
- Bảng nguyên liệu vẫn có cột `Cần nhập thêm` và `Tiền cần mua`.
- POS login, bán hàng, in bill, audit và dashboard hoạt động như trước.

## QA
- Test Node.js trên fixture: `node tests/run-tests.js`.
- Google production: chưa kiểm chứng; cần deploy staging trước nếu đang sử dụng cho bán hàng thật.
