# Kiểm thử Mori POS 3.1.0

Ngày: 05/11/2026. **7 bộ kiểm thử, 87 nhóm báo PASS** bằng Node VM, DOM/RPC và Sheets/Cache/Lock giả lập. Không có giao dịch hoặc thay đổi dữ liệu trên tài khoản Google thật.

## Phạm vi đã kiểm tra

| Bộ kiểm thử | Nội dung chính |
| --- | --- |
| startup.test.js | Cú pháp toàn bộ `.gs` và script HTML; loader RPC/Base64/SHA-256; phiên đăng nhập; chặn storage; trang công khai; lỗi RPC/runtime hiển thị rõ |
| business.test.js | Giá bill riêng, giữ hàng online, ngăn bán vượt tồn, giao hàng/thu tiền, tip, version conflict, nhập kho và thanh toán lặp |
| performance.test.js | 18 nhóm của r3: 1 RPC xác thực/bootstrap, 1 RPC thanh toán, đọc tồn mới, kiểm tra quyền sau khóa, phục hồi lỗi ghi một phần, khóa/flush, chống trùng, lịch sử tải nền và phân quyền |
| frontend.test.js | 8 nhóm r3: không chờ lịch sử để bán, không reload sau thanh toán, chặn click đôi, phản hồi cũ không ghi đè, giữ request khi thử lại, logout |
| planning.test.js | 12 nhóm: 1 kg → 1.000 g, giá vốn bình quân, nhiều nguyên liệu, combo/dịch vụ lồng nhau, hao hụt, trừ tồn một lần, công thức lợi nhuận, kỳ đã kết thúc, số bán vượt kế hoạch, nguyên liệu dùng chung, ngày Việt Nam, giảm giá/tip, quyền và lưu kế hoạch |
| audit.test.js | 7 nhóm: giá trị trước/sau, nhóm ghi một lần, một lần append nhiều nhóm, kiểm tra quyền/đầu vào, audit chốt giá, nhóm chờ đi cùng thanh toán, lỗi ghi bill và diễn giải JSON cũ |
| planning-ui.test.js | 7 nhóm: tải Forecast khi mở trang, tính cục bộ, lưu plan/defaults, đổi kỳ, đồng nhất công thức client/server, thao tác sửa giá bằng ô nhập/Enter, gửi nhóm audit nền hoặc cùng checkout, retry và phản hồi sau logout |

## Một số kết quả số học

- Nhập 1 kg thịt giá 100.000đ vào nguyên liệu g → tồn tăng 1.000 g, giá vốn 100đ/g; xác nhận phiếu lại không tăng tồn thêm.
- Combo gồm 200 g thịt + 100 g rau (rau lưu theo kg), thêm 1.000đ chế biến → giá vốn 23.000đ/phần khi thịt 100đ/g và rau 20.000đ/kg.
- Bán 2 Combo A và 1 Combo B trong fixture → cộng chung nhu cầu nguyên liệu rồi trừ tồn; không trừ tồn riêng của combo.
- Giá vốn 23.000đ, mục tiêu lãi trên chi phí 20% → doanh thu cần 27.600đ; biên lợi nhuận 20% → 28.750đ, gợi ý giá làm tròn lên 28.800đ.
- Bill có giảm giá và tip → doanh thu Forecast phân bổ giảm giá theo dòng, không cộng tip; giữ giá vốn đã chốt trên bill.
- Kỳ kết thúc và sản lượng kế hoạch còn thiếu → không ghi nhận phần chưa bán thành doanh thu thực tế.
- Nhóm audit đã ghi nhưng phản hồi bị mất → thử lại không ghi trùng; bản ghi thanh toán được giữ riêng.

## Chạy lại

Từ thư mục chứa source, dùng Node.js hiện đại (đã chạy Node 24):

```bash
node tests/run-tests.js
```

Có thể chạy riêng từng file test. So sánh số lượt dịch vụ với bộ source r2 gốc nếu còn giữ:

```bash
MORI_BASELINE_DIR=/duong-dan/source-r2 node tests/performance.test.js
```

## Chưa được xác minh trên môi trường thật

Chưa deploy Apps Script, chưa đo độ trễ đầu-cuối, chưa kiểm tra gửi OTP email thật hoặc nhiều thiết bị ghi đồng thời. Môi trường hiện tại không chạy được Chromium do giới hạn socket, nên **không có kết quả kiểm tra trình duyệt thật hoặc ảnh chụp giao diện để báo PASS**. DOM/RPC fixture kiểm tra mã và chuỗi sự kiện, không xác nhận bố cục hiển thị thực tế.

Sau deploy, thực hiện `QC_CHECKLIST.md` trên dữ liệu kiểm thử riêng và đối chiếu thời gian bằng `window.MoriPerformance`. Dự báo chưa đọc dữ liệu archive hoặc mô hình hóa mùa vụ, giá mua tương lai, thuế/phí không khai báo.
