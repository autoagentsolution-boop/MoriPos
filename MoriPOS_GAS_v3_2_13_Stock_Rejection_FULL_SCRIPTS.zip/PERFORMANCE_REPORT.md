# Hiệu năng — Mori POS 3.1.0

Giữ các tối ưu r3: xác minh OTP + core bootstrap trong một lượt, lịch sử tải sau, snapshot mới trong mỗi execution ghi, tái sử dụng handle Sheets, ghi nhóm dòng liền nhau, tìm request ID trực tiếp, trả bill/tồn thay đổi trong cùng phản hồi thanh toán.

## Số đếm trong mô phỏng

Fixture: 3.000 bill PAID, 80 mặt hàng, 2 chi nhánh; thanh toán 5 mặt hàng nằm ở các dòng liền nhau. Chưa có nhóm sửa bill đang chờ hoặc đơn online giữ tồn. Số đếm 3.1.0 giữ bằng r3; đây không phải số giây thực tế.

| Chỉ số | r2 | 3.1.0 |
| --- | ---: | ---: |
| RPC từ OTP đến màn hình bán hàng | 3 | 1 |
| Mở spreadsheet khi đăng nhập, cache trống | 15 | 2 |
| getValues khi đăng nhập, cache trống | 14 | 8 |
| Dòng đọc khi đăng nhập, cache trống | 1.711 | 89 |
| RPC đến phản hồi thanh toán | 2 | 1 |
| Mở spreadsheet khi thanh toán | 11 | 4 |
| getValues khi thanh toán | 19 | 4 |
| Dòng đọc khi thanh toán | 5.003 | 83 |
| setValues khi thanh toán | 8 | 4 |

Không gồm RPC tải mã giao diện, gửi email OTP hoặc tải lịch sử nền. Mở phiên bằng token với cache sẵn đọc AccessControl hiện tại: 1 getValues, 1 dòng. Cache không thay thế kiểm tra quyền hoặc tồn mới khi chốt.

## Chi phí của module mới

- Không đọc bảng ForecastPlans hay tính dự báo khi đăng nhập/thanh toán.
- Mở Forecast: đọc Items, bảng Bills đang hoạt động và danh sách kế hoạch. Tự làm mới mỗi phút chỉ khi đang mở trang, không bận ghi và không đổi kỳ chưa cập nhật. Dữ liệu lớn vẫn có thể khiến lượt này chậm; chưa có mô hình tổng hợp ngày hoặc đọc archive.
- Chỉnh số lượng/giá/chi phí kịch bản: tính ngay trong trình duyệt, không gọi Sheets theo từng ô.
- Nhật ký sửa bill: gom tối đa 30 thay đổi/nhóm, gửi sau khoảng 1,8 giây không có chỉnh sửa mới; tối đa 10 nhóm trong một RPC và một lần append Sheets cho các nhóm mới.
- Nếu còn nhóm chờ khi thanh toán, gửi trong cùng checkout RPC. Có thêm một lần append Audit cho các nhóm chưa ghi, ngoài bản ghi thanh toán. Nhóm đã ghi nền được kiểm tra chống trùng.
- Giá vốn/nhu cầu nguyên liệu dùng danh mục đã đọc một lần trong request; công thức được tính trong bộ nhớ.

Chưa xác nhận đăng nhập/thanh toán dưới 10 giây trên project Google thật. RPC/cold start, kích thước dữ liệu, lịch sử và tranh chấp khóa vẫn ảnh hưởng thời gian. Dùng `window.MoriPerformance` theo quick start để đo `clientMs`, `serverMs`, `lockWaitMs` thực tế.
