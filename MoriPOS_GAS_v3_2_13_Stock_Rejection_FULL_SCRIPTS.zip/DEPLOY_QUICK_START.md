# MoriPOS v3.2.13 — Full scripts

Thêm **Từ chối nhập hàng** cho phiếu chờ duyệt: lý do bắt buộc, lưu lịch sử, không cộng tồn kho/giá vốn. Admin/Quản lý xử lý theo quyền chi nhánh; nhân viên xem được lý do của phiếu mình gửi.

Từ v3.2.12: thay 6 file Index.html, Code.gs, Inventory.gs, Operations.gs, AuditFormat.gs, Archive.gs. Không chạy lại Setup hoặc migration.

Chạy moriFrontendCheck(): build 3.2.13, ok: true, exactFileMatch: true; sau đó Deploy → Manage deployments → Edit → New version → Deploy.

Hướng dẫn chi tiết: README_UPGRADE_3_2_13.md. Không chép tests/docs/Markdown/Original_UI_Offline.html vào Apps Script. 24 suites / 202 nhóm kiểm tra mô phỏng đạt; chưa triển khai Web App. Chưa thay đổi sang cơ chế lưu nền/cache mới hoặc xác nhận mức lưu 3 giây.
