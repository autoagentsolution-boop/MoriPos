/** Owner-only preflight: verifies code integrity without modifying operational data. */
function moriPreflight322(){
 moriEditorOnly_();
 var checks={
  publishLinks:typeof moriPublishLinks==='function',staffOTP:typeof moriAuthStart==='function',staffList:typeof moriStaffList==='function',staffSave:typeof moriStaffSave==='function',
  customerInstall:typeof moriCustomerInstall==='function',guestOTP:typeof moriCustomerAuthStart==='function'&&typeof moriCustomerAuthVerify==='function',
  guestHistory:typeof moriCustomerOrders==='function',orderClaim:typeof moriCustomerClaimMyOrder==='function',
  memberRegistration:typeof moriCustomerMemberSave==='function',customerWorker:typeof moriCustomerAnalyticsWorker_==='function',
  customerDashboard:typeof moriCustomerAnalyticsQuery==='function',
  analyticsFoundation:typeof moriAnalyticsQuery==='function'
 };
 var source=moriFrontendCheck(),missing=Object.keys(checks).filter(function(x){return !checks[x];});
 return {ok:missing.length===0&&source.ok&&source.exactFileMatch&&source.build==='3.2.2',version:'3.2.2',functionChecks:checks,missing:missing,
  frontend:{ok:source.ok,exactFileMatch:source.exactFileMatch,build:source.build},
  installation:{analyticsDashboard:!!moriProp_('FILE_DASHBOARD'),customersReady:moriCustomerReady_(),customerFilePresent:!!moriProp_('FILE_CUSTOMERS'),customerBackfillComplete:moriProp_('CUSTOMER_BACKFILL_COMPLETE')==='1'},
  nextStep:moriCustomerReady_()?'Chạy moriCustomerSyncNow() và kiểm tra moriCustomerStatus()':'Chạy moriCustomerInstall() một lần từ Apps Script Editor'};
}
