/** Durable, idempotent batches of confirmed browser edits; not a replacement for server commit audit. */
function moriRecordBillEdits_(actor,batches,context){
 moriEnsure_(Array.isArray(batches)&&batches.length<=10,'Tối đa 10 nhóm nhật ký mỗi lần ghi');
 var out=[],fresh=[],labels={'item.add':'Thêm mặt hàng','item.remove':'Xóa mặt hàng','item.qty':'Số lượng','item.price':'Đơn giá','item.employee':'Nhân viên thực hiện',customer:'Khách hàng',resource:'Bàn / ghế',discount:'Giảm giá (%)',discountFixed:'Giảm giá cố định',tipAmount:'Tiền tip',method:'Thanh toán',billEmployee:'Nhân viên phụ trách',tipEmployees:'Nhân viên nhận tip',branch:'Chi nhánh'};
 batches.forEach(function(b){
  moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],Number(b.branchId));
  moriEnsure_(/^[A-Za-z0-9_-]{12,100}$/.test(String(b.id))&&/^[A-Za-z0-9_-]{12,128}$/.test(String(b.clientRequestId)),'Mã nhóm nhật ký không hợp lệ');
  if(context)moriEnsure_(String(b.clientRequestId)===String(context.clientRequestId)&&Number(b.branchId)===Number(context.branchId),'Nhật ký không thuộc bill');
  var id='BE:'+b.clientRequestId+':'+b.id,old=moriFind_('Audit',id);
  if(old){moriEnsure_(old.email===actor.email&&Number(old.branchId)===Number(b.branchId),'Nhóm nhật ký không thuộc tài khoản');out.push(old);return;}
  moriEnsure_(Array.isArray(b.events)&&b.events.length>0&&b.events.length<=30,'Nhóm nhật ký phải có 1–30 thay đổi');
  var details=b.events.map(function(e){
   moriEnsure_(Object.prototype.hasOwnProperty.call(labels,e.field),'Trường nhật ký không hợp lệ');
   function scalar(v){moriEnsure_(v===null||v===undefined||['string','number','boolean'].indexOf(typeof v)>=0,'Giá trị nhật ký không hợp lệ');if(typeof v==='number')moriEnsure_(Number.isFinite(v),'Số trong nhật ký không hợp lệ');return typeof v==='string'?v.slice(0,300):v;}
   var key=e.field==='item.price'?'unitPrice':e.field==='discountFixed'?'discountFixed':e.field;
   return {label:labels[e.field]+(e.itemName?' · '+String(e.itemName).slice(0,120):''),before:moriAuditValue_(scalar(e.before),key),after:moriAuditValue_(scalar(e.after),key),field:e.field};
  });
  var doc={id:id,branchId:Number(b.branchId),at:moriNow_(),email:actor.email,action:'BILL_EDIT',entity:'BILL',recordId:'DRAFT:'+b.clientRequestId,clientRequestId:String(b.clientRequestId),description:'Sửa bill đang lập '+String(b.tempNo||'').slice(0,80)+' · '+details.length+' thay đổi',details:details,changes:{},source:'CONFIRMED_UI_EDIT'};
  fresh.push(doc);out.push(doc);
 });
 if(fresh.length)moriInsertMany_('Audit',fresh);return out;
}
function moriBillAudit(token,payload){return moriLock_(function(){var actor=moriActor_(token);return {ok:true,audits:moriRecordBillEdits_(actor,payload?.batches||[],null)};});}
