# Local QC — MoriPOS 3.1.5

`node tests/run-tests.js`: **11 test suites, 107 PASS** (simulation only).

Tests cover: OTP startup and checksum; checkout and stock/booking semantics; audit; Forecast business calculations; money suggestions; on-demand snapshot; daily backfill; day/hour Vietnam boundaries; edits/repricing/cancellations; confirmed stock cashflow; non-double-counting; failure and replay; access by branch and role; dashboard aggregate query; backfill readiness after multiple batches.

Limits: tests use an in-memory simulation of Google Sheets and Apps Script; **not a timing/availability measurement on actual Google servers**. Manual staging verification is required before production.
