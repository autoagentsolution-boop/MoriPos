# MoriPOS 3.2.12 — sắp xếp bộ lọc mặt hàng

## Thay đổi

- Bỏ nhãn đếm dạng “25 / 25 mặt hàng” ở phía trên bảng Danh mục hiện tại.
- Đặt Danh mục và Trạng thái cạnh nhau trên cùng một dòng, cùng chiều cao dropdown.
- Màn hình hẹp đưa cả nhóm lọc xuống dưới tiêu đề; hai bộ lọc vẫn ở cùng một dòng.
- Giữ bộ lọc, số lượng ở phân trang và hành vi dropdown Mori hiện có.

## Nâng cấp từ 3.2.11

Chỉ thay **Index.html** và **Code.gs**. Chạy `moriFrontendCheck()` để xác nhận build `3.2.12`, `ok: true`, `exactFileMatch: true`, sau đó **Deploy → Manage deployments → Edit → New version → Deploy** và tải lại trang.

Nếu đang ở 3.2.9/3.2.10, dùng đủ 8 file theo `README_UPGRADE_3_2_11.md`, lấy nội dung từ gói 3.2.12 này.

Đây là gói full scripts. Logic ghi dữ liệu, cache, xử lý nền và tính toán giữ nguyên 3.2.11. Chưa thực hiện đề xuất lưu tạm UI hoặc tách công việc nền mới; các phương án đó chỉ được giải thích trong câu trả lời theo yêu cầu của bạn.

## Kiểm tra

3 bộ kiểm tra hiện có (khởi động, chỉnh sửa/lọc danh mục, dropdown) đạt 46 nhóm kiểm tra trong mô phỏng Node/DOM/RPC/Sheets. Checksum giao diện khớp. Đối chiếu gói trước xác nhận chỉ `Index.html` và các hằng phiên bản/checksum trong `Code.gs` thay đổi ở runtime.

Chưa kiểm tra bố cục trong trình duyệt thật hoặc triển khai lên Web App của bạn. Log: `tests/TEST_3212_RUN.log`. Các báo cáo của 3.2.11 được giữ để tham khảo bản nền.
