# MoriPOS v3.1.4 performance patch — local verification

- 10 Node.js suites, 100 PASS groups. Tests use in-memory Sheets/Cache/RPC simulations; **not** live Google Apps Script timing.
- Cache hit: no Bills, StockIn, Items or ForecastPlans Sheet reads after authentication.
- Cache access still requires authorized actor and branch.
- `forceRefresh` bypasses cached snapshot.
- Catalog writes invalidate generation so subsequent Forecast reads recompute.
- Only JSON column H is read for historical Bills, covering all active data.
- Original login, checkout, audit and planning tests remain green.

## Unmeasured

- Real response time cold/warm, network/Google RPC overhead, actual Calendar Trigger behavior, quotas, and large-store scaling. Validate on a staging deployment.
