# POS_Dashboard — Nền tảng Analytics phục vụ Forecast và Dashboard

## Cấu trúc workbook

```text
MoriPOS_Data/
├── POS_Master                  ← Settings / Branches / Employees / ForecastPlans
├── POS_Items                   ← Catalog và định lượng
├── POS_Bills                   ← Giao dịch gốc
├── POS_StockIn                 ← Phiếu nhập kho gốc
├── POS_Dashboard               ← DỮ LIỆU PHÂN TÍCH (file riêng)
│   ├── AnalyticsLedger         ← 1 bản ghi / nguồn Bill hoặc StockIn
│   └── AnalyticsDaily          ← 1 chi nhánh × 1 ngày × 1 mặt hàng / fact
└── ... các POS_* hiện có
```

## Metadata

Cả 2 tab `POS_Dashboard` đều có cột `id | branch_id | event_day | status | created_at | updated_at | version | data_json`. Đối tượng trong `data_json` là fact đã chuẩn hóa, không chứa toàn bộ PII từ nguồn.

| Bảng | Khóa | Nội dung |
|---|---|---|
| `AnalyticsLedger` | `B|billId` hoặc `S|stockInId` | Fingerprint + đóng góp số lượng, doanh thu, giá vốn, tiền nhập kho; dùng để reproject khi bill sửa/hủy |
| `AnalyticsDaily` | `branchId|YYYY-MM-DD|itemId` | Doanh số ngày, qty, COGS, hóa đơn, nhập kho; phục vụ báo cáo nhanh |

Fact `SALES_ITEM` mang `qty`, `revenue`, `cost`; `BILLS_COUNT` mang `paidBillCount`; `STOCK_CASH` mang `purchaseAmount`, `receiptCount`. `STOCK_CASH` là dòng tiền, **không** cộng vào COGS thêm lần nữa.

**Phân quyền:** `moriAnalyticsQuery(token,{branchId,startDate,endDate,groupBy})` kiểm tra vai trò Admin/Manager và quyền chi nhánh. Web app không đọc Google Sheet trực tiếp. `groupBy`: `DAY`, `MONTH`, `ITEM`.

**Cập nhật:** worker Apps Script 5 phút/lần nhận outbox thay đổi rồi xây lại các ngày ảnh hưởng trong `AnalyticsDaily`. Có `materializedAt` và `hasPendingChanges` để cảnh báo dữ liệu trễ. Forecast dùng bảng này thay cho quét tất cả raw Bills. Điều này làm giảm tải lên `POS_Master` và tạo cơ sở cho dashboard tương lai, nhưng không loại bỏ mọi giới hạn của Apps Script/Sheets.
