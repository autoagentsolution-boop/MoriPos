
/** v3.1.4: short-lived, branch-scoped Forecast snapshots, invalidated on POS writes.
 * Cache is a performance layer, never a permission layer. The requesting actor is
 * authorized before any read, including cache hits.
 */
var MORI_FC_CACHE_TTL_=300;
function moriForecastCacheEpoch_(){
 var c=CacheService.getScriptCache(),v=c.get('mori:fc:epoch:315');
 if(!v){v=Utilities.getUuid();c.put('mori:fc:epoch:315',v,21600);}
 return v;
}
function moriForecastSnapshotKey_(branchId,start,end,lookback){
 var seed='v315|'+moriForecastCacheEpoch_()+'|'+String(branchId)+'|'+start+'|'+end+'|'+lookback;
 var bytes=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,seed,Utilities.Charset.UTF_8);
 return 'mori:fc:'+bytes.map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2);}).join('').slice(0,32);
}
function moriForecastCacheRead_(key){
 try{
  var c=CacheService.getScriptCache(),head=c.get(key+':meta');if(!head)return null;
  var n=Number(head),parts=[];if(!Number.isInteger(n)||n<1||n>12)return null;
  for(var j=0;j<n;j++){var part=c.get(key+':'+j);if(part===null||part===undefined)return null;parts.push(part);}
  var data=JSON.parse(parts.join(''));return data&&data.ok===true?data:null;
 }catch(e){console.warn('Forecast cache miss: '+e.message);return null;}
}
function moriForecastCacheWrite_(key,data){
 try{
  var raw=JSON.stringify(data),size=28000,n=Math.ceil(raw.length/size);
  // CacheService entries are limited in size. If the payload exceeds this safe
  // envelope, serve directly rather than storing a partial result.
  if(n>12||n<1)return false;
  var c=CacheService.getScriptCache();
  for(var i=0;i<n;i++)c.put(key+':'+i,raw.slice(i*size,(i+1)*size),MORI_FC_CACHE_TTL_);
  c.put(key+':meta',String(n),MORI_FC_CACHE_TTL_);return true;
 }catch(e){console.warn('Forecast cache unavailable: '+e.message);return false;}
}
/** Raw sales belong exclusively to the background analytics projector. */
/** This private function (trailing underscore) cannot be called through google.script.run.
 * It is invoked only by an owner-installed time trigger. Never expose it as a
 * public no-token RPC, since each call may scan the entire active Bill table.
 * Warm at most 2 active branches per invocation to control Apps Script quota.
 */
function moriForecastWarmup_(){
 var owner=String(moriProp_('OWNER_EMAIL')||'').toLowerCase(),effective=String(Session.getEffectiveUser().getEmail()||'').toLowerCase();
 moriEnsure_(owner&&effective===owner,'Chỉ chủ hệ thống được chạy trigger Forecast');
 var acl=moriFind_('AccessControl',moriProp_('OWNER_EMAIL'));
 moriEnsure_(acl&&acl.isActive!==false&&acl.role==='ADMIN','Tài khoản chạy lịch không phải chủ hệ thống');
 var actor=moriUser_(acl),settings=moriFind_('Settings','global')||{};
 if(settings.modules?.forecast===false)return {ok:true,skipped:'Forecast đã tắt'};
 var today=moriDate_(),branches=moriAll_('Branches',true).filter(function(b){return b.isActive!==false&&(!actor.branchIds?.length||actor.branchIds.map(Number).indexOf(Number(b.id))>=0);}).slice(0,2),warmed=[];
 branches.forEach(function(b){var x=moriForecastLoadFor_(actor,{branchId:Number(b.id),startDate:today,endDate:moriForecastShift_(today,6),lookbackDays:settings.forecast?.lookbackDays||28});warmed.push({branchId:b.id,fromCache:!!x.timing.fromCache,serverMs:x.timing.serverMs});});
 return {ok:true,warmed:warmed,at:moriNow_()};
}
/** Editor-only, opt-in: register at most one time-driven warm-up trigger. */
function moriForecastInstallWarmup(){
 moriEditorOnly_();
 var existing=ScriptApp.getProjectTriggers().filter(function(t){return t.getHandlerFunction()==='moriForecastWarmup_';});
 if(!existing.length)ScriptApp.newTrigger('moriForecastWarmup_').timeBased().everyMinutes(5).create();
 return {ok:true,installed:true,existingCount:existing.length};
}
/** Editor-only rollback for the optional background schedule. */
function moriForecastRemoveWarmup(){
 moriEditorOnly_();var n=0;
 ScriptApp.getProjectTriggers().forEach(function(t){if(t.getHandlerFunction()==='moriForecastWarmup_'){ScriptApp.deleteTrigger(t);n++;}});
 return {ok:true,removed:n};
}

/** Forecast is loaded on demand; no extra workbook is read during login or checkout. */
function moriForecastRequire_(actor,branchId){moriRequire_(actor,['ADMIN','MANAGER'],branchId);moriEnsure_((moriFind_('Settings','global')||{}).modules?.forecast!==false,'Module Forecast đang tắt');moriEnsure_(moriFind_('Branches',branchId),'Chi nhánh không tồn tại');}
function moriForecastInstalled_(){var book=MORI_BOOK_HANDLES_.MASTER;if(!book)book=MORI_BOOK_HANDLES_.MASTER=SpreadsheetApp.openById(moriProp_('FILE_MASTER'));return !!book.getSheetByName('ForecastPlans');}
function moriForecastInstall_(actor){
 moriRequire_(actor,['ADMIN']);var book=MORI_BOOK_HANDLES_.MASTER;if(!book)book=MORI_BOOK_HANDLES_.MASTER=SpreadsheetApp.openById(moriProp_('FILE_MASTER'));
 var sheet=book.getSheetByName('ForecastPlans');if(!sheet){sheet=book.insertSheet('ForecastPlans');sheet.getRange(1,1,1,8).setValues([MORI_HEADERS]);sheet.setFrozenRows(1);sheet.getRange('A:A').setNumberFormat('@');sheet.getRange('H:H').setNumberFormat('@');}
 MORI_SHEET_HANDLES_.ForecastPlans=sheet;
 var old=moriFind_('Settings','global'),doc=moriDeep_(old);doc.modules=doc.modules||{};if(doc.modules.forecast===undefined)doc.modules.forecast=true;if(!doc.forecast)doc.forecast=Object.assign(moriForecastDefaults_(),{version:1});
 if(JSON.stringify(old)!==JSON.stringify(doc)){doc=moriPut_('Settings',doc,old.version);moriAudit_(actor.email,'ENABLE','FORECAST','module',old,doc);}
 return {ok:true,installed:true,defaults:doc.forecast,settingsVersion:doc.version,modules:doc.modules};
}
function moriForecastInstall(token){return moriLock_(function(){return moriForecastInstall_(moriActor_(token));});}
function moriUpgradePlanning(){moriEditorOnly_();return moriLock_(function(){var acl=moriFind_('AccessControl',moriProp_('OWNER_EMAIL'));moriEnsure_(acl,'Không tìm thấy chủ hệ thống');return moriForecastInstall_(moriUser_(acl));});}
/** Forecast operating expense and stock cash spending: distinct ledgers to prevent double COGS. */
function moriForecastMonthlyFactor_(start,end){
 start=moriForecastDay_(start);end=moriForecastDay_(end);
 var first=Date.parse(start+'T00:00:00Z'),last=Date.parse(end+'T00:00:00Z')+86400000;
 moriEnsure_(last>first&&last-first<=366*86400000,'Kỳ chi phí không hợp lệ');
 var cursor=new Date(first),factor=0;
 while(cursor.getTime()<last){
  var y=cursor.getUTCFullYear(),m=cursor.getUTCMonth(),begin=Date.UTC(y,m,1),next=Date.UTC(y,m+1,1),days=(next-begin)/86400000;
  factor+=Math.max(0,Math.min(last,next)-Math.max(first,begin))/86400000/days;
  cursor=new Date(next);
 }
 return factor;
}
function moriForecastCostSummary_(actor,branchId,startDate,endDate,aggregateRows){
 // Caller must authorize the branch BEFORE reading amounts. No employee names are returned.
 moriForecastRequire_(actor,branchId);
 var store=moriFind_('Stores','1')||{},branch=moriFind_('Branches',branchId)||{};
 var allBranches=moriAll_('Branches',true).filter(function(b){return b.isActive!==false&&Number(b.storeId||1)===Number(branch.storeId||1);});
 var share=Math.max(1,allBranches.length),factor=moriForecastMonthlyFactor_(startDate,endDate),sum=function(value){return Math.round(Math.max(0,Number(value)||0)*factor);};
 var staff=moriAll_('Employees',true).filter(function(e){return e.isActive!==false&&Number(e.branchId)===Number(branchId);});
 var salaryMonthly=0,unpricedStaff=0;staff.forEach(function(e){if(Number(e.salaryBase)>0)salaryMonthly+=Number(e.salaryBase);else unpricedStaff++;});
 var storeRent=Math.round(sum(store.monthlyRent)/share),storeOther=Math.round(sum(store.monthlyOtherCost)/share);
 var branchRent=sum(branch.monthlyRent),branchOther=sum(branch.monthlyOtherCost),salary=sum(salaryMonthly);
 var fixed=storeRent+storeOther+branchRent+branchOther+salary;
 // Materialized purchase cashflow, read from AnalyticsDaily (never raw StockIn here).
 var purchase=0,count=0;
 var purchaseRows=aggregateRows||moriAnalyticsDailyRead_(branchId,startDate,endDate);
 purchaseRows.forEach(function(r){if(r.kind!=='STOCK_CASH')return;purchase+=Number(r.purchaseAmount)||0;count+=Number(r.receiptCount)||0;});
 var historyPartial=false;
 var warnings=[];
 if(unpricedStaff)warnings.push(unpricedStaff+' nhân sự chưa có lương cố định/tháng; lương ca/giờ cần nhập mức dự toán tháng để được tính.');
 if(!moriAnalyticsReady_())warnings.push('Tầng Analytics chưa hoàn tất nạp lịch sử; dữ liệu tổng hợp chưa sẵn sàng.');
 if(share>1)warnings.push('Chi phí chung cửa hàng đang phân bổ đều cho '+share+' chi nhánh đang hoạt động.');
 return {periodFactor:factor,allocatedBranchCount:share,storeRent:storeRent,storeOther:storeOther,branchRent:branchRent,branchOther:branchOther,salaries:salary,unpricedStaff:unpricedStaff,operatingFixedTotal:fixed,stockPurchases:Math.round(purchase),confirmedStockReceipts:count,totalCashOut:fixed+Math.round(purchase),stockHistoryPartial:historyPartial,warnings:warnings,fromDate:startDate,toDate:endDate};
}

function moriForecastLoad(token,query){return moriForecastLoadFor_(moriActor_(token),query);}
function moriForecastLoadFor_(actor,query){
 var started=Date.now(),q=query||{},branchId=Number(q.branchId),settings=moriFind_('Settings','global')||{};moriForecastRequire_(actor,branchId);
 var defaults=moriForecastConfig_(settings.forecast||moriForecastDefaults_()),today=moriDate_(),start=moriForecastDay_(q.startDate||today),end=moriForecastDay_(q.endDate||moriForecastShift_(today,6));
 var periodDays=(Date.parse(end)-Date.parse(start))/86400000+1;moriEnsure_(periodDays>=1&&periodDays<=366,'Kỳ kế hoạch phải từ 1 đến 366 ngày');
 var lookback=Math.round(moriForecastNumber_(q.lookbackDays??defaults.lookbackDays,1,180,'Số ngày tham chiếu'));
 // Important: authorization and query validation happen ABOVE the cache lookup.
 moriAnalyticsRequireReady_();
 var key=moriForecastSnapshotKey_(branchId,start,end,lookback),hit=!q.forceRefresh?moriForecastCacheRead_(key):null;
 if(hit){hit.timing={serverMs:Date.now()-started,fromCache:true,computedAt:hit.generatedAt};return hit;}
 var phase={},at=Date.now();
 var analytics=moriAnalyticsRequireReady_(),index=moriItemIndex_(),byItem={},nowMs=Date.now();
 var prevEnd=start<today?start:today,prevStart=moriForecastShift_(prevEnd,-periodDays),refStart=moriForecastShift_(today,-lookback);
 var minDay=[start,prevStart,refStart].sort()[0],maxDay=[end,moriForecastShift_(today,-1)].sort().slice(-1)[0];
 var daily=moriAnalyticsDailyRead_(branchId,minDay,maxDay),earliest=null,paidCount=0,lastPaidAt=null,purchaseRows=[];
 phase.readDailyMs=Date.now()-at;at=Date.now();
 daily.forEach(function(r){
  if(r.status==='EMPTY')return;
  var day=String(r.day),current=day>=start&&day<=end,previous=day>=prevStart&&day<prevEnd,reference=day>=refStart&&day<today;
  if(r.kind==='STOCK_CASH'){if(current)purchaseRows.push(r);return;}
  if(r.kind==='BILLS_COUNT'){
   if(Number(r.paidBillCount)>0){earliest=!earliest||day<earliest?day:earliest;if(current||previous||reference){paidCount+=Number(r.paidBillCount)||0;if(!lastPaidAt||String(r.lastPaidAt)>lastPaidAt)lastPaidAt=r.lastPaidAt;}}
   return;
  }
  if(r.kind!=='SALES_ITEM'||!current&&!previous&&!reference)return;
  var id=String(r.itemId),st=byItem[id]||(byItem[id]={currentQty:0,currentRevenue:0,currentCost:0,previousQty:0,previousRevenue:0,previousCost:0,referenceQty:0,referenceRevenue:0,referenceCost:0,estimatedCostLines:0});
  ['current','previous','reference'].forEach(function(key,j){if([current,previous,reference][j]){st[key+'Qty']+=Number(r.qty)||0;st[key+'Revenue']+=Number(r.revenue)||0;st[key+'Cost']+=Number(r.cost)||0;}});
  if(current)st.estimatedCostLines+=Number(r.estimatedCostLines)||0;
 });
 var startMs=new Date(start+'T00:00:00+07:00').getTime(),endMs=new Date(moriForecastShift_(end,1)+'T00:00:00+07:00').getTime();
 phase.aggregateBillsMs=Date.now()-at;at=Date.now();
 var reserved=moriReservations_(branchId,null,index),available={},threshold=settings.lowStockPolicy==='BLOCK'?Number(settings.lowStockThreshold)||0:0;
 Object.keys(index).forEach(function(id){available[id]=Math.max(0,moriInventorySource_(index[id],branchId).qty-(reserved[id]||0)-threshold);});
 phase.readInventoryMs=Date.now()-at;at=Date.now();
 var costSummary=moriForecastCostSummary_(actor,branchId,start,end,purchaseRows);
 phase.readCostsMs=Date.now()-at;at=Date.now();
 var installed=moriForecastInstalled_(),plans=installed?moriAll_('ForecastPlans',false).filter(function(p){return Number(p.branchId)===branchId;}).sort(function(a,b){return String(b.updatedAt).localeCompare(String(a.updatedAt));}).slice(0,40).map(function(p){return {id:p.id,name:p.name,startDate:p.startDate,endDate:p.endDate,version:p.version,updatedAt:p.updatedAt};}):[];
 var items=Object.keys(index).map(function(id){var x=moriDeep_(index[id]);delete x.appliedOps;delete x.stockByBranch;delete x.stock;if(x.costByBranch){var localCost=x.costByBranch[String(branchId)];x.costByBranch={};if(localCost!==undefined)x.costByBranch[String(branchId)]=localCost;}return x;});
 phase.readPlansAndShapeMs=Date.now()-at;
 var result={ok:true,installed:installed,defaults:Object.assign(defaults,{version:settings.forecast?.version||0}),plans:plans,branchId:branchId,today:today,startDate:start,endDate:end,periodDays:periodDays,lookbackDays:lookback,referenceStart:refStart,referenceEnd:moriForecastShift_(today,-1),previousStart:prevStart,previousEnd:moriForecastShift_(prevEnd,-1),elapsedDays:Math.max(0,Math.min(periodDays,(nowMs-startMs)/86400000)),remainingDays:Math.max(0,Math.min(periodDays,(endMs-Math.max(nowMs,startMs))/86400000)),items:items,byItem:byItem,available:available,lastPaidAt:lastPaidAt,generatedAt:moriNow_(),costSummary:costSummary,coverage:{source:'AnalyticsDaily',aggregateRowsRead:daily.length,paidBillsInWindows:paidCount,earliestActivePaidDay:earliest,archivesIncluded:true,materializedAt:analytics.lastMaterializedAt||null,hasPendingChanges:!!analytics.hasPendingChanges},timing:{serverMs:Date.now()-started,fromCache:false,phases:phase}};
 moriForecastCacheWrite_(key,result);
 return result;
}
function moriForecastGet(token,id){var actor=moriActor_(token);moriRequire_(actor,['ADMIN','MANAGER']);moriEnsure_(moriForecastInstalled_(),'Chưa khởi tạo module');var doc=moriFind_('ForecastPlans',id);moriEnsure_(doc,'Không tìm thấy kế hoạch');moriForecastRequire_(actor,doc.branchId);return doc;}
function moriForecastSave(token,raw){return moriLock_(function(){
 var actor=moriActor_(token),plan=moriForecastNormalize_(raw);moriForecastRequire_(actor,plan.branchId);moriEnsure_(moriForecastInstalled_(),'Admin cần khởi tạo module Forecast một lần');
 if(plan.fixedCostMode==='AUTO'){moriAnalyticsRequireReady_();var costs=moriForecastCostSummary_(actor,plan.branchId,plan.startDate,plan.endDate);plan.fixedCosts=costs.operatingFixedTotal+plan.extraFixedCosts;}
 var index=moriItemIndex_();plan.items.forEach(function(l){var item=index[String(l.itemId)];moriEnsure_(item&&item.isActive!==false&&item.type!=='MATERIAL','Mặt hàng kế hoạch không còn bán');moriRecipe_(l.itemId,index,plan.branchId,1);});
 var before=plan.id?moriFind_('ForecastPlans',plan.id):null;
 if(!plan.id){moriEnsure_(plan.clientRequestId.length>=12,'Thiếu mã yêu cầu lưu kế hoạch');var existing=moriFindJsonString_('ForecastPlans','clientRequestId',plan.clientRequestId);if(existing){moriForecastRequire_(actor,existing.branchId);moriEnsure_(Number(existing.branchId)===plan.branchId,'Sai chi nhánh kế hoạch');return existing;}}
 if(plan.id){moriEnsure_(before,'Kế hoạch không tồn tại');moriForecastRequire_(actor,before.branchId);moriEnsure_(Number(before.branchId)===plan.branchId,'Không chuyển kế hoạch sang chi nhánh khác');moriEnsure_(plan.version!==undefined,'Thiếu phiên bản kế hoạch');}
 var doc=Object.assign({},plan,{id:before?before.id:moriNext_('FORECAST'),version:before?before.version:1,createdBy:before?.createdBy||actor.email,updatedBy:actor.email,status:'ACTIVE'});
 doc=before?moriPut_('ForecastPlans',doc,plan.version):moriInsert_('ForecastPlans',doc);moriAudit_(actor.email,before?'UPDATE':'CREATE','FORECAST',doc.id,before,doc);return doc;
});}
function moriForecastSaveDefaults(token,raw){return moriLock_(function(){var actor=moriActor_(token);moriRequire_(actor,['ADMIN']);var old=moriFind_('Settings','global'),doc=moriDeep_(old);moriEnsure_(Number(raw.version||0)===Number(old.forecast?.version||0),'VERSION_CONFLICT: Cấu hình lợi nhuận đã thay đổi');doc.forecast=Object.assign(moriForecastConfig_(raw),{version:Number(old.forecast?.version||0)+1});doc=moriPut_('Settings',doc,old.version);moriAudit_(actor.email,'UPDATE','FORECAST_SETTINGS','global',old.forecast||{},doc.forecast);return {defaults:doc.forecast,settingsVersion:doc.version};});}
