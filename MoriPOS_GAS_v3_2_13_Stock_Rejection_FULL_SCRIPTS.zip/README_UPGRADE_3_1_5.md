> **Tài liệu lịch sử v3.1.5 — không dùng để deploy v3.1.6.** Bản mới tách `AnalyticsLedger` và `AnalyticsDaily` sang **Spreadsheet riêng `POS_Dashboard`**. Xem `README_UPGRADE_3_1_6.md`.

# MoriPOS v3.1.5 — Analytics Daily & Dashboard Foundation

## Mục tiêu

Không đọc toàn bộ **SalesBills** để tính Forecast mỗi lần mở trang. Giữ mô hình Google Apps Script + Google Sheets, nhưng tách rõ:

- **Raw/Operational**: `POS_Bills`, `POS_StockIn`, `POS_Items`, các bảng hiện có. Phục vụ giao dịch thực tế.
- **Incremental projector**: `Analytics.gs`, nhận outbox từ ghi bill/nhập kho; worker riêng chạy mỗi 5 phút.
- **Materialized read model**: `AnalyticsLedger` + `AnalyticsDaily` trong `POS_Master`. Forecast và dashboard dùng dữ liệu đã tổng hợp.
- **Client**: Forecast vẫn chỉ tính 3 kịch bản từ snapshot, không truy vấn dữ liệu lịch sử theo từng thao tác gõ.

```text
POS (Bills, StockIn) --ghi thành công--> Outbox (Script Properties, sharded)
                                       |
                           Worker 5 phút / backfill lịch sử
                                       |
                                AnalyticsLedger
                             (1 projection / chứng từ)
                                       |
                     Recompute những ngày có thay đổi
                                       |
                                 AnalyticsDaily
                                 /            \
                        Forecast API        Dashboard API
```

## Triển khai trên project đã có dữ liệu

1. Sao lưu project Apps Script và các Google Sheets, **không chạy lại** `moriSetup` / seed. Giữ nguyên tất cả `MORI_FILE_*` Script Properties.
2. Thay đồng bộ toàn bộ các file `.gs` và `Index.html` trong ZIP; **thêm `Analytics.gs`**. Xóa `MoriPreflight314.gs` cũ nếu có, dùng `MoriPreflight315.gs`. Không tải `Original_UI_Offline.html`, `tests/`, `docs/`, file Markdown lên project.
3. Chạy `moriPreflight315()` và `moriFrontendCheck()` từ Apps Script Editor: phải có `ok: true`, `exactFileMatch: true`, build `3.1.5`. Tạo **New version** trên deployment hiện tại, giữ quyền và URL `/exec` cũ.
4. **Bắt buộc:** từ Apps Script Editor (tài khoản owner), chạy **`moriAnalyticsInstall()` một lần**. Hàm chỉ tạo hai tab `AnalyticsLedger`, `AnalyticsDaily` trong `POS_Master`, cài trigger 5 phút và tắt trigger `moriForecastWarmup_` cũ. Có thể cần cấp quyền ScriptApp.
5. Chạy **`moriAnalyticsSyncNow()`** để bắt đầu nhập lịch sử. Nếu dữ liệu nhiều, chạy lại hàm này thêm các lượt hoặc để trigger tiếp tục nạp theo lô; mỗi lượt thường đọc tối đa 160 dòng lịch sử, sau đó tái tổng hợp tối đa 12 ngày có thay đổi. **Không có thời gian hoàn tất cố định**; phụ thuộc số dòng và Apps Script quota.
6. Chạy **`moriAnalyticsStatus()`** và xem `ready: true`, `backfillComplete: true`, `pendingDirtyDays: 0` để xác nhận backfill đã hoàn tất. Chỉ khi `ready: true` Forecast mới được mở; trước đó sẽ có thông báo đồng bộ chưa hoàn tất, **không tự đọc raw Bills để che lỗi**.
7. Kiểm tra số doanh thu, giá vốn, số bill, chi phí nhập kho bằng cách so sánh với các Bill/StockIn mẫu, test bill sửa/hủy, kiểm tra các role và chi nhánh. Mở Forecast `/exec` và dùng **Cập nhật từ doanh số** để bỏ qua cache và đọc lại `AnalyticsDaily`.

**Không cần tạo workbook khác, không đổi ID Google Sheets, không migrate dữ liệu cũ theo kiểu xóa/copy raw.** Thao tác cài đặt có thể chạy lại an toàn. Khi `ready: true`, dữ liệu mới có độ trễ theo lịch worker khoảng 5 phút (có thể lâu hơn khi trigger bị trễ hoặc quota giới hạn).

## Các sheet mới trong POS_Master

Đều dùng 8 cột metadata nhất quán: `id | branch_id | event_day | status | created_at | updated_at | version | data_json`.

**AnalyticsLedger**: một bản ghi theo source (`B|<Bill ID>`, `S|<StockIn ID>`), lưu fingerprint và `entries[]` đóng góp kinh tế. Khi sửa bill, ledger giữ phiên bản hiện tại, ngày cũ và ngày mới được đánh dấu để tái tính. Ledger chỉ chứa thông tin cần tổng hợp, không sao chép khách hàng/nhân viên.

**AnalyticsDaily**: một bản ghi theo `branchId|YYYY-MM-DD|itemId`.

- `SALES_ITEM`: `qty`, `revenue` (đã phân bổ chiết khấu, không gồm tip), `cost`, `estimatedCostLines`.
- `BILLS_COUNT` (`__BILLS__`): số bill đã thanh toán trong ngày, `lastPaidAt`.
- `STOCK_CASH` (`__STOCK__`): tổng tiền các phiếu nhập đã xác nhận, số phiếu nhập.
- `status: EMPTY`: bản ghi đã được xóa khỏi tổng hợp vì chứng từ đổi ngày/hủy; không được cộng khi báo cáo.

**Stock cash là dòng tiền chi, KHÔNG phải chi phí P&L lần thứ hai**. Lợi nhuận gộp = doanh thu sau giảm giá − giá vốn theo lượng bán. Lợi nhuận Forecast còn trừ chi phí bổ sung/đơn vị và chi phí vận hành.

## Dashboard API sẵn có

`moriAnalyticsQuery(token, {branchId, startDate:'2026-11-01',endDate:'2026-11-30',groupBy:'DAY'})`

`groupBy` nhận `DAY`, `MONTH`, `ITEM`. Response `summary` và `data[]`: `quantity`, `revenue`, `cogs`, `grossProfit`, `bills`, `stockPurchases`, `stockReceipts`; trả `materializedAt` và `hasPendingChanges`. Có kiểm tra phiên đăng nhập và quyền **ADMIN / MANAGER** trên chi nhánh; không có API đọc dữ liệu raw hoặc nhân sự. **grossProfit** là lợi nhuận gộp, không phải lợi nhuận ròng.

## Độ đúng và giới hạn

- **Không đọc lịch sử Bills hoặc StockIn khi mở Forecast**. Lần backfill/worker vẫn phải đọc nguồn để cập nhật view; phép kiểm tra giữ hàng trong các đơn **đang mở** vẫn đọc trạng thái hoạt động để tính tồn khả dụng chính xác.
- Outbox đặt ở Script Properties, không thêm lần ghi Google Sheet vào checkout. Khi queue bị lỗi/quá quota, hệ thống đánh dấu `ANALYTICS_REPAIR_REQUIRED`, tạm dừng Forecast thay vì cho số liệu sai; cần kiểm tra Script Executions, xử lý quota, rồi chạy `moriAnalyticsRebuildHistory()` để đối soát lại từ nguồn. **Không tự xóa flag bằng tay**.
- Tự sửa/xóa trực tiếp trong Google Sheets không phát outbox; cần chạy `moriAnalyticsRebuildHistory()` sau các chỉnh sửa trực tiếp. Chức năng này xử lý bản ghi còn trong raw/archives; **xóa cứng nguồn mà không có hồ sơ lưu trữ** cần kiểm tra thủ công vì không thể đối soát phần dữ liệu đã mất.
- Nạp lịch sử gồm bảng hoạt động và các file archive được MoriPOS biết qua `MORI_ARCHIVE_*`. Hệ thống tạm **ngăn chuyển raw Bills/StockIn vào archive** nếu Analytics chưa ready hoặc còn dữ liệu chờ để tránh thất lạc thống kê.
- Với quy mô lớn trong nhiều năm, mỗi tab Google Sheets vẫn chịu giới hạn số ô và quota; cách mở rộng tiếp theo là partition theo tháng hoặc di chuyển dữ liệu Analytics sang kho dữ liệu chuyên dụng. Mức hiệu năng thực tế phải đo từ deployment.

## Các hàm bảo trì

- `moriAnalyticsInstall()`: tạo bảng + trigger, chỉ chạy từ Apps Script Editor.
- `moriAnalyticsSyncNow()`: chạy ngay một lượt đồng bộ, chỉ Owner trong Editor.
- `moriAnalyticsStatus()`: trạng thái backfill/queue/checkpoint.
- `moriAnalyticsRebuildHistory()`: bắt đầu đối soát lại (tạm tắt Forecast cho tới khi làm xong).
- `moriFrontendCheck()`: checksum file giao diện và backend.

## Rollback

Có thể redeploy version cũ để tiếp tục hoạt động POS; **không xóa các tab analytics** nếu vẫn muốn giữ dữ liệu tổng hợp. Khi đang ở bản cũ, các ghi bill mới sẽ không tạo outbox Analytics; muốn quay lại bản 3.1.5 cần chạy `moriAnalyticsRebuildHistory()` để nạp phần phát sinh trong thời gian rollback.
