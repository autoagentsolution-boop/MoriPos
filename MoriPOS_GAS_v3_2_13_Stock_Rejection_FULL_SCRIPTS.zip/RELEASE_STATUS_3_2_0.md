# MoriPOS v3.2.0 — Release status

**Feature complete for code review and staging**; not verified on actual Google Apps Script production.

- A: Staff Access Administration with per-RPC allowlist, multi-branch assignment and revocation.
- B: Guest OTP, Member registration via POS, verified identity linkage, old-order claim by tracking token.
- C: CustomerDaily incremental materialization in POS_Dashboard, authorized dashboard RPC and repair/replay.
- Migration: create separate POS_Customers and copy existing Customers from POS_Master; leave legacy copy intact; preserve numeric sequence.
- Build: Code.gs / Index.html SHA-256 handshake. Static shell stays below the pre-existing 120,000-character startup constraint.
- Automated tests: see TEST_REPORT_3_2_0.md.

Caveats: no production benchmark, no real email-delivery test, archived historical Bills require separate customer-identity backfill if desired. Use staging/backup before production.
