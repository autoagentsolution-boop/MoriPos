/** Owner-only, read-only deployment preflight for MoriPOS 3.2.3. */
function moriPreflight323(){
 moriEditorOnly_();
 var required={
  checkout:typeof moriCheckout==='function',
  coreBootstrap:typeof moriSessionBootstrap==='function',
  lazyHistory:typeof moriHistoryModule==='function',
  customerLookup:typeof moriCustomerLookup==='function',
  staffLogin:typeof moriAuthStart==='function'&&typeof moriActor_==='function',
  inventory:typeof moriInventoryValidate_==='function',
  customerAnalytics:typeof moriCustomerAnalyticsQuery==='function',
  forecast:typeof moriForecastLoad==='function',
  publicSite:typeof moriPublicBootstrap==='function',
  analyticsFoundation:typeof moriAnalyticsQuery==='function'
 };
 var missing=Object.keys(required).filter(function(k){return !required[k];});
 var frontend=moriFrontendCheck();
 return {ok:missing.length===0&&frontend.ok&&frontend.exactFileMatch&&frontend.build==='3.2.3',
  version:'3.2.3',required:required,missing:missing,
  frontend:{ok:frontend.ok,exactFileMatch:frontend.exactFileMatch,build:frontend.build},
  analyticsConfigured:!!moriProp_('FILE_DASHBOARD'),customersConfigured:!!moriProp_('FILE_CUSTOMERS')};
}
