# MoriPOS v3.2.5 — Holiday Settings UI Alignment

**Phạm vi: Giao diện và điều hướng sau lưu. Không sửa business logic, cấu trúc Sheets, lịch giá hay phương pháp tính giá.**

Từ MoriPOS v3.2.4, **chỉ thay đúng 2 file**:

1. `Index.html`: Bố cục & style phần Cài đặt → Mặt hàng / Lịch giá đặc biệt; điều hướng về Cài đặt → Mặt hàng khi lưu lịch giá thành công.
2. `Code.gs`: Chỉ cập nhật build `3.2.5` và SHA-256 của `Index.html`. Nếu không thay, `moriFrontendCheck()` sẽ báo lệch phiên bản/checksum.

## Giao diện
- Các ô tên/ngày/tần suất sử dụng cùng kích thước, viền và khoảng cách của MoriPOS.
- Nút Thêm/Lưu/Quản lý lịch có icon và text trên một hàng, canh đều.
- Hai nhóm ngày lễ và khoảng ngày được hiển thị trong card riêng, không cần tạo lại danh sách.
- Các mục đã nhập vẫn hiện trong danh sách với nút Bỏ hiện có; không thay đổi chức năng quản lý.
- Giao diện đáp ứng màn hình nhỏ.
- Lưu lịch thành công -> chuyển về Cài đặt → Mặt hàng. Nếu lưu lỗi -> ở lại màn hình lịch và hiển thị lỗi.

## Deploy
1. Backup Google Apps Script project hiện tại.
2. Từ patch, thay nội dung `Index.html` và `Code.gs` tương ứng.
3. Save, chạy `moriFrontendCheck()` trong Apps Script Editor. Kiểm tra `build: "3.2.5"`, `exactFileMatch: true`, `ok: true`.
4. Deploy → Manage deployments → Edit → New version → Deploy.
5. Kiểm tra Cài đặt → Mặt hàng → Quản lý lịch. Thêm thử một ngày và một khoảng ngày; kiểm tra bố cục và lưu chuyển về Cài đặt → Mặt hàng.

**Không chạy lại** `moriSetup`, `moriAnalyticsInstall`, `moriCustomerInstall`, migration hay backfill.

## Tests
Test mô phỏng: 18 bộ/151 nhóm hồi quy PASS và test bổ sung riêng UI/callback PASS. Chưa xác minh trực tiếp trên môi trường Google Apps Script production.
