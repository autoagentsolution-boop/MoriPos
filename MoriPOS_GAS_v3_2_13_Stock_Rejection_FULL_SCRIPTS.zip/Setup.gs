/** Run ONCE from the Apps Script editor as the owner. Does not seed example transactions. */
function moriSetup(ownerEmail){moriEditorOnly_();
  var email=String(ownerEmail||Session.getEffectiveUser().getEmail()||'').toLowerCase().trim();moriEnsure_(!moriProp_('OWNER_EMAIL')||moriProp_('OWNER_EMAIL')===email,'Owner email cannot be changed by re-running setup');
  moriEnsure_(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email),'Provide ownerEmail explicitly (your Gmail)');
  var rootId=moriProp_('ROOT_FOLDER');var root=rootId?DriveApp.getFolderById(rootId):DriveApp.createFolder('MoriPOS_Data');
  moriSetProp_('ROOT_FOLDER',root.getId());
  ['ProductImages','Receipts','StockInProof','AttendancePhotos','Branding','Archive'].forEach(function(name){
    var k='FOLDER_'+name.toUpperCase(),id=moriProp_(k);
    if(!id){var f=root.createFolder(name);moriSetProp_(k,f.getId());}
  });
  Object.keys(MORI_FILE_NAMES).forEach(function(type){
    var id=moriProp_('FILE_'+type);var book;
    if(id){book=SpreadsheetApp.openById(id);}else{
      book=SpreadsheetApp.create(MORI_FILE_NAMES[type]);moriSetProp_('FILE_'+type,book.getId());
      DriveApp.getFileById(book.getId()).moveTo(root);
    }
    Object.keys(MORI_TABLES).filter(function(t){return MORI_TABLES[t][0]===type;}).forEach(function(t){
      var sheet=book.getSheetByName(MORI_TABLES[t][1]);if(!sheet)sheet=book.insertSheet(MORI_TABLES[t][1]);
      if(sheet.getLastRow()===0){sheet.getRange(1,1,1,8).setValues([(t==='AnalyticsDaily'||t==='AnalyticsLedger')?MORI_ANALYTICS_HEADERS_:MORI_HEADERS]);sheet.setFrozenRows(1);sheet.getRange('A:A').setNumberFormat('@');sheet.getRange('H:H').setNumberFormat('@');}
    });
    if(book.getSheets().length>1&&book.getSheetByName('Sheet1')&&book.getSheetByName('Sheet1').getLastRow()===0)book.deleteSheet(book.getSheetByName('Sheet1'));
  });
  moriLock_(function(){
    if(!moriFind_('Stores','1'))moriInsert_('Stores',{id:1,name:'Cửa hàng của tôi',type:'FNB',phone:'',email:email,address:'',monthlyRent:0,monthlyOtherCost:0,isActive:true});
    if(!moriFind_('Branches','1'))moriInsert_('Branches',{id:1,storeId:1,code:'CN01',name:'Chi nhánh 01',phone:'',email:'',address:'',isActive:true,monthlyRent:0,monthlyOtherCost:0});
    if(!moriFind_('AccessControl',email))moriInsert_('AccessControl',{id:email,email:email,role:'ADMIN',branchIds:[1],isActive:true});
    if(!moriFind_('Employees',email))moriInsert_('Employees',{id:email,email:email,name:'Chủ cửa hàng',role:'ADMIN',branchId:1,isActive:true});
    if(!moriFind_('Settings','global'))moriInsert_('Settings',{id:'global',modules:{stockIn:true,booking:true,attendance:true,commission:false,membership:true,publishSite:false,onlineOrder:false,vietqr:true,reporting:true},lowStockThreshold:3,lowStockPolicy:'WARN',costMethod:'WEIGHTED_AVG',archive:{audit:90,bills:90,stock:180,booking:90,shipping:180,attendance:365},receipt:{paper:'80',fontSize:12},showItemImages:true,paidBillEditRoles:{ADMIN:true,MANAGER:true,EMPLOYEE:false}});
    if(!moriFind_('PublishSite','site'))moriInsert_('PublishSite',{id:'site',published:false,mode:'CONTACT',tagline:'',categoryVisibility:{},itemRules:{},bookingChannels:{PHONE:true,PUBLISH_SITE:false,FACEBOOK:false},orderBranches:'ALL',bookingBranches:'ALL'});
  });
  moriSetProp_('SEQ_BRANCH',Math.max(Number(moriProp_('SEQ_BRANCH'))||0,1));moriSetProp_('OWNER_EMAIL',email);moriSetProp_('READY','1');
  return {ok:true,owner:email,files:moriFileLinks(),folder:root.getUrl()};
}
function moriFileLinks(){moriEditorOnly_();var out={};Object.keys(MORI_FILE_NAMES).forEach(function(k){var id=moriProp_('FILE_'+k);out[k]=id?'https://docs.google.com/spreadsheets/d/'+id+'/edit':null;});return out;}
function moriSetupStatus(){moriEditorOnly_();return {ready:moriProp_('READY')==='1',files:moriFileLinks()};}
/** Create a small, reversible sample catalog. DO NOT run in a live merchant database. */
function moriSeedQC(){moriEditorOnly_();moriEnsure_(moriProp_('READY')==='1','Run moriSetup first');return moriLock_(function(){
  var samples=[{name:'Trà đào cam sả',cat:'Đồ uống',type:'PRODUCT',price:32000,cost:11000,baseUnit:'cái',track:true,stock:34},{name:'Bánh mì thịt nướng',cat:'Món ăn',type:'PRODUCT',price:39000,cost:21000,baseUnit:'cái',track:true,stock:40},{name:'Nước suối',cat:'Đồ uống',type:'PRODUCT',price:12000,cost:5000,baseUnit:'cái',track:true,stock:80},{name:'Chăm sóc móng cơ bản',cat:'Dịch vụ',type:'SERVICE',price:120000,cost:20000,track:false}];
  var created=0;samples.forEach(function(v){if(moriAll_('Items',false).some(function(i){return moriNorm_(i.name)===moriNorm_(v.name);}))return;v.id=moriNext_('ITEM');v.stockByBranch={'1':v.stock||0};v.costByBranch={'1':v.cost||0};moriInsert_('Items',v);created++;});moriClear_('Items');return {ok:true,created:created};
});}
