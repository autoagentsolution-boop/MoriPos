/** Configurable archive worker. Copy -> verify -> delete, oldest closed records first. */
function moriArchiveRun(){moriEditorOnly_();return moriArchiveRun_();}
function moriArchiveRun_(){moriEnsure_(moriProp_('READY')==='1','Not installed');var settings=moriFind_('Settings','global')||{},r=settings.archive||{},results=[];
 [['Bills',Number(r.bills)||90],['StockIn',Number(r.stock)||180],['Booking',Number(r.booking)||90],['Attendance',Number(r.attendance)||365],['Audit',Number(r.audit)||90]].forEach(function(entry){
  results.push(moriArchiveTable_(entry[0],entry[1],500));
 });return {ok:true,at:moriNow_(),results:results};
}
/** Read at most 2,000 source rows; resume the scan on the next maintenance run.
 * Copy and verify the full eight-column rows before deleting any source rows.
 */
function moriArchiveTable_(table,days,maxRows){return moriLock_(function(){
 moriEnsure_(['Bills','StockIn','Booking','Attendance','Audit'].indexOf(table)>=0,'Bảng không được lưu trữ');
 moriEnsure_(Number(days)>=1,'Số ngày lưu trữ không hợp lệ');maxRows=Math.min(500,Math.max(1,Math.floor(Number(maxRows)||500)));
 if((table==='Bills'||table==='StockIn')&&typeof moriAnalyticsCanArchive_==='function'&&!moriAnalyticsCanArchive_(table))return {table:table,moved:0,skipped:'Analytics chưa nạp hết hoặc đang có dữ liệu chờ tổng hợp'};
 if(table==='Bills'&&typeof moriCustomerCanArchive_==='function'&&!moriCustomerCanArchive_())return {table:table,moved:0,skipped:'Customer Analytics đang backfill hoặc đồng bộ; chưa thể lưu trữ Bills'};
 var sheet=moriSheet_(table),last=sheet.getLastRow(),cursorKey='ARCHIVE_CURSOR_3211_'+table,position=Math.max(2,Math.floor(Number(moriProp_(cursorKey))||2));
 if(last<2){moriSetProp_(cursorKey,2);return {table:table,moved:0,scanned:0};}if(position>last)position=2;
 var cutoff=Date.now()-Number(days)*86400000,eligible=[],scanned=0;
 while(position<=last&&scanned<2000&&eligible.length<maxRows){
  var count=Math.min(200,last-position+1,2000-scanned),rows=sheet.getRange(position,1,count,8).getValues();scanned+=count;
  for(var j=0;j<rows.length;j++){
   var row=rows[j],rowNumber=position++,d=moriDecode_(row);if(!d)continue;
   var time=new Date(d.updatedAt||d.createdAt||d.at).getTime();if(!Number.isFinite(time)||time>=cutoff)continue;
   var final=table==='Bills'?(d.channel==='ONLINE'?['DELIVERED','CANCELLED','REJECTED'].indexOf(d.orderStatus)>=0&&d.paymentStatus==='CONFIRMED':d.status==='PAID'||d.status==='CANCELLED'):
    table==='StockIn'?['CONFIRMED','CANCELLED','REJECTED'].indexOf(d.status)>=0:table==='Booking'?['COMPLETED','CANCELLED','REJECTED'].indexOf(d.status)>=0:table==='Attendance'?!!d.checkoutAt:true;
   if(final)eligible.push({row:rowNumber,values:row,doc:d});if(eligible.length>=maxRows)break;
  }
 }
 if(!eligible.length){moriSetProp_(cursorKey,position>last?2:position);return {table:table,moved:0,scanned:scanned,hasMore:position<=last};}
 var folder=DriveApp.getFolderById(moriProp_('FOLDER_ARCHIVE')),groups={};
 eligible.forEach(function(e){var month=String(e.doc.createdAt||e.doc.at||e.doc.updatedAt).slice(0,7),key=table+'_'+month;(groups[key]||(groups[key]=[])).push(e);});
 Object.keys(groups).forEach(function(name){
  var fileKey='ARCHIVE_'+name,fileId=moriProp_(fileKey),book;if(fileId)book=SpreadsheetApp.openById(fileId);else{book=SpreadsheetApp.create('MoriPOS_'+name);DriveApp.getFileById(book.getId()).moveTo(folder);moriSetProp_(fileKey,book.getId());}
  var dest=book.getSheets()[0],destLast=dest.getLastRow();if(destLast===0){dest.getRange(1,1,1,8).setValues([MORI_HEADERS]);destLast=1;}
  var index=Object.create(null);if(destLast>1)dest.getRange(2,1,destLast-1,1).getValues().forEach(function(r,j){index[String(r[0])]=j+2;});
  var missing=groups[name].filter(function(r){return !index[String(r.doc.id)];});
  if(missing.length){dest.getRange(destLast+1,1,missing.length,8).setValues(missing.map(function(x){return x.values;}));missing.forEach(function(x,j){index[String(x.doc.id)]=destLast+1+j;});}
  SpreadsheetApp.flush();
  var expected=groups[name].map(function(e){return {row:index[String(e.doc.id)],values:e.values};}).sort(function(a,b){return a.row-b.row;}),blocks=[];
  expected.forEach(function(e){var block=blocks[blocks.length-1];if(block&&block[0].row+block.length===e.row)block.push(e);else blocks.push([e]);});
  blocks.forEach(function(block){var actual=dest.getRange(block[0].row,1,block.length,8).getValues();block.forEach(function(e,j){
   moriEnsure_(e.values.every(function(value,k){return String(value)===String(actual[j][k]);}),'Archive verification failed: '+name+'/'+e.values[0]+'; dữ liệu gốc được giữ lại');
  });});
 });
 var clusters=[];eligible.sort(function(a,b){return b.row-a.row;}).forEach(function(r){var g=clusters[clusters.length-1];if(g&&r.row===g.low-1){g.low=r.row;g.count++;}else clusters.push({low:r.row,count:1});});
 // Reset before physical deletion. Even a partial delete failure is safe to retry.
 moriSetProp_(cursorKey,2);var moved=0;
 try{clusters.forEach(function(g){MORI_WRITE_DIRTY_=true;sheet.deleteRows(g.low,g.count);moved+=g.count;});}
 finally{moriClear_(table);}
 var next=position-moved;moriSetProp_(cursorKey,next>last-moved?2:Math.max(2,next));
 return {table:table,moved:moved,scanned:scanned,hasMore:position<=last};
});}
function moriInstallArchiveTrigger(){moriEditorOnly_();var fn='moriArchiveRun_';ScriptApp.getProjectTriggers().forEach(function(t){if(t.getHandlerFunction()===fn)ScriptApp.deleteTrigger(t);});ScriptApp.newTrigger(fn).timeBased().everyDays(1).atHour(2).create();return {ok:true,trigger:fn};}
