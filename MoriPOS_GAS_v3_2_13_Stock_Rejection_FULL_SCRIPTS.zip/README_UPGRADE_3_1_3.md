# MoriPOS 3.1.3 — sửa gợi ý tiền & định dạng nhập VND

## Sửa lỗi
- Mức tiền chọn từ gợi ý được đưa vào đúng model bằng sự kiện **input + change**, không đòi gõ phím hay refresh thủ công.
- Các ô **tiền tệ của Forecast** sử dụng kiểu nhập văn bản `inputmode=numeric`, tự thêm dấu chấm hàng nghìn ngay trong ô (ví dụ 1000 thành 1.000, 3000000 thành 3.000.000). Dữ liệu lưu vẫn là số nguyên VND; không thêm dấu chấm vào Google Sheets hoặc trường `data_json`.
- Các ô đã áp dụng: mục tiêu số tiền cố định, tiền phát sinh, tổng chi phí vận hành, lợi nhuận tham chiếu nhập tay, chi phí thêm/món, và giá bán giả định trong cả ba kịch bản. Các ô **%** và **số lượng** vẫn giữ dạng số thông thường.
- Nút gợi ý **sản lượng 80% / 100% / 120%** đã sửa ở v3.1.2: nếu thiếu lịch sử bán thì dùng số lượng **Cơ sở** bạn nhập làm mốc; nếu chưa nhập mốc sẽ hiện thông báo.
- Tiếp tục có phân rã doanh thu (đã bán vs. còn bán) và chi phí (giá vốn thực tế, giá vốn tương lai, phí thêm và vận hành), hiển thị rõ bảng tồn nguyên liệu / thành phẩm.

## Deploy
1. Sao lưu code Apps Script và dữ liệu Sheets.
2. Thay toàn bộ file `.gs` và `Index.html` theo gói; không upload `.md`, `tests/` hay `Original_UI_Offline.html`.
3. Bỏ `MoriPreflight312.gs` và `MoriPreflight311.gs` cũ nếu có; thay bằng `MoriPreflight313.gs`. Chạy `moriPreflight313()` và `moriFrontendCheck()`, cần `exactFileMatch:true` và build `3.1.3`.
4. Deploy → Manage deployments → Edit → New version → Deploy. Mở lại đường dẫn `/exec`.
5. Thử 3 ⇒ gợi ý 3.000/30.000/300.000; thử nhập 3000000 ⇒ tự hiển thị 3.000.000 và tổng Forecast cập nhật; nhập 35000 ở giá bán Cơ sở ⇒ 35.000; kiểm tra báo cáo chi phí.

Không chạy lại `moriSetup()`, `moriInstallOnce()` hoặc seed trên production. Không cần migrate Sheets.

**Giới hạn:** Định dạng trực tiếp này đang giới hạn ở phần **Forecast** để không ảnh hưởng các ô nhập tiền của hóa đơn và thanh toán. Phần nhập tiền các module khác có thể chuẩn hóa trong lần cập nhật riêng nếu cần.
