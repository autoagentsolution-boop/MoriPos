# Forecast, định lượng và Nhật ký

## Ví dụ nhập kg, bán theo định lượng g

| Nguyên liệu | Đơn vị cơ sở | Nhập | Giá cho đơn vị nhập | Giá vốn cơ sở |
| --- | --- | --- | ---: | ---: |
| Thịt bò | g | 1 kg | 100.000đ/kg | 100đ/g |
| Rau | kg | 1 kg | 20.000đ/kg | 20.000đ/kg |

Một Combo A gồm `100 g thịt + 100 g rau`, chi phí chế biến `3.000đ/phần`.

Giá vốn một phần = 100 × 100 + 0,1 × 20.000 + 3.000 = **15.000đ**. Bán 2 phần trừ 200 g thịt và 0,2 kg rau. Đơn vị nhập có thể khác đơn vị định lượng và đơn vị tồn; hệ thống quy đổi trước khi tính.

Hao hụt là phần dự phòng cộng thêm: `100 g, dự phòng 5%` tiêu hao 105 g. Không phải công thức hiệu suất thu hồi `100 / 95%`. Chi phí bao bì có thể là một thành phần theo dõi tồn hoặc chi phí thêm/đơn vị trong kế hoạch; tránh nhập cả hai để không tính trùng.

## Ba kịch bản mẫu

Giả sử chưa bán trong kỳ, đủ nguyên liệu như ví dụ, chi phí cố định cả kỳ 50.000đ, mục tiêu lợi nhuận 100.000đ; chưa có chi phí thêm ngoài công thức.

| Kịch bản | Sản lượng | Giá/phần | Doanh thu | Tổng chi phí | Lợi nhuận | So với mục tiêu |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Thận trọng | 5 | 35.000đ | 175.000đ | 125.000đ | 50.000đ | Thiếu 50.000đ |
| Cơ sở | 8 | 35.000đ | 280.000đ | 170.000đ | 110.000đ | Đạt |
| Tăng trưởng | 10 | 32.000đ | 320.000đ | 200.000đ | 120.000đ | Đạt, dùng hết nguyên liệu |

Ở kịch bản 5 phần, nếu giữ nguyên giá và chỉ tăng Combo A thì cần thêm 3 phần: mỗi phần đóng góp 20.000đ, bù được mức thiếu 50.000đ. Nếu vẫn chỉ bán 5 phần, giá cần đạt mục tiêu là 45.000đ/phần. Hệ thống nêu điều kiện tồn và nhịp bán để người dùng cân nhắc.

Gợi ý ưu tiên kịch bản đủ tồn, nhịp cần bán không vượt 120% nhịp tham chiếu khi có lịch sử, sau đó ưu tiên đạt mục tiêu và lợi nhuận cao hơn. Chưa có lịch sử thì phải tự nhập giả định; nút điền từ doanh số không bịa doanh số. Đây là so sánh giữa 3 phương án đã nhập, không phải tối ưu toàn bộ thị trường.

## Bốn cách đặt mục tiêu

| Chế độ | Ý nghĩa | Ví dụ |
| --- | --- | --- |
| Số tiền lợi nhuận | Doanh thu − toàn bộ chi phí đã nhập ≥ số tiền mục tiêu | Muốn lời 1.000.000đ trong kỳ |
| Lãi trên tổng chi phí | Lợi nhuận / tổng chi phí ≥ % | Chi phí 100.000đ, mục tiêu 20% → doanh thu 120.000đ |
| Biên lợi nhuận | Lợi nhuận / doanh thu ≥ % | Chi phí 100.000đ, mục tiêu 20% → doanh thu 125.000đ |
| Tăng lợi nhuận | Lợi nhuận ≥ mốc tham chiếu × (1 + %) | Mốc 1.000.000đ, tăng 20% → 1.200.000đ |

Mốc tăng trưởng phải dương. Có thể nhập mốc thủ công hoặc dùng kỳ trước có độ dài bằng kỳ đang lập, kết thúc trước ngày bắt đầu kế hoạch hoặc trước hôm nay nếu kế hoạch ở tương lai. Chi phí cố định và chi phí thêm của kỳ trước được ước tính bằng cấu hình của kế hoạch hiện tại; chưa phải sổ chi phí lịch sử.

Admin lưu mặc định để kế hoạch **mới** dùng lại. Các kế hoạch đã lưu giữ giả định riêng, không bị đổi theo mặc định mới. Xung đột khi hai người sửa cùng kế hoạch sẽ được báo để mở lại bản mới nhất.

## Cập nhật theo tình hình bán

- Sản lượng nhập là **tổng cả kỳ**, gồm đã bán + phần định bán tiếp. Nếu đã bán vượt kế hoạch, giữ nguyên số đã bán.
- Phần đã bán dùng doanh thu đã phân bổ giảm giá theo tỷ lệ giá trị dòng, không gồm tip; dùng giá vốn đã lưu trên bill. Giá giả định chỉ áp dụng cho phần chưa bán.
- Kỳ đã kết thúc chỉ hiển thị kết quả thực tế, không tự cộng phần sản lượng chưa bán.
- Chi phí thêm/đơn vị áp dụng theo giả định cho cả kỳ. Chi phí cố định của chỉ số “LN đến hiện tại” được phân bổ theo thời gian đã qua; dự kiến cả kỳ trừ toàn bộ chi phí cố định.
- Nhịp tham chiếu dùng N ngày hoàn tất trước hôm nay, theo giờ Việt Nam. “Điền SL từ tốc độ bán” lấy nhịp trung bình × số ngày trong kỳ × 80%/100%/120%; có thể sửa lại từng ô.
- Tồn khả dụng trừ nguyên liệu giữ cho đơn online và ngưỡng chặn tồn nếu đang bật. Các combo dùng chung nguyên liệu được cộng trước khi so với tồn.
- Tiền cần nhập ước tính theo giá vốn hiện tại của nguyên liệu thiếu; không cộng thêm vào giá vốn lần nữa. Giá mua mới, quy cách đóng gói và số lượng đặt tối thiểu cần người dùng kiểm tra.
- Forecast làm mới mỗi phút khi đang mở trang, hoặc theo nút cập nhật. Đổi kỳ/chi nhánh/số ngày tham chiếu thì phải tải đúng dữ liệu trước khi tính hoặc lưu.
- Chỉ tính bill đã PAID trong bảng SalesBills đang hoạt động, chưa gồm archive, đơn hủy hoặc chưa thanh toán. Chỉ tính những mặt hàng đã chọn, không đại diện tự động cho toàn cửa hàng.

## Nhật ký dễ đọc

Ví dụ một nhóm nhật ký:

| Nội dung | Trước | Sau |
| --- | --- | --- |
| Đơn giá · Combo A | 200.000 ₫ | 220.000 ₫ |
| Số lượng · Combo A | 1 | 2 |
| Khách hàng | Khách lẻ | Chị Mai |

Các thay đổi được ghi khi ô nhập/nút lưu đã xác nhận; không ghi từng ký tự đang gõ. Nhóm được gửi sau khoảng 1,8 giây không có chỉnh sửa mới. Nếu bấm thanh toán trước đó, nhóm chưa gửi đi cùng lượt lưu bill. Mã nhóm giúp tránh trùng khi phản hồi bị mất và người dùng thử lại.

Thời gian trên Nhật ký là thời gian máy chủ ghi nhận nhóm. Bản ghi “Sửa bill đang lập” thể hiện thao tác từ giao diện, kể cả khi bill chưa thanh toán. Bản ghi Thanh toán riêng chứa thông tin chốt từ máy chủ; giá riêng khác giá danh mục được ghi rõ. Bill nháp lưu lại cũng có các trường thay đổi trước/sau.

Nhóm chưa ghi hiển thị **Chờ ghi**; lỗi có nút **Ghi nhật ký còn chờ**. Nhóm chờ lưu trong sessionStorage của tài khoản trong cùng tab nếu trình duyệt cho phép. Nếu storage bị chặn, nhóm chỉ còn trong bộ nhớ trang; tải lại/đóng tab trước khi ghi có thể mất nhật ký chưa gửi. Không đóng tab khi đang chờ lưu bill hoặc nhật ký.

Dữ liệu audit vẫn lưu trong cột JSON hiện có để giữ tương thích. Giao diện chuyển thành tên hành động và bảng trước/sau; không hiển thị một khối JSON thô. Bản ghi cũ không có chi tiết đã được lưu từ trước chỉ có thể hiển thị thông tin sẵn có.
