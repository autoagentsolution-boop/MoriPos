/** Human-readable audit formatting. Raw structured changes remain available in Sheets. */
function moriAuditLabels_(){return {name:'Tên',price:'Giá bán',holidayPrice:'Giá ngày lễ',priceType:'Loại giá',unitPrice:'Đơn giá trên bill',catalogPriceAtAdd:'Giá danh mục',cost:'Giá vốn',qty:'Số lượng',quantity:'Số lượng',baseUnit:'Đơn vị cơ sở',unit:'Đơn vị',components:'Định lượng',items:'Mặt hàng',lines:'Chi tiết',customerId:'Khách hàng',customerName:'Tên khách hàng',phone:'Số điện thoại',email:'Email',address:'Địa chỉ',status:'Trạng thái',rejectionReason:'Lý do từ chối',rejectedAt:'Thời gian từ chối',rejectedBy:'Người từ chối',orderStatus:'Trạng thái đơn',paymentStatus:'Trạng thái thanh toán',shippingStatus:'Trạng thái giao hàng',method:'Phương thức thanh toán',discount:'Giảm giá (%)',discountFixed:'Giảm giá cố định',discountTotal:'Tổng giảm giá',tipAmount:'Tiền tip',finalTotal:'Tổng tiền',subtotal:'Tạm tính',paidAmountAtCheckout:'Số tiền đã thu',billEmployeeId:'Nhân viên phụ trách',employeeId:'Nhân viên thực hiện',tipEmployeeIds:'Nhân viên nhận tip',branchId:'Chi nhánh',role:'Vai trò',isActive:'Đang sử dụng',track:'Theo dõi tồn',type:'Loại',cat:'Danh mục',resource:'Bàn / ghế',modules:'Module',forecast:'Forecast',fixedCosts:'Chi phí cố định',goal:'Mục tiêu lợi nhuận',mode:'Cách tính',value:'Giá trị mục tiêu',baselineMode:'Cách chọn mốc',baselineProfit:'Lợi nhuận tham chiếu',lookbackDays:'Ngày tham chiếu',startDate:'Từ ngày',endDate:'Đến ngày',scenarios:'Kịch bản',extraCost:'Chi phí thêm mỗi đơn vị',processingCost:'Chi phí chế biến',wastePercent:'Hao hụt (%)',unitFactors:'Quy đổi đơn vị',monthlyRent:'Tiền thuê / tháng',monthlyOtherCost:'Chi phí khác / tháng',lowStockThreshold:'Ngưỡng tồn',lowStockPolicy:'Chính sách tồn',receipt:'Mẫu in',paidBillEditRoles:'Quyền sửa bill',bankAccount:'Tài khoản ngân hàng',bankName:'Ngân hàng',bankHolder:'Chủ tài khoản',shipping:'Giao hàng',note:'Ghi chú',published:'Công khai',stock:'Tồn kho',stockByBranch:'Tồn theo chi nhánh',costByBranch:'Giá vốn theo chi nhánh'};}
function moriAuditValue_(v,key){
 if(v===undefined||v===null||v==='')return '—';if(typeof v==='boolean')return v?'Có / Bật':'Không / Tắt';
 if(typeof v==='number'){var text=Number(v).toLocaleString('vi-VN',{maximumFractionDigits:6});if(/price|cost|amount|total|rent|salary|discountFixed|baselineProfit/i.test(key||''))return text+' ₫';if(/Percent|Rate|^discount$/i.test(key||''))return text+'%';return text;}
 var statuses={OPEN:'Đang mở',COMMITTING:'Đang ghi thanh toán',PAID:'Đã thanh toán',PENDING:'Chờ xử lý',SUBMITTED:'Chờ duyệt',APPLYING:'Đang nhập kho',REJECTED:'Đã từ chối',CONFIRMED:'Đã xác nhận',PENDING_CONFIRMATION:'Chờ xác nhận',PREPARING:'Đang chuẩn bị',SHIPPED:'Đang giao',DELIVERED:'Đã giao',CANCELLED:'Đã hủy',FULFILLED:'Đã giao, chưa thu tiền',CASH:'Tiền mặt',BANK_TRANSFER:'Chuyển khoản',COD:'Thu khi giao',ADMIN:'Quản trị',MANAGER:'Quản lý',EMPLOYEE:'Nhân viên',FIXED:'Số tiền cố định',MARKUP:'Lãi trên giá vốn',MARGIN:'Biên lợi nhuận',GROWTH:'Tăng so với kỳ trước',PREVIOUS:'Kỳ trước',MANUAL:'Nhập tay'};
 if(typeof v==='string')return statuses[v]||v.slice(0,500);
 if(Array.isArray(v))return v.length?v.slice(0,6).map(function(x){return typeof x==='object'?String(x.name||x.email||x.itemId||x.id||'Mục'):moriAuditValue_(x,key);}).join(', ')+(v.length>6?' … ('+v.length+' mục)':''):'Không có';
 if(v.name||v.email)return String(v.name||v.email);return Object.keys(v).slice(0,6).map(function(k){return (moriAuditLabels_()[k]||k)+': '+moriAuditValue_(v[k],k);}).join('; ');
}
function moriAuditRows_(changes){
 if(typeof changes==='string'){try{changes=JSON.parse(changes);}catch(_){return [{label:'Nội dung cũ',before:'—',after:'Không đọc được dữ liệu thay đổi cũ'}];}}
 var out=[],labels=moriAuditLabels_(),ignored=['version','createdAt','updatedAt','appliedOps','trackingToken','token','inventoryNeeds','inventoryConsumed','clientRequestId','requestId','auditBatches','lineKey'];
 function walk(before,after,key,label,depth){
  if(out.length>=80||JSON.stringify(before)===JSON.stringify(after)||ignored.indexOf(key)>=0)return;
  if(depth<4&&Array.isArray(before)&&Array.isArray(after)&&['items','lines','components','scenarios'].indexOf(key)>=0){
   var used={};after.forEach(function(x,j){var identity=x&&typeof x==='object'?(x.lineKey||x.itemId||x.id):j;var k=before.findIndex(function(b,i){return !used[i]&&b&&String(b.lineKey||b.itemId||b.id||i)===String(identity);});if(k>=0)used[k]=true;
    walk(k>=0?before[k]:null,x,key+'Row',label+' · '+(x?.name||x?.itemId||x?.id||j+1),depth+1);
   });before.forEach(function(x,i){if(!used[i])walk(x,null,key+'Row',label+' · '+(x?.name||x?.itemId||x?.id||i+1),depth+1);});return;
  }
  if(depth<4&&before&&after&&!Array.isArray(before)&&!Array.isArray(after)&&typeof before==='object'&&typeof after==='object'){
   Array.from(new Set(Object.keys(before).concat(Object.keys(after)))).forEach(function(k){walk(before[k],after[k],k,label+' · '+(labels[k]||k),depth+1);});return;
  }
  out.push({label:label,before:moriAuditValue_(before,key),after:moriAuditValue_(after,key)});
 }
 Object.keys(changes||{}).forEach(function(key){var v=changes[key];if(v&&typeof v==='object'&&('before' in v||'after' in v))walk(v.before,v.after,key,labels[key]||key,0);});return out;
}
function moriAuditDescribe_(action,entity,recordId,before,after){
 var entities={BILL:'bill',ONLINE_ORDER:'đơn online',ITEM:'mặt hàng',STOCKIN:'phiếu nhập',CUSTOMERS:'khách hàng',EMPLOYEES:'nhân viên',BRANCH:'chi nhánh',STORE:'cửa hàng',SETTINGS:'cài đặt',BOOKING:'đặt lịch',SHIPPING:'vận chuyển',ATTENDANCE:'chấm công',PUBLISH_SITE:'website',FORECAST:'kế hoạch',FORECAST_SETTINGS:'mục tiêu lợi nhuận'};
 var actions={CREATE:'Tạo',UPDATE:'Cập nhật',PAY:'Thanh toán',PAYMENT_CONFIRM:'Xác nhận thu tiền',CONFIRM:'Duyệt',REJECT:'Từ chối',STATUS:'Đổi trạng thái',UPDATE_TIP_ASSIGNMENT:'Sửa tip / nhân viên',CHECKIN:'Chấm vào',CHECKOUT:'Chấm ra',ENABLE:'Bật',BILL_EDIT:'Sửa bill đang lập'};
 var x=after||before||{},ref=x.no||x.code||x.name||String(recordId),description=(actions[action]||action)+' '+(entities[entity]||entity)+' '+ref,details=[];
 if(entity==='BILL'&&after){
  if(action==='PAY')description+=' · '+moriAuditValue_(after.finalTotal,'finalTotal');
  (after.items||[]).forEach(function(l){if(Number(l.unitPrice)!==Number(l.catalogPriceAtAdd)&&l.catalogPriceAtAdd!==undefined)details.push({label:'Giá chốt · '+l.name,before:moriAuditValue_(l.catalogPriceAtAdd,'unitPrice'),after:moriAuditValue_(l.unitPrice,'unitPrice')});});
 }
 return {description:description,details:details};
}
function moriAuditDisplay_(record){
 var labels={CREATE:'Tạo mới',UPDATE:'Cập nhật',PAY:'Thanh toán',CONFIRM:'Xác nhận',REJECT:'Từ chối',STATUS:'Đổi trạng thái',PAYMENT_CONFIRM:'Thu tiền',BILL_EDIT:'Sửa bill',UPDATE_TIP_ASSIGNMENT:'Sửa tip / nhân viên',ENABLE:'Bật module',CHECKIN:'Chấm vào',CHECKOUT:'Chấm ra'};
 return {title:record.description||moriAuditDescribe_(record.action,record.entity,record.recordId||record.id,null,null).description,action:labels[record.action]||record.action,rows:(record.details||[]).concat(moriAuditRows_(record.changes))};
}
