# MoriPOS v3.2.4 — Item Status & Holiday Pricing

## Changes

- Item editor: compact recipe hints, a sale status dropdown, optional holiday price.
- Items list: regular price, holiday price, quick toggle (Đang bán / Ngừng bán) and status filter.
- Settings → Mặt hàng: enable/disable special pricing; Settings → Lịch giá đặc biệt: Saturdays, Sundays, individual dates (one-off or yearly), inclusive date ranges.
- Checkout: server computes the appropriate local-day catalog price, and saves the line's `priceType` (`REGULAR`, `HOLIDAY`, or `MANUAL`). The existing explicit manual-price edit still works.
- Online: price is computed from holiday/regular price on the server and then online promotional rule is applied exactly once. Public product and checkout are consistent on the same day.
- An inactive item cannot be chosen for a new sale or Publish Site order. Existing paid bills, audit records, inventory and Analytics history are retained.

## Storage / Migration

No new Google Sheet is required. Existing generic `Items` rows store `holidayPrice` and `isActive` in `data_json`. The existing `Settings/global` row stores `holidayPricing` in `data_json`.

Existing items missing `isActive` are treated as active; items missing `holidayPrice` use regular price. Holiday pricing is disabled by default. All values are validated and saved via backend APIs. Do not manually add physical columns or rerun `moriSetup()`.

## Upgrade from v3.2.3

1. Backup Apps Script and the Google Sheets workbooks; preserve the last working deployment.
2. Replace: `Index.html`, `Code.gs`, `ApiRead.gs`, `Billing.gs`, `Operations.gs`, `AuditFormat.gs`.
3. Add: `HolidayPricing.gs`, `MoriPreflight324.gs`. Remove older preflight versions only if desired; keep all other production scripts unchanged.
4. Save Apps Script files. Run `moriPreflight324()` from the editor. Confirm `ok: true`, `version: 3.2.4`, `missing: []`, and frontend's `exactFileMatch: true`.
5. Deploy → Manage deployments → Edit → New version → Deploy. Verify `/exec` on a staging copy before production.
6. Open Settings → Lịch giá đặc biệt. Add a current-day rule for testing, enable it, save, and check POS/Public Site prices and a newly created test bill. Turn off the test rule once done.
7. Open Mặt hàng. Test temporarily stopping and resuming a sample item; verify it disappears/reappears on POS and Publish Site, while previous paid bills remain unchanged.

## Behavioral notes

- Weekend/holiday checks use `Asia/Ho_Chi_Minh` date, irrespective of the browser's timezone. Ranges include both endpoints. One-off date matches the exact year; annually recurring date matches month and day. Range entries are not repeated automatically each year.
- For existing OPEN drafts, manually entered unit price remains a bill-level price snapshot. A product marked inactive cannot be newly submitted for checkout; remove it from a draft when necessary. Existing PAID records are immutable for catalog pricing purposes.
- Forecast plans already saved are not repriced; item catalog and scenario assumptions can be updated separately.
- The Analytics data model does not change. Sales totals are computed from the actual unit prices stored in each bill.
- Public pricing is recalculated on the backend when orders are created. A public page left open across midnight should be refreshed so shown prices match the newly active rule.

## Testing

Run `node tests/run-tests.js` locally. There are 18 suites with 151 reported PASS groups, including 6 new dedicated checks for v3.2.4. This is not a claim of production testing on Google Apps Script.
