MoriPOS v3.2.6 - UI Action Feedback

- Changes: Index.html, Code.gs only
- New UI guard for API-backed actions and client-side double clicks; on-button spinner + persistent progress indicator; no automatic write retry
- Stable session-scoped request ID for repeated identical public order and public booking submissions
- Existing POS and Google Sheets data model unchanged
- 19 local simulation suites / 157 passing groups
- NOT production-tested: test on staging before deployment
