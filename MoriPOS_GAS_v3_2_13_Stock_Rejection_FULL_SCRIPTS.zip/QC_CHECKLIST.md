# Đối chiếu sau deploy — Mori POS 3.1.0

Thực hiện các giao dịch kiểm tra trên bộ dữ liệu thử riêng. Các mục dưới đây chưa được đánh dấu PASS trên project Google của người dùng.

## Cập nhật và quyền

- [ ] Đã thay đầy đủ source và thêm 5 file mới; deploy New version; tải lại tab.
- [ ] Admin thấy Forecast & Kế hoạch. Khởi tạo module tạo đúng một tab ForecastPlans; mở lại không tạo thêm dữ liệu.
- [ ] Manager chỉ mở/lưu kế hoạch trong chi nhánh được cấp. Employee không thấy/không gọi được API Forecast.
- [ ] Tắt/bật Forecast trong Cài đặt được lưu lại và có hiệu lực.
- [ ] Đăng nhập vẫn vào POS trước khi tải lịch sử. Đo vài lượt đầu và tiếp theo bằng MoriPerformance.

## Định lượng và tồn

- [ ] Tạo thịt bò đơn vị g, nhập 1 kg giá 100.000đ; duyệt xong tồn tăng 1.000 g, giá vốn 100đ/g.
- [ ] Tạo rau đơn vị kg; combo dùng 100 g rau quy đổi thành 0,1 kg.
- [ ] Tạo combo gồm nhiều nguyên liệu, chỉnh hao hụt/chi phí chế biến; preview giá vốn đúng.
- [ ] Thêm/xóa nhiều dòng thành phần; không mất dữ liệu của các dòng còn lại.
- [ ] Bán combo trừ đúng từng nguyên liệu; hai combo dùng chung nguyên liệu cộng đủ; không bán vượt tồn đã giữ.
- [ ] Sửa định lượng sau thanh toán không đổi giá vốn bill cũ.

## Forecast

- [ ] Chọn kỳ/chi nhánh, thêm nhiều mặt hàng, nhập 3 bộ sản lượng và giá; tổng chi phí gồm đúng chi phí thêm + cố định.
- [ ] Thử mục tiêu số tiền, markup, margin, tăng trưởng; phân biệt 20% chi phí với 20% doanh thu.
- [ ] Chưa có dữ liệu hoặc mốc tăng trưởng không dương có thông báo, không bịa kết quả bán.
- [ ] Lưu mục tiêu mặc định, tạo kế hoạch mới, mở lại kế hoạch cũ.
- [ ] Lưu kế hoạch, mở lại sau đăng nhập; hai tab sửa cùng phiên bản có báo xung đột.
- [ ] Thanh toán bill kiểm thử rồi cập nhật doanh số: phần thực tế tăng, phần cần bán giảm, giữ giá/cost của bill đã chốt.
- [ ] Bill có giảm giá và tip: doanh thu Forecast không cộng tip; giảm giá phân bổ đúng.
- [ ] Kỳ đã hết không cộng số chưa bán thành doanh thu; số đã bán vượt kế hoạch vẫn giữ đủ.
- [ ] Tổng nhu cầu nguyên liệu, phần thiếu và tiền nhập hợp lý; đọc rõ phạm vi mặt hàng/kỳ/chi nhánh và chưa gồm archive.

## Nhật ký

- [ ] Sửa đơn giá bằng nút lưu, change/blur và Enter; thấy đúng trước/sau, không ghi trùng do sự kiện lồng nhau.
- [ ] Sửa số lượng, khách, bàn/ghế, giảm giá, tip, nhân viên; mở Nhật ký thấy hành động có ý nghĩa.
- [ ] Chỉnh giá rồi thanh toán ngay: còn nhóm chờ vẫn được lưu, có audit thanh toán chốt giá.
- [ ] Thử mất kết nối trên dữ liệu kiểm thử: nhóm chờ hiển thị; thử ghi lại không trùng.
- [ ] Audit cũ được diễn giải thành bảng trước/sau; không cần đọc JSON thô.
- [ ] Kiểm tra giao diện Forecast/định lượng/Nhật ký trên desktop và điện thoại.
