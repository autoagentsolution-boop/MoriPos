# MoriPOS v3.2.11 — chỉnh sửa mặt hàng và tối ưu đọc/ghi/tải/xóa lịch sử

Gói full scripts, kế thừa v3.2.9 và phần chỉnh sửa mặt hàng của v3.2.10. Chưa triển khai lên Web App của bạn.

## Nâng cấp từ v3.2.9 hoặc v3.2.10

1. Thay đầy đủ 8 file cùng bản này trong Apps Script:
   - `Index.html`
   - `Code.gs`
   - `Operations.gs`
   - `ApiRead.gs`
   - `Data.gs`
   - `Config.gs`
   - `Inventory.gs`
   - `Archive.gs`
2. Lưu rồi chạy `moriFrontendCheck()` trong editor. Kết quả cần có build `3.2.11`, `ok: true` và `exactFileMatch: true`.
3. **Deploy → Manage deployments → Edit → New version → Deploy**, rồi tải lại trang Web App.

Không cần chạy lại Setup, tạo Sheet mới hay migrate dữ liệu. Không chép thư mục tests/docs, các file Markdown hoặc `Original_UI_Offline.html` vào Apps Script.

## Mặt hàng

- Form sửa cho phép đổi **Đơn vị gốc bán/tồn** và **Loại**: Sản phẩm, Dịch vụ, Combo, Nguyên liệu.
- **Danh mục hiện tại** có lọc danh mục kết hợp trạng thái bán, đếm kết quả và về trang đầu khi đổi bộ lọc. Lọc ngay trên dữ liệu đã tải, không gọi máy chủ mỗi lần chọn.
- Dropdown thành phần dùng cùng Mori style và đều có tìm kiếm. Định lượng của sản phẩm/dịch vụ vẫn giữ khi lưu và mở lại.
- Đổi đơn vị là sửa đơn vị khai báo: **giữ nguyên số lượng, giá và định lượng đã nhập**. Ví dụ sửa “cái” thành “phần”. Chọn kg → g không tự nhân tồn kho 1.000 lần hay chia giá. Form hiển thị nhắc kiểm tra giá trị theo đơn vị mới.
- Giữ kiểm tra công thức khi đổi Loại; không tự xóa thành phần. Nguyên liệu không nhận công thức con, Combo cần ít nhất một thành phần.

## Hiệu năng và đồng bộ dữ liệu

- Các thao tác dùng luồng lưu chung nhận ngay bản ghi đã xác nhận và những dòng liên quan trong cùng một phản hồi. Không tải lại cả nhóm dữ liệu sau lưu. API cũ vẫn trả kết quả theo cấu trúc cũ khi không yêu cầu phản hồi gọn.
- Phiếu nhập gộp các thay đổi cùng mặt hàng trong bộ nhớ và ghi các dòng liền nhau thành một lô. Giữ tính giá vốn bình quân, kiểm tra phiên bản và dấu chống cộng tồn hai lần khi thử lại.
- Gộp các yêu cầu tải đang trùng nhóm dữ liệu. Phản hồi cũ hoặc từ phiên đăng nhập trước bị bỏ qua. Bản danh mục đầy đủ mới loại các dòng không còn xuất hiện; cập nhật một vài dòng vẫn giữ các dòng khác.
- Nút Làm mới đọc trực tiếp dữ liệu mới. Cache danh mục có phiên bản và được làm mất hiệu lực sau khi ghi hoàn tất; dữ liệu cache không được dùng để duyệt ghi/tồn kho.
- Tìm đơn theo mã theo dõi và tìm yêu cầu đã xử lý dùng tìm kiếm chính xác trên Sheet, chỉ chuyển các dòng khớp vào mã xử lý. Đây không phải database index và vẫn chịu thời gian tìm kiếm của Sheets.
- Booking không chọn bàn/ghế bỏ qua bước đọc toàn bộ lịch để kiểm tra trùng tài nguyên.
- Lưu tài khoản nhận tiền chỉ gửi một lần lưu chi nhánh, không còn lệnh lưu cài đặt dư và không báo thành công trước xác nhận máy chủ.
- Loading nằm tại nút thao tác. Không tự gửi lại lệnh ghi khi mạng chậm.

## Lưu trữ và xóa lịch sử

Worker archive hiện có quét tối đa 2.000 dòng nguồn mỗi bảng mỗi lượt và lưu vị trí để tiếp tục lượt sau. Tối đa 500 dòng đủ điều kiện được chuyển trong một lượt. Bản ghi đang mở vẫn được giữ.

Worker sao chép, đọc lại và đối chiếu đủ 8 cột trước khi xóa nguồn. Các dòng liền nhau được xóa theo lô từ dưới lên. Khi xóa dở gặp lỗi, vị trí quét và bộ nhớ số dòng được đặt lại để lượt sau tiếp tục đúng; các bản sao đã có được dùng lại.

Nếu bản sao cùng ID có nội dung khác nguồn, worker báo lỗi xác minh và giữ dữ liệu nguồn để kiểm tra. Không ghi đè bản sao khác nội dung một cách im lặng. Bản này không thêm nút xóa vĩnh viễn mặt hàng; mặt hàng vẫn có trạng thái Ngừng bán. Không tự chạy hay cài trigger archive khi nâng cấp.

## Kiểm tra và giới hạn

Đã đạt **23 bộ kiểm thử / 193 nhóm kiểm tra** trên mô phỏng Node, DOM, RPC và Sheets. Xem `TEST_REPORT_3_2_11.md` và `tests/TEST_3211_RUN.log`.

Chưa chạy trên Web App/Google Sheets thực tế của bạn. Các số đo là số lời gọi/dòng đọc trong mô phỏng, không phải cam kết thời gian phản hồi. Không thay đổi công thức giá combo hoặc Forecast.

Sau triển khai, kiểm tra sửa mặt hàng → lưu → mở lại, lọc danh mục, tạo/duyệt phiếu nhập và Làm mới. `window.MoriPerformance` trong console ghi thời gian RPC phía trình duyệt và thời gian máy chủ trả về; chức năng đo đọc có sẵn `moriPerformanceProbe323()` chỉ chạy từ editor của chủ hệ thống.
