# MoriPOS v3.1.2 — Forecast calculation & UI repair

## Đã sửa
- Chọn nút gợi ý số tiền phải phát sự kiện **input** và **change**, để Forecast luôn cập nhật đúng. Khi nhập 3.000.000đ ở Chi phí phát sinh, ô tổng chi phí tự chuyển thành 3.000.000đ (cộng chi phí cơ sở).
- Mục tiêu lợi nhuận: Dropdown phương pháp và ô nhập tiền hoặc phần trăm nằm **cùng hàng**. Khi chọn % sẽ hiển thị trường Mức mục tiêu (%).
- Chi phí có bảng phân rã: giá vốn đã bán + giá vốn tương lai + chi phí thêm/đơn vị cho tổng sản lượng + chi phí vận hành. Doanh thu quá khứ theo bill, doanh thu tương lai theo giá kịch bản.
- Gợi ý 80% / 100% / 120%: Khi có lịch sử sẽ theo nhịp bán; nếu **chưa có lịch sử**, lấy số lượng ở cột **Cơ sở** mà người dùng nhập để nhân tỷ lệ. Nếu không có lịch sử và không nhập cơ sở, hiện thông báo rõ ràng chứ không im lặng.
- Không gắn nhãn "Đề xuất" cho kịch bản chưa đạt mục tiêu lợi nhuận; báo thiếu mục tiêu, yêu cầu điều chỉnh.
- Bảng tồn kho bổ sung: hiện Cần cho số chưa bán, Tồn khả dụng, Cần nhập, Tồn sau kế hoạch, Giá nhập/đơn vị, Tiền cần mua. Thành phẩm được ghi rõ để phân biệt nguyên liệu trong BOM.

## Minh họa từ ảnh của người dùng
- Kịch bản Cơ sở: Đã bán 2 ly, doanh thu lịch sử 42.000đ, định bán 15 ly cả kỳ ở mức 35.000đ/ly cho 13 ly còn lại -> 42.000 + 13 × 35.000 = **497.000đ**.
- Giá vốn quá khứ 22.000đ, tương lai 13 × 11.000 = 143.000đ, chi phí thêm 15 × 2.000 = 30.000đ. Trước khi cộng chi phí vận hành: **195.000đ**. Nếu nhập thêm **3.000.000đ** cho vận hành thì tổng chi phí là **3.195.000đ** và lãi dự kiến **-2.698.000đ** (nếu chi phí cơ sở là 0).
- Tồn sẵn có 32 ly, chỉ cần thêm 13 ly -> nhập thêm **0 ly**; tiền mua thêm **0đ**. Nếu muốn tính vật tư trà/đường/ly, khai báo sản phẩm thành Combo và định lượng các nguyên liệu.

## Cập nhật Google Apps Script
1. Backup project và spreadsheet hiện tại. Thay các file `.gs` và `Index.html` từ ZIP; không tải file test, báo cáo `.md` lên GAS.
2. Xóa file `MoriPreflight311.gs` cũ nếu tồn tại. Dùng `MoriPreflight312.gs`.
3. Chạy `moriPreflight312()` rồi `moriFrontendCheck()` trong Apps Script Editor; cần `ok:true` và `exactFileMatch:true`, version 3.1.2.
4. Deploy > Manage deployments > Edit > New version > Deploy, sau đó hard refresh `/exec`.
5. Kiểm tra bằng cách điền giá Cơ sở 35.000, SL 15; nhập Chi phí phát sinh 3.000.000, quan sát ô tổng và chi phí kịch bản cập nhật ngay. Thử bấm gợi ý số tiền và Gợi ý SL.

Không chạy `moriSetup`, `moriInstallOnce`, `moriSeedQC` trên dữ liệu production. Không cần migration Google Sheets.

**Lưu ý:** Chi phí tiền nhập kho là dòng tiền, không được cộng trùng vào giá vốn hàng đã bán. Độ chính xác lịch sử phụ thuộc dữ liệu bill, giá vốn, công thức nguyên liệu và chi phí vận hành.
