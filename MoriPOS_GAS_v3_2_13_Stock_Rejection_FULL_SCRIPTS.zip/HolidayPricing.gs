/** MoriPOS v3.2.4 — pricing calendar; all monetary decisions are server-authoritative. */
function moriHolidayDefaults_(){return {enabled:false,saturday:false,sunday:false,days:[],ranges:[]};}
function moriHolidayDateValid_(value){
 var s=String(value||'');if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;
 var y=Number(s.slice(0,4)),m=Number(s.slice(5,7)),d=Number(s.slice(8,10));
 var dt=new Date(Date.UTC(y,m-1,d));return dt.getUTCFullYear()===y&&dt.getUTCMonth()===m-1&&dt.getUTCDate()===d&&y>=2000&&y<=2100;
}
function moriHolidayConfig_(raw){
 var c=raw||{},out=moriHolidayDefaults_();out.enabled=c.enabled===true;out.saturday=c.saturday===true;out.sunday=c.sunday===true;
 moriEnsure_(Array.isArray(c.days||[])&&c.days.length<=90,'Tối đa 90 ngày đặc biệt');
 moriEnsure_(Array.isArray(c.ranges||[])&&c.ranges.length<=40,'Tối đa 40 khoảng ngày');
 out.days=(c.days||[]).map(function(x){var date=String(x.date||''),name=String(x.name||'Ngày đặc biệt').trim().slice(0,80);moriEnsure_(moriHolidayDateValid_(date),'Ngày lễ không hợp lệ');return {name:name,date:date,annual:x.annual===true,isActive:x.isActive!==false};});
 out.ranges=(c.ranges||[]).map(function(x){var startDate=String(x.startDate||''),endDate=String(x.endDate||''),name=String(x.name||'Đợt đặc biệt').trim().slice(0,80);moriEnsure_(moriHolidayDateValid_(startDate)&&moriHolidayDateValid_(endDate)&&endDate>=startDate,'Khoảng ngày không hợp lệ');return {name:name,startDate:startDate,endDate:endDate,isActive:x.isActive!==false};});
 return out;
}
function moriHolidayApplies_(config,localDate){
 var c=config||moriHolidayDefaults_(),day=String(localDate||moriDate_());if(c.enabled!==true||!moriHolidayDateValid_(day))return false;
 var weekDay=new Date(day+'T12:00:00Z').getUTCDay();
 if(weekDay===6&&c.saturday===true||weekDay===0&&c.sunday===true)return true;
 if((c.days||[]).some(function(x){return x.isActive!==false&&(x.annual===true?String(x.date).slice(5)===day.slice(5):x.date===day);} ))return true;
 return (c.ranges||[]).some(function(x){return x.isActive!==false&&x.startDate<=day&&day<=x.endDate;});
}
function moriItemPrice_(item,holidayConfig,day){
 var price=Number(item.price)||0,holiday=item.holidayPrice;
 if(moriHolidayApplies_(holidayConfig,day)&&holiday!==null&&holiday!==undefined&&holiday!==''&&Number.isFinite(Number(holiday))&&Number(holiday)>=0)
  return {price:Number(holiday),source:'HOLIDAY'};
 return {price:price,source:'REGULAR'};
}
/** Stored in Settings JSON: no new sheet and no migration necessary. */
function moriHolidaySettingsSave_(actor,payload){
 moriRequire_(actor,['ADMIN']);var old=moriFind_('Settings','global');moriEnsure_(old,'Chưa cấu hình cửa hàng');
 moriEnsure_(Number(payload.version)===Number(old.version),'Cài đặt đã được cập nhật. Tải lại trước khi lưu.');
 var doc=moriDeep_(old);doc.holidayPricing=moriHolidayConfig_(payload.config);
 doc=moriPut_('Settings',doc,old.version);
 moriAudit_(actor.email,'UPDATE','HOLIDAY_PRICING','global',old.holidayPricing||{},doc.holidayPricing);
 return {holidayPricing:doc.holidayPricing,version:doc.version};
}
