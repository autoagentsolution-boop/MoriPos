# MoriPOS v3.2.8 — Mori shared dropdown bugfix

Only runtime files changed: `Index.html` and `Code.gs`. Reuses original Mori dropdown primitives globally for the dropdowns affected in v3.2.7, including staff multi-select. Corrects unintended initial highlight/focus and removes per-field CSS variant. No Google Sheets migrations or changes to checkout, role validation, holiday pricing rules or other backend logic.
