/** Run from Apps Script editor under the owner account, after copying the project files. */
function moriInstallOnce(){
  var email=String(Session.getEffectiveUser().getEmail()||'').toLowerCase().trim();
  if(!email)throw new Error('Không đọc được email chủ; chạy từ Apps Script editor bằng tài khoản chính');
  return moriSetup(email);
}
