/** Mori 3.1.6 — durable, background-only materialized analytics.
 * Sales/StockIn write path adds a tiny sharded outbox entry in Script Properties.
 * The worker projects immutable economic contributions into AnalyticsLedger, then
 * rebuilds only affected branch-days in AnalyticsDaily. UI never scans raw Bills.
 * Recomputing days from ledger makes retries and edit/cancel moves idempotent.
 */
var MORI_ANALYTICS_PENDING_=Object.create(null);
var MORI_ANALYTICS_SHARDS_=16;
var MORI_ANALYTICS_META_KEY_='ANALYTICS_STATE_V1';
var MORI_ANALYTICS_HEADERS_=['id','branch_id','event_day','status','created_at','updated_at','version','data_json'];
function moriAnalyticsShard_(id){var s=String(id),h=0;for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;return h%MORI_ANALYTICS_SHARDS_;}
function moriAnalyticsQueueKey_(kind,shard){return 'ANALYTICS_QUEUE_'+(kind==='Bills'?'B':'S')+'_'+shard;}
function moriAnalyticsDayKey_(shard){return 'ANALYTICS_DAYS_'+shard;}
function moriAnalyticsPropObject_(key){try{return JSON.parse(moriProp_(key)||'{}')||{};}catch(e){throw Error('Analytics property corrupted '+key+': '+e.message);}}
function moriAnalyticsWritePropObject_(key,obj){var s=JSON.stringify(obj);moriEnsure_(s.length<8500,'Analytics queue property is full: '+key);moriSetProp_(key,s);}
function moriAnalyticsCaptureChange_(kind,doc){
 var key=kind+':'+String(doc.id),v=String(doc.version||1)+'@'+String(doc.updatedAt||'');
 MORI_ANALYTICS_PENDING_[key]={kind:kind,id:String(doc.id),version:v};
}
function moriAnalyticsFlushPending_(){
 var pending=Object.keys(MORI_ANALYTICS_PENDING_);if(!pending.length)return;
 var buckets=Object.create(null);
 pending.forEach(function(k){var e=MORI_ANALYTICS_PENDING_[k],pkey=moriAnalyticsQueueKey_(e.kind,moriAnalyticsShard_(e.id));(buckets[pkey]||(buckets[pkey]={}))[e.id]=e.version;});
 Object.keys(buckets).forEach(function(k){var current=moriAnalyticsPropObject_(k);Object.assign(current,buckets[k]);moriAnalyticsWritePropObject_(k,current);});
 MORI_ANALYTICS_PENDING_=Object.create(null);moriSetProp_('ANALYTICS_PENDING_FLAG','1');
}
function moriAnalyticsQueued_(limit){
 var out=[];
 ['Bills','StockIn'].forEach(function(kind){for(var shard=0;shard<MORI_ANALYTICS_SHARDS_;shard++){
  if(out.length>=limit)return;var k=moriAnalyticsQueueKey_(kind,shard),obj=moriAnalyticsPropObject_(k);
  Object.keys(obj).slice(0,Math.max(0,limit-out.length)).forEach(function(id){out.push({kind:kind,id:id,version:obj[id],queueKey:k});});
 }});return out;
}
function moriAnalyticsQueueHas_(kind){
 var tables=kind?[kind]:['Bills','StockIn'];return tables.some(function(k){for(var i=0;i<MORI_ANALYTICS_SHARDS_;i++)if(Object.keys(moriAnalyticsPropObject_(moriAnalyticsQueueKey_(k,i))).length)return true;return false;});
}
function moriAnalyticsAck_(processed){
 if(!processed.length)return;var lock=LockService.getScriptLock();moriEnsure_(lock.tryLock(3000),'Analytics outbox đang cập nhật; sẽ thử lại');
 try{var buckets={};processed.forEach(function(e){(buckets[e.queueKey]||(buckets[e.queueKey]=[])).push(e);});
  Object.keys(buckets).forEach(function(k){var obj=moriAnalyticsPropObject_(k),changed=false;
   buckets[k].forEach(function(e){if(obj[e.id]===e.version){delete obj[e.id];changed=true;}});if(changed)moriAnalyticsWritePropObject_(k,obj);
  });
 }finally{lock.releaseLock();}
}
function moriAnalyticsDayId_(branch,day){return String(branch)+'|'+day;}
function moriAnalyticsMarkDays_(dayIds){
 var groups={};dayIds.forEach(function(id){if(!id)return;var k=moriAnalyticsDayKey_(moriAnalyticsShard_(id));(groups[k]||(groups[k]={}))[id]=1;});
 Object.keys(groups).forEach(function(k){var obj=moriAnalyticsPropObject_(k);Object.assign(obj,groups[k]);moriAnalyticsWritePropObject_(k,obj);});
}
function moriAnalyticsPendingDays_(limit){var out=[];for(var i=0;i<MORI_ANALYTICS_SHARDS_&&out.length<limit;i++){
 var key=moriAnalyticsDayKey_(i),obj=moriAnalyticsPropObject_(key);Object.keys(obj).slice(0,limit-out.length).forEach(function(id){out.push({id:id,key:key});});
 }return out;}
function moriAnalyticsAckDays_(ids){if(!ids.length)return;var groups={};ids.forEach(function(d){(groups[d.key]||(groups[d.key]=[])).push(d.id);});
 Object.keys(groups).forEach(function(key){var obj=moriAnalyticsPropObject_(key);groups[key].forEach(function(id){delete obj[id];});moriAnalyticsWritePropObject_(key,obj);});
}
function moriAnalyticsDashboardReady_(){return !!moriProp_('FILE_DASHBOARD')&&moriProp_('ANALYTICS_DASHBOARD_READY')==='1';}
function moriAnalyticsReady_(){return moriAnalyticsDashboardReady_()&&!!moriAnalyticsState_().ready;}
function moriAnalyticsState_(){try{return JSON.parse(moriProp_(MORI_ANALYTICS_META_KEY_)||'null')||{installed:false,ready:false,sourceIndex:0,cursor:2};}catch(e){throw Error('Analytics state corrupted: '+e.message);}}
function moriAnalyticsSaveState_(state){moriSetProp_(MORI_ANALYTICS_META_KEY_,JSON.stringify(state));}
function moriAnalyticsRequireReady_(){
 moriEnsure_(moriAnalyticsDashboardReady_(),'POS_Dashboard chưa được khởi tạo/chuyển dữ liệu. Owner chạy moriAnalyticsInstall() trong Apps Script Editor.');
 var s=moriAnalyticsState_();moriEnsure_(s.installed&&s.ready,'AnalyticsDaily chưa hoàn tất đồng bộ lịch sử. Owner chạy moriAnalyticsSyncNow() hoặc chờ trigger định kỳ; kiểm tra moriAnalyticsStatus().');
 moriEnsure_(moriProp_('ANALYTICS_REPAIR_REQUIRED')!=='1','Analytics outbox cần đối soát, tạm dừng Forecast để tránh báo cáo sai.');
 return Object.assign({},s,{hasPendingChanges:moriProp_('ANALYTICS_PENDING_FLAG')==='1'});
}
/** Verifies the server-side worksheet copy without loading entire analytics history.
 * No source data are deleted. The source must remain unchanged while migration holds
 * the analytics worker lease; POS writes continue to enqueue changes, not update ledger.
 */
function moriAnalyticsVerifyCopy_(source,target,name){
 var srcLast=source.getLastRow(),dstLast=target.getLastRow();
 moriEnsure_(srcLast===dstLast,'POS_Dashboard '+name+' không khớp số dòng với POS_Master ('+srcLast+' / '+dstLast+'). Không chuyển nguồn đọc.');
 var checkpoints=srcLast<=1?[1]:[1,2,Math.max(2,Math.floor(srcLast/2)),srcLast];
 checkpoints.filter(function(n,i,arr){return arr.indexOf(n)===i;}).forEach(function(row){
  var x=source.getRange(row,1,1,8).getValues()[0],y=target.getRange(row,1,1,8).getValues()[0];
  moriEnsure_(JSON.stringify(x)===JSON.stringify(y),'POS_Dashboard '+name+' không khớp dòng '+row+'. Nguồn cũ vẫn được giữ nguyên.');
 });
}
/** Creates a dedicated POS_Dashboard spreadsheet and copies legacy MASTER tabs
 * once. The routing flag is the commit point. Subsequent executions never write
 * to POS_Master Analytics tables. Safe to retry after a partial migration.
 */
function moriAnalyticsPrepareDashboard_(){
 var id=moriProp_('FILE_DASHBOARD'),book,created=false;
 if(id){book=MORI_BOOK_HANDLES_.DASHBOARD||(MORI_BOOK_HANDLES_.DASHBOARD=SpreadsheetApp.openById(id));}
 else{
  book=SpreadsheetApp.create('POS_Dashboard');created=true;
  moriSetProp_('FILE_DASHBOARD',book.getId());MORI_BOOK_HANDLES_.DASHBOARD=book;
  var rootId=moriProp_('ROOT_FOLDER');if(rootId)DriveApp.getFileById(book.getId()).moveTo(DriveApp.getFolderById(rootId));
 }
 var committed=moriProp_('ANALYTICS_DASHBOARD_READY')==='1';
 var masterId=moriProp_('FILE_MASTER');moriEnsure_(masterId,'Thiếu FILE_MASTER');
 var master=MORI_BOOK_HANDLES_.MASTER||(MORI_BOOK_HANDLES_.MASTER=SpreadsheetApp.openById(masterId));
 moriEnsure_(book.getId()!==master.getId(),'FILE_DASHBOARD không được trỏ vào POS_Master');
 var moved={},sourceCount={},targetCount={};
 ['AnalyticsLedger','AnalyticsDaily'].forEach(function(table){
  var source=master.getSheetByName(table),target=book.getSheetByName(table);
  var hasLegacy=!!(source&&source.getLastRow()>1);
  if(!committed&&hasLegacy){
   if(!target||target.getLastRow()<=1){
    // Copy into a temporary sheet, verify before replacing any empty template.
    var copy=source.copyTo(book);
    try{
     copy.setName('__MIGRATE_'+table+'_'+Utilities.getUuid().slice(0,8));
     moriAnalyticsVerifyCopy_(source,copy,table);
     if(target){moriEnsure_(target.getLastRow()<=1,'Analytics target was populated concurrently');book.deleteSheet(target);}
     copy.setName(table);target=copy;moved[table]=true;
    }catch(e){
     // Remove only the new temporary copy on failure; original and existing
     // destination are never deleted unless verification has already passed.
     try{if(copy&&copy.getName().indexOf('__MIGRATE_')===0)book.deleteSheet(copy);}catch(_){ }
     throw e;
    }
   }else{moriAnalyticsVerifyCopy_(source,target,table);}
  }
  if(!target){target=book.insertSheet(table);}
  if(target.getLastRow()===0){target.getRange(1,1,1,8).setValues([MORI_ANALYTICS_HEADERS_]);target.setFrozenRows(1);target.getRange('A:A').setNumberFormat('@');target.getRange('H:H').setNumberFormat('@');}
  var header=target.getRange(1,1,1,8).getValues()[0];
  moriEnsure_(JSON.stringify(header)===JSON.stringify(MORI_ANALYTICS_HEADERS_),'Header '+table+' trong POS_Dashboard không chính xác; không đổi dữ liệu.');
  sourceCount[table]=source?Math.max(0,source.getLastRow()-1):0;
  targetCount[table]=Math.max(0,target.getLastRow()-1);
  MORI_SHEET_HANDLES_[table]=target;
 });
 // New spreadsheet usually contains an unused default sheet.
 var blank=book.getSheetByName('Sheet1');if(blank&&blank.getLastRow()===0&&book.getSheets().length>1)book.deleteSheet(blank);
 // Do not publish until both target sheets are complete and header-verified.
 moriSetProp_('ANALYTICS_DASHBOARD_READY','1');
 // Force all remaining execution-local handles to target the new physical file.
 delete MORI_DATA_STATE_.AnalyticsLedger;delete MORI_DATA_STATE_.AnalyticsDaily;
 return {spreadsheetId:book.getId(),url:book.getUrl?book.getUrl():'https://docs.google.com/spreadsheets/d/'+book.getId()+'/edit',created:created,moved:moved,sourceRows:sourceCount,targetRows:targetCount,legacyBackupInMaster:sourceCount.AnalyticsLedger>0||sourceCount.AnalyticsDaily>0};
}
function moriAnalyticsInstall(){
 moriEditorOnly_();moriEnsure_(moriProp_('READY')==='1','Cần cài MoriPOS trước');
 var lease=moriAnalyticsTakeLease_();moriEnsure_(lease,'Analytics đang chạy. Thử lại sau khi worker hiện tại kết thúc.');
 try{
  var dashboard=moriAnalyticsPrepareDashboard_();
  var state=moriAnalyticsState_();if(!state.installed){state={installed:true,ready:false,sourceIndex:0,cursor:2,startedAt:moriNow_(),lastMaterializedAt:null};moriAnalyticsSaveState_(state);}
  var triggers=ScriptApp.getProjectTriggers().filter(function(t){return t.getHandlerFunction()==='moriAnalyticsWorker_';});
  if(!triggers.length)ScriptApp.newTrigger('moriAnalyticsWorker_').timeBased().everyMinutes(5).create();
  ScriptApp.getProjectTriggers().forEach(function(t){if(t.getHandlerFunction()==='moriForecastWarmup_')ScriptApp.deleteTrigger(t);});
  return {ok:true,installed:true,ready:!!state.ready,trigger:'moriAnalyticsWorker_',existingTrigger:triggers.length>0,tables:['AnalyticsLedger','AnalyticsDaily'],dashboard:dashboard};
 }finally{moriAnalyticsReleaseLease_(lease);}
}
/** Existing archives are included in the one-time backfill, not reread on UI requests. */
function moriAnalyticsSources_(){
 var all=PropertiesService.getScriptProperties().getProperties(),arr=[];
 ['Bills','StockIn'].forEach(function(kind){
  Object.keys(all).filter(function(k){return k.indexOf('MORI_ARCHIVE_'+kind+'_')===0;}).sort().forEach(function(k){arr.push({key:kind+'|'+k,kind:kind,archiveId:all[k]});});
  arr.push({key:kind+'|ACTIVE',kind:kind});
 });return arr;
}
function moriAnalyticsSourceSheet_(s){
 if(!s.archiveId)return moriSheet_(s.kind);
 var book=SpreadsheetApp.openById(s.archiveId),sheets=book.getSheets();moriEnsure_(sheets.length,'Archive spreadsheet without a sheet');return sheets[0];
}
function moriAnalyticsFingerprint_(doc){
 var raw=JSON.stringify(doc),bytes=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,raw,Utilities.Charset.UTF_8);
 return bytes.map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2);}).join('');
}
function moriAnalyticsBillEntries_(bill,index){
 if(!bill||bill.status!=='PAID')return {day:'',entries:[]};
 var when=new Date(bill.paidAt||bill.createdAt);if(!Number.isFinite(when.getTime())||when.getTime()>Date.now())return {day:'',entries:[]};
 var day=moriDate_(when),id=String(bill.id),branch=Number(bill.branchId),out=[{itemId:'__BILLS__',kind:'BILLS_COUNT',paidBillCount:1,paidAt:when.toISOString()}];
 var lines=bill.items||[],subtotal=lines.reduce(function(n,l){return n+Math.max(0,Number(l.qty)||0)*Math.max(0,Number(l.unitPrice)||0);},0);
 var discount=bill.discountTotal!==undefined?Number(bill.discountTotal):Math.max(0,subtotal-(Number(bill.finalTotal??subtotal)-Number(bill.tipAmount||0)));
 discount=Math.min(subtotal,Math.max(0,discount||0));var byItem={};
 lines.forEach(function(l){var itemId=String(l.id),qty=Number(l.qty)||0;if(qty<=0)return;
  var x=byItem[itemId]||(byItem[itemId]={itemId:itemId,kind:'SALES_ITEM',qty:0,revenue:0,cost:0,estimatedCostLines:0});
  var unitCost,estimated=false;if(l.cost!==undefined&&l.cost!==null&&Number.isFinite(Number(l.cost)))unitCost=Number(l.cost);
  else{estimated=true;try{unitCost=moriRecipe_(itemId,index,branch,1).cost;}catch(_){unitCost=0;}}
  x.qty+=qty;x.revenue+=qty*(Number(l.unitPrice)||0)*(subtotal>0?1-discount/subtotal:0);x.cost+=qty*unitCost;
  if(estimated)x.estimatedCostLines++;
 });
 return {day:day,entries:out.concat(Object.keys(byItem).map(function(k){return byItem[k];}))};
}
function moriAnalyticsStockEntries_(receipt){
 if(!receipt||receipt.status!=='CONFIRMED')return {day:'',entries:[]};
 var when=new Date(receipt.confirmedAt||receipt.date||receipt.createdAt||'');if(!Number.isFinite(when.getTime()))return {day:'',entries:[]};
 var value=Number(receipt.totalCost??receipt.total);if(!Number.isFinite(value)||value<0)return {day:'',entries:[]};
 return {day:moriDate_(when),entries:[{itemId:'__STOCK__',kind:'STOCK_CASH',purchaseAmount:value,receiptCount:1}]};
}
/** One column ID index per worker execution. Avoid N Google Sheets TextFinder
 * requests while projecting hundreds of rows. No index is built in POS requests. */
function moriAnalyticsPrimeIndex_(table){
 var st=moriState_(table);if(st.analyticsIndexComplete)return;
 var last=moriLastRow_(table);
 if(last>=2)moriSheet_(table).getRange(2,1,last-1,1).getValues().forEach(function(r,i){
  if(!r[0])return;var id=String(r[0]);if(!Object.prototype.hasOwnProperty.call(st.entries,id))st.entries[id]={row:i+2,doc:null};
 });
 st.analyticsIndexComplete=true;
}
/** Idempotent batch projection: record affected days durably BEFORE updating ledger. */
function moriAnalyticsProjectBatch_(records){
 if(!records.length)return {processed:0,skipped:0,dirty:0};
 moriAnalyticsPrimeIndex_('AnalyticsLedger');
 var unique={},updated=[],created=[],dirty={},index=null,skipped=0;
 records.forEach(function(rec){
  var key=(rec.kind==='Bills'?'B':'S')+'|'+String(rec.id);if(unique[key])return;unique[key]=true;
  var old=moriFind_('AnalyticsLedger',key),fingerprint=rec.doc?moriAnalyticsFingerprint_(rec.doc):'DELETED';
  if(old&&old.fingerprint===fingerprint){skipped++;return;}
  var projection=rec.kind==='Bills'?moriAnalyticsBillEntries_(rec.doc,index||(index=moriItemIndex_())):moriAnalyticsStockEntries_(rec.doc);
  var branch=Number(rec.doc?.branchId||old?.branchId||0),d={id:key,branchId:branch,email:projection.day||'',status:projection.entries.length?'INCLUDED':'EXCLUDED',sourceKind:rec.kind,sourceId:String(rec.id),day:projection.day,fingerprint:fingerprint,entries:projection.entries};
  if(old?.day)dirty[moriAnalyticsDayId_(old.branchId,old.day)]=1;
  if(d.day)dirty[moriAnalyticsDayId_(branch,d.day)]=1;
  if(old)updated.push({doc:d,expectedVersion:old.version});else created.push(d);
 });
 moriAnalyticsMarkDays_(Object.keys(dirty));
 if(updated.length)moriPutMany_('AnalyticsLedger',updated);
 if(created.length)moriInsertMany_('AnalyticsLedger',created);
 return {processed:updated.length+created.length,skipped:skipped,dirty:Object.keys(dirty).length};
}
/** Sparse read: find ledger projections for ONE day by its indexed metadata column C.
 * This is a background computation, and does not scan raw POS transactions.
 */
function moriAnalyticsLedgerDay_(branchId,day){
 var last=moriSheet_('AnalyticsLedger').getLastRow();if(last<2)return [];
 var rows=moriSheet_('AnalyticsLedger').getRange(2,3,last-1,1).createTextFinder(day).matchCase(true).matchEntireCell(true).findAll().map(function(c){return c.getRow();}).sort(function(a,b){return a-b;});
 return moriAnalyticsReadSparseJson_('AnalyticsLedger',rows).filter(function(x){return Number(x.branchId)===Number(branchId)&&x.day===day;});
}
function moriAnalyticsReadSparseJson_(table,rows){
 var groups=[],out=[];rows.forEach(function(row){var g=groups[groups.length-1];if(g&&g.first+g.count===row)g.count++;else groups.push({first:row,count:1});});
 groups.forEach(function(g){moriSheet_(table).getRange(g.first,8,g.count,1).getValues().forEach(function(r){try{if(r[0])out.push(JSON.parse(r[0]));}catch(e){throw Error('Invalid Analytics JSON at '+table+' row '+g.first);}});});return out;
}
function moriAnalyticsExistingDaily_(branchId,day){
 var last=moriSheet_('AnalyticsDaily').getLastRow();if(last<2)return [];
 var prefix=String(branchId)+'|'+day+'|',regexp='^'+prefix.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 var rows=moriSheet_('AnalyticsDaily').getRange(2,1,last-1,1).createTextFinder(regexp).matchCase(true).useRegularExpression(true).findAll().map(function(c){return c.getRow();}).sort(function(a,b){return a-b;});
 return moriAnalyticsReadSparseJson_('AnalyticsDaily',rows);
}
function moriAnalyticsRebuildDay_(id){
 var parts=id.split('|'),branchId=Number(parts[0]),day=parts[1];moriEnsure_(branchId>0&&/^\d{4}-\d\d-\d\d$/.test(day),'Invalid dirty day '+id);
 moriAnalyticsPrimeIndex_('AnalyticsDaily');
 var ledgers=moriAnalyticsLedgerDay_(branchId,day),next={};
 ledgers.forEach(function(ledger){(ledger.entries||[]).forEach(function(e){
  var key=String(e.itemId),r=next[key]||(next[key]={id:String(branchId)+'|'+day+'|'+key,branchId:branchId,day:day,email:day,itemId:key,kind:e.kind,qty:0,revenue:0,cost:0,estimatedCostLines:0,paidBillCount:0,receiptCount:0,purchaseAmount:0,lastPaidAt:null});
  ['qty','revenue','cost','estimatedCostLines','paidBillCount','receiptCount','purchaseAmount'].forEach(function(field){r[field]+=Number(e[field])||0;});
  if(e.paidAt&&(!r.lastPaidAt||e.paidAt>r.lastPaidAt))r.lastPaidAt=e.paidAt;
 });});
 var old=moriAnalyticsExistingDaily_(branchId,day),updates=[],inserts=[],oldById={};old.forEach(function(x){oldById[x.id]=x;});
 Object.keys(oldById).forEach(function(k){if(!next[oldById[k].itemId]){var x=oldById[k];next[x.itemId]={id:x.id,branchId:branchId,day:day,email:day,itemId:x.itemId,kind:x.kind,qty:0,revenue:0,cost:0,estimatedCostLines:0,paidBillCount:0,receiptCount:0,purchaseAmount:0,lastPaidAt:null};}});
 Object.keys(next).forEach(function(k){var x=next[k],before=oldById[x.id];x.status=(x.qty||x.paidBillCount||x.receiptCount)?'ACTIVE':'EMPTY';if(before){
  var fields=['qty','revenue','cost','estimatedCostLines','paidBillCount','receiptCount','purchaseAmount','lastPaidAt','status'];
  if(fields.every(function(f){return JSON.stringify(before[f]??null)===JSON.stringify(x[f]??null);}))return;
  updates.push({doc:x,expectedVersion:before.version});
 }else inserts.push(x);});
 if(updates.length)moriPutMany_('AnalyticsDaily',updates);
 if(inserts.length)moriInsertMany_('AnalyticsDaily',inserts);
 return {day:day,branchId:branchId,ledgers:ledgers.length,writes:updates.length+inserts.length};
}
function moriAnalyticsDailyRead_(branchId,start,end){
 var last=moriSheet_('AnalyticsDaily').getLastRow();if(last<2)return [];
 // For the normal 7/28-day plan, filter matching month IDs server-side and
 // fetch only the matching JSON cells. Annual reports can read one JSON column.
 var months=[],cursor=start.slice(0,7),lastMonth=end.slice(0,7);
 while(cursor<=lastMonth&&months.length<=13){months.push(cursor);var y=Number(cursor.slice(0,4)),m=Number(cursor.slice(5,7));cursor=(m===12?y+1:y)+'-'+('0'+(m===12?1:m+1)).slice(-2);}
 var docs;
 if(months.length<=6){
  var prefix='^'+String(branchId)+'\\|(?:'+months.join('|')+')-\\d{2}\\|';
  var rows=moriSheet_('AnalyticsDaily').getRange(2,1,last-1,1).createTextFinder(prefix).matchCase(true).useRegularExpression(true).findAll().map(function(c){return c.getRow();}).sort(function(a,b){return a-b;});
  docs=moriAnalyticsReadSparseJson_('AnalyticsDaily',rows);
 }else{
  docs=moriSheet_('AnalyticsDaily').getRange(2,8,last-1,1).getValues().map(function(r){if(!r[0])return null;try{return JSON.parse(r[0]);}catch(e){throw Error('AnalyticsDaily có dòng JSON không hợp lệ');}}).filter(Boolean);
 }
 return docs.filter(function(x){return x&&Number(x.branchId)===Number(branchId)&&x.day>=start&&x.day<=end;});
}
function moriAnalyticsBackfillBatch_(state,limit){
 var sources=moriAnalyticsSources_(),done=0,read=0;
 while(state.sourceIndex<sources.length&&read<limit){
  var src=sources[state.sourceIndex],sheet=moriAnalyticsSourceSheet_(src),last=sheet.getLastRow(),cursor=Math.max(2,Number(state.cursor)||2);
  if(last<cursor){state.sourceIndex++;state.cursor=2;continue;}
  var n=Math.min(last-cursor+1,limit-read),rows=sheet.getRange(cursor,8,n,1).getValues();read+=n;
  var docs=rows.map(function(r){if(!r[0])return null;try{return JSON.parse(r[0]);}catch(e){throw Error('Raw historical JSON invalid: '+src.key+' row '+cursor);}}).filter(Boolean);
  moriAnalyticsProjectBatch_(docs.map(function(doc){return {kind:src.kind,id:String(doc.id),doc:doc};}));
  done+=docs.length;state.cursor=cursor+n;
  // Cursor is advanced only after the durable ledger write; retries are idempotent.
  moriAnalyticsSaveState_(state);
  if(state.cursor>last){state.sourceIndex++;state.cursor=2;}
 }
 return {read:read,projected:done,finished:state.sourceIndex>=sources.length,sources:sources.length};
}
function moriAnalyticsTakeLease_(){
 var lock=LockService.getScriptLock();if(!lock.tryLock(2000))return null;
 try{var old=Number(moriProp_('ANALYTICS_LEASE_UNTIL')||0),now=Date.now();if(old>now)return null;
  var id=Utilities.getUuid();moriSetProp_('ANALYTICS_LEASE_UNTIL',String(now+360000));moriSetProp_('ANALYTICS_LEASE_ID',id);return id;
 }finally{lock.releaseLock();}
}
function moriAnalyticsReleaseLease_(id){var lock=LockService.getScriptLock();if(!lock.tryLock(2000))return;
 try{if(moriProp_('ANALYTICS_LEASE_ID')===id)moriSetProp_('ANALYTICS_LEASE_UNTIL','0');}finally{lock.releaseLock();}}
function moriAnalyticsSyncCore_(){
 moriEnsure_(moriAnalyticsDashboardReady_(),'Chưa chuyển Analytics sang POS_Dashboard. Owner chạy moriAnalyticsInstall().');
 var state=moriAnalyticsState_();moriEnsure_(state.installed,'Chạy moriAnalyticsInstall() trong Editor trước');
 var lease=moriAnalyticsTakeLease_();if(!lease)return {ok:true,skipped:'Có một lượt tổng hợp đang chạy'};
 try{
  var changeItems=moriAnalyticsQueued_(60),raw=[];
  changeItems.forEach(function(e){raw.push({kind:e.kind,id:e.id,doc:moriFind_(e.kind,e.id)});});
  var changes=moriAnalyticsProjectBatch_(raw);
  if(changeItems.length)moriAnalyticsAck_(changeItems);
  var backfill={read:0,projected:0,finished:true};
  if(!state.ready||!state.backfillComplete){backfill=moriAnalyticsBackfillBatch_(state,160);state.backfillComplete=backfill.finished;}
  var dirty=moriAnalyticsPendingDays_(12),rebuilt=[];
  dirty.forEach(function(e){rebuilt.push(moriAnalyticsRebuildDay_(e.id));moriAnalyticsAckDays_([e]);});
  // First publication must wait until all historical days have been materialized.
  // Once published, new writes may lag by one worker interval, but do not hide reports.
  if(!state.ready)state.ready=!!state.backfillComplete&&!moriAnalyticsQueueHas_()&&!moriAnalyticsPendingDays_(1).length;
  if(state.ready&&moriProp_('ANALYTICS_REPAIR_REQUIRED')==='1'&&!moriAnalyticsQueueHas_()&&!moriAnalyticsPendingDays_(1).length)moriSetProp_('ANALYTICS_REPAIR_REQUIRED','0');
  if(rebuilt.length)state.lastMaterializedAt=moriNow_();state.lastRunAt=moriNow_();
  moriSetProp_('ANALYTICS_PENDING_FLAG',moriAnalyticsQueueHas_()||moriAnalyticsPendingDays_(1).length?'1':'0');
  moriAnalyticsSaveState_(state);
  return {ok:true,ready:state.ready,changes:changes,backfill:backfill,daysRebuilt:rebuilt.length,pendingDirtyDays:moriAnalyticsPendingDays_(100).length,pendingSourceChanges:moriAnalyticsQueued_(100).length};
 }finally{moriAnalyticsReleaseLease_(lease);}
}
/** Timer target: always private and validates the executing owner's identity. */
function moriAnalyticsWorker_(){
 var owner=String(moriProp_('OWNER_EMAIL')||'').toLowerCase(),effective=String(Session.getEffectiveUser().getEmail()||'').toLowerCase();
 moriEnsure_(owner&&owner===effective,'Analytics trigger phải chạy với tài khoản owner');
 return moriAnalyticsSyncCore_();
}
function moriAnalyticsSyncNow(){moriEditorOnly_();return moriAnalyticsSyncCore_();}
function moriAnalyticsStatus(){moriEditorOnly_();var s=moriAnalyticsState_(),sources=moriAnalyticsSources_();return {
  installed:!!s.installed,dashboardReady:moriAnalyticsDashboardReady_(),dashboardUrl:moriProp_('FILE_DASHBOARD')?'https://docs.google.com/spreadsheets/d/'+moriProp_('FILE_DASHBOARD')+'/edit':null,ready:moriAnalyticsReady_(),backfillComplete:!!s.backfillComplete,sourceIndex:s.sourceIndex,cursor:s.cursor,
  sourceCount:sources.length,currentSource:sources[s.sourceIndex]?.key||null,lastRunAt:s.lastRunAt||null,lastMaterializedAt:s.lastMaterializedAt||null,
  pendingSourceChanges:moriAnalyticsQueued_(1000).length,pendingDirtyDays:moriAnalyticsPendingDays_(1000).length,repairRequired:moriProp_('ANALYTICS_REPAIR_REQUIRED')==='1'
};}
/** Existing archives must not delete source rows while materializer has unsynced writes. */
function moriAnalyticsCanArchive_(kind){return moriAnalyticsDashboardReady_()&&moriAnalyticsReady_()&&!moriAnalyticsQueueHas_(kind)&&!moriAnalyticsPendingDays_(1).length;}

/** Non-destructive reconciliation: scans source again and retracts changed records.
 * During repair, dashboard reads are paused to avoid silently stale numbers.
 */
function moriAnalyticsRebuildHistory(){
 moriEditorOnly_();var state=moriAnalyticsState_();moriEnsure_(state.installed,'Analytics chưa cài');
 state.ready=false;state.backfillComplete=false;state.sourceIndex=0;state.cursor=2;state.restartedAt=moriNow_();moriAnalyticsSaveState_(state);
 return {ok:true,message:'Đang đối soát lại dữ liệu nguồn; trigger 5 phút sẽ chạy tiếp từng lô.'};
}
/** Reusable, branch-scoped dashboard query. Never exposes Bills, cost snapshots or staff. */
function moriAnalyticsQuery(token,request){
 var actor=moriActor_(token),q=request||{},branchId=Number(q.branchId),start=moriForecastDay_(q.startDate),end=moriForecastDay_(q.endDate);
 moriRequire_(actor,['ADMIN','MANAGER'],branchId);moriAnalyticsRequireReady_();
 var days=(Date.parse(end)-Date.parse(start))/86400000+1;
 moriEnsure_(days>=1&&days<=366,'Chỉ hỗ trợ kỳ báo cáo từ 1 đến 366 ngày');
 var by=String(q.groupBy||'DAY').toUpperCase();moriEnsure_(['DAY','MONTH','ITEM'].indexOf(by)>=0,'Kiểu nhóm Analytics không hợp lệ');
 var rows=moriAnalyticsDailyRead_(branchId,start,end),groups={},summary={quantity:0,revenue:0,cogs:0,bills:0,stockPurchases:0,stockReceipts:0};
 function blank(key){return {key:key,quantity:0,revenue:0,cogs:0,bills:0,stockPurchases:0,stockReceipts:0};}
 rows.forEach(function(r){
  if(r.status==='EMPTY')return;
  var key=by==='DAY'?r.day:by==='MONTH'?r.day.slice(0,7):String(r.itemId||''),g=groups[key]||(groups[key]=blank(key));
  if(r.kind==='SALES_ITEM'){
   ['quantity','revenue','cogs'].forEach(function(field){var src=field==='quantity'?'qty':field==='cogs'?'cost':field;g[field]+=Number(r[src])||0;summary[field]+=Number(r[src])||0;});
  }else if(r.kind==='BILLS_COUNT'){g.bills+=Number(r.paidBillCount)||0;summary.bills+=Number(r.paidBillCount)||0;}
  else if(r.kind==='STOCK_CASH'){g.stockPurchases+=Number(r.purchaseAmount)||0;summary.stockPurchases+=Number(r.purchaseAmount)||0;g.stockReceipts+=Number(r.receiptCount)||0;summary.stockReceipts+=Number(r.receiptCount)||0;}
 });
 // With ITEM grouping, exclude synthetic sales-count and stock-cash dimensions from item rows;
 // these remain in the independently computed summary object.
 var data=Object.keys(groups).filter(function(k){return by!=='ITEM'||k!=='__BILLS__'&&k!=='__STOCK__';}).sort().map(function(k){var r=groups[k];r.grossProfit=r.revenue-r.cogs;return r;});
 summary.grossProfit=summary.revenue-summary.cogs;
 return {ok:true,source:'AnalyticsDaily',branchId:branchId,startDate:start,endDate:end,groupBy:by,summary:summary,data:data,materializedAt:moriAnalyticsState_().lastMaterializedAt||null,hasPendingChanges:moriProp_('ANALYTICS_PENDING_FLAG')==='1'};
}
