# MoriPOS v3.1.7 Test Report

- Baseline: 3.1.6 POS_Dashboard source.
- Local simulated test runner: `node tests/run-tests.js`.
- Outcome: **13 suites, 118 reported PASS groups**, including 6 targeted UI cleanup tests.
- Start/auth, sales/checkout, revenue, Forecast arithmetic, audit, inventory, Analytics backfill, POS_Dashboard migration remained passing.
- Production source code changes restricted to `Index.html` and `Code.gs`.
- Code.gs's MORI_FRONTEND_SHA256 matches byte-for-byte UTF-8 hash of Index.html; build markers aligned at v3.1.7.
- Only layout strings/CSS and rendering fragments changed; no calculations, calls, sheet schemas, or triggers changed.
- Limitations: tests use Node VM and mocked DOM/Sheets, not a real browser or production Google Apps Script deployment.
