# Cách sử dụng Forecast MoriPOS 3.1.3

1. Chọn chi nhánh, kỳ dự báo, ngày tham chiếu. Kỳ tính lợi nhuận là từ ngày bắt đầu đến ngày kết thúc (bao gồm cả hai ngày).
2. Chọn phương pháp mục tiêu và nhập giá trị **ở ô bên cạnh**: số tiền (đ) hoặc tỷ lệ (%). Ví dụ lợi nhuận cố định 1.000.000đ, biên lợi nhuận 20%.
3. Chọn Tự tính chi phí vận hành. Nhập phí phát sinh ngoài cấu hình (đ). Ô tổng màu xanh phải tự nhảy khi bạn nhập hoặc bấm số gợi ý.
4. Thêm combo/sản phẩm, nhập **tổng số lượng trong kỳ** cho ba kịch bản. Giá bán giả định chỉ áp dụng cho **số lượng còn phải bán**.
5. Có thể bấm gợi ý 80/100/120. Nếu chưa có doanh thu lịch sử, nhập trước số lượng cột Cơ sở để suy ra hai cột khác.
6. Xem ba kịch bản và chọn một. Đọc bảng Doanh thu & chi phí chi tiết để xác minh phép tính.
7. Đọc bảng Nguyên liệu / thành phẩm: số cần cho phần chưa bán − tồn khả dụng, thiếu bao nhiêu thì mới có tiền cần mua. Nếu không có thành phần định lượng, sản phẩm theo dõi tồn như thành phẩm (không đo nguyên liệu riêng).
8. Bấm Lưu kế hoạch để lưu vào tab ForecastPlans; không thay giá danh mục hay tạo bill.

### Ví dụ từ dữ liệu thử
- Đã bán 2 ly: doanh thu thực tế 42.000đ, giá vốn thực tế 22.000đ.
- Cơ sở 15 ly cả kỳ, giá kịch bản 35.000đ, chi phí thêm 2.000đ/ly.
- Còn cần bán 13 ly; doanh thu cả kỳ 42.000 + 13 × 35.000 = 497.000đ.
- Tổng chi phí trước vận hành 22.000 + 13 × 11.000 + 15 × 2.000 = 195.000đ.
- Nhập phát sinh 3 triệu, không có chi phí vận hành cơ sở -> tổng chi phí 3.195.000đ; lợi nhuận -2.698.000đ.
- Nếu tồn khả dụng 32 ly, cần 13 ly, cần nhập thêm 0 ly. Nếu thiếu 5 ly với giá nhập 11.000đ thì tiền nhập thêm 55.000đ (dòng tiền mua hàng, không cộng trùng vào giá vốn).

### Cách nhập tiền
Các ô tiền của Forecast tự thêm dấu phân cách hàng nghìn: gõ `1000000` sẽ thấy `1.000.000`. Bạn có thể chọn mức gợi ý; con số sẽ cập nhật ngay cả khi không gõ thêm phím. Khi lưu, hệ thống chỉ lưu `1000000` dạng số. Các ô `%` nhập `20` để hiểu là `20%`.
