# MoriPOS v3.2.4 — local QC

- Baseline: v3.2.3 full scripts and its 17 existing Node test suites.
- Outcome: 18 suites / 151 PASS groups (local simulated Google Apps Script and browser environment).
- Syntax/integrity: Index JavaScript parses, Apps Script files parse, Code.gs frontend SHA-256 matches exact Index.html bytes, startup checks pass.
- New test: `tests/holiday-pricing-324.test.js`.
- Covered: weekday/weekend matching; annual holiday vs one-off holiday; inclusive date ranges; invalid dates; on/off fallback; special price and empty-price fallback; server quote matching public display; promotion applied once; inactive item blocking and reactivation; privileged settings updates and optimistic-version conflict; UI native selects and fields.
- Not covered: real deployed Google Apps Script latency, full physical browser acceptance on mobile devices, live checkout financial reconciliation against production data. Stage-test before deploying.
