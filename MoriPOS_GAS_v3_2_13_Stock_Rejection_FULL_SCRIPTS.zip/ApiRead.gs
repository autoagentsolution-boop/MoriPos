/** Defensive response projection: UI hiding alone is not an access boundary. */
function moriForActor_(actor,table,doc){
 if(!doc)return doc;
 if(actor.role==='ADMIN')return doc;
 var x=moriDeep_(doc);
 if(table==='Items'&&actor.role==='EMPLOYEE'){
  delete x.cost;delete x.costByBranch;delete x.processingCost;delete x.appliedOps;
 }
 if(table==='Bills'&&actor.role==='EMPLOYEE'){
  delete x.inventoryNeeds;
  (x.items||[]).forEach(function(line){delete line.cost;});
 }
 if(table==='StockIn'&&actor.role==='EMPLOYEE'){
  (x.lines||[]).forEach(function(line){delete line.unitCostBase;delete line.cost;});
 }
 if(table==='Employees'&&actor.role==='MANAGER'){
  delete x.salaryBase;delete x.rate;delete x.cccd;
 }
 if(table==='Employees'&&actor.role==='MANAGER'){return {id:x.id,email:x.email,name:x.name,role:x.role,branchId:x.branchId,branchIds:x.branchIds||[x.branchId],isActive:x.isActive};}
 if(table==='Employees'&&actor.role==='EMPLOYEE'){
  return {id:x.id,email:x.email,name:x.name,role:x.role,branchId:x.branchId,isActive:x.isActive};
 }
 if(table==='Customers'&&actor.role==='EMPLOYEE'){
  return {id:x.id,name:x.name,phone:x.phone,customerGroup:x.customerGroup};
 }
 if(table==='Settings'){
  return {id:'global',modules:x.modules||{},showItemImages:x.showItemImages,
    lowStockThreshold:x.lowStockThreshold,lowStockPolicy:x.lowStockPolicy,
    forecast:actor.role==='MANAGER'?x.forecast:undefined,holidayPricing:x.holidayPricing||{enabled:false,saturday:false,sunday:false,days:[],ranges:[]},receipt:x.receipt||{},paidBillEditRoles:{[actor.role]:!!(x.paidBillEditRoles||{})[actor.role]}};
 }
 if(table==='Stores'&&actor.role==='EMPLOYEE'){
  delete x.monthlyRent;delete x.monthlyOtherCost;
 }
 if(table==='Branches'&&actor.role==='EMPLOYEE'){
  delete x.monthlyRent;delete x.monthlyOtherCost;
 }
 if(table==='PublishSite'&&actor.role==='EMPLOYEE'){
  return {id:x.id,published:x.published,mode:x.mode,orderBranches:x.orderBranches,bookingBranches:x.bookingBranches};
 }
 return x;
}
function moriReadFilter_(actor,table,records){
 var scopes=(actor.branchIds||[]).map(Number),within=function(x){return actor.role==='ADMIN'||scopes.indexOf(Number(x.branchId))>=0;};
 return (records||[]).filter(function(x){
  if(['Bills','StockIn','Booking','Attendance','Employees','Customers'].indexOf(table)>=0){
   if(table==='Employees'&&actor.role==='EMPLOYEE')return x.email===actor.email;
   if(table==='Customers'&&!x.branchId)return actor.role==='ADMIN'; // Legacy unscoped members require Admin review before staff visibility.
   if(table==='Attendance'&&actor.role==='EMPLOYEE')return x.email===actor.email;
   if(table==='StockIn'&&actor.role==='EMPLOYEE')return x.employee===actor.email;
   return within(x);
  }
  return true;
 }).map(function(x){return moriForActor_(actor,table,x);});
}
/** Read APIs: bootstrap returns only data authorized for this role/branch. */
function moriHistoryFor_(user){
 return {bills:moriReadFilter_(user,'Bills',moriRecent_('Bills',1500)),
  stockins:moriReadFilter_(user,'StockIn',moriRecent_('StockIn',600)),
  bookings:moriReadFilter_(user,'Booking',moriRecent_('Booking',800)),
  attendance:moriReadFilter_(user,'Attendance',moriRecent_('Attendance',user.role==='EMPLOYEE'?100:500)),
  audits:user.role==='ADMIN'?moriRecent_('Audit',200):[]};
}
function moriBootstrapFor_(user,coreOnly){
 var data={ok:true,user:user,
  store:moriForActor_(user,'Stores',moriCachedOne_('Stores','1')),
  settings:moriForActor_(user,'Settings',moriCachedOne_('Settings','global')),
  publishSite:moriForActor_(user,'PublishSite',moriCachedOne_('PublishSite','site')),
  branches:moriAll_('Branches',true).filter(function(x){return user.role==='ADMIN'||user.branchIds.map(Number).indexOf(Number(x.id))>=0;}).map(function(x){return moriForActor_(user,'Branches',x);}),
  employees:moriReadFilter_(user,'Employees',moriAll_('Employees',true)),
  customers:coreOnly?[]:moriReadFilter_(user,'Customers',moriAll_('Customers',true)),
  customersDeferred:!!coreOnly,
  items:moriReadFilter_(user,'Items',moriAll_('Items',true)),
  bills:[],stockins:[],bookings:[],attendance:[],audits:[],historyDeferred:!!coreOnly,loadedAt:moriNow_()};
 if(!coreOnly)Object.assign(data,moriHistoryFor_(user));
 return data;
}
function moriBootstrap(token){return moriBootstrapFor_(moriActor_(token),false);}
function moriSessionBootstrap(token){
 var started=Date.now(),user;
 // Keep setup/Sheets failures distinguishable from an expired or revoked session.
 try{user=moriActor_(token);}catch(e){
  if(/Chưa đăng nhập|Phiên đăng nhập đã hết hạn|Quyền truy cập đã bị thu hồi/.test(e.message))return {authenticated:false};
  throw e;
 }
 var authMs=Date.now()-started,data=moriBootstrapFor_(user,true);
 return {authenticated:true,data:data,timing:{serverMs:Date.now()-started,authMs:authMs}};
}
function moriHistory(token){var started=Date.now(),data=moriHistoryFor_(moriActor_(token));data.timing={serverMs:Date.now()-started};return data;}
/** v3.2.3: fetch one authorized history group on demand, never on login.
 * Naming and upper bounds are server controlled; the client cannot request arbitrary sheets.
 * Only the active page's data is shipped to the browser. Existing moriHistory remains
 * available for older deployed clients during migration.
 */
function moriHistoryModule(token,group){
 var started=Date.now(),user=moriActor_(token),data={},name=String(group||'');
 switch(name){
  case 'Bills': data.bills=moriReadFilter_(user,'Bills',moriRecent_('Bills',1500));break;
  case 'StockIn': data.stockins=moriReadFilter_(user,'StockIn',moriRecent_('StockIn',600));break;
  case 'Booking': data.bookings=moriReadFilter_(user,'Booking',moriRecent_('Booking',800));break;
  case 'Attendance': data.attendance=moriReadFilter_(user,'Attendance',moriRecent_('Attendance',user.role==='EMPLOYEE'?100:500));break;
  case 'Audit': moriRequire_(user,['ADMIN']);data.audits=moriRecent_('Audit',200);break;
  case 'Customers': data.customers=moriReadFilter_(user,'Customers',moriAll_('Customers',true));break;
  default:throw new Error('Nhóm dữ liệu không được hỗ trợ');
 }
 data.group=name;data.timing={serverMs:Date.now()-started};
 console.info('Mori history '+JSON.stringify({group:name,serverMs:data.timing.serverMs,rows:(data.bills||data.stockins||data.bookings||data.attendance||data.audits||data.customers||[]).length}));
 return data;
}
/** Exact-value customer lookup. No full directory response is sent to the POS.
 * The backing search is Sheet TextFinder, not an actual database index.
 */
function moriCustomerLookup(token,field,raw){
 var user=moriActor_(token),allowed=field==='email'||field==='phone';moriEnsure_(allowed,'Chỉ được tìm email hoặc số điện thoại');
 var value=String(raw||'').trim();moriEnsure_(value.length>=5&&value.length<=160,'Giá trị tìm kiếm không hợp lệ');
 if(field==='email')value=value.toLowerCase();
 var found=moriFindJsonString_('Customers',field,value);
 return {found:!!found&&moriReadFilter_(user,'Customers',[found]).length>0,customer:found?moriReadFilter_(user,'Customers',[found])[0]||null:null};
}

function moriRefresh(token,opts){var actor=moriActor_(token),table=String(opts.table||'Bills');
 moriEnsure_(['Bills','StockIn','Booking','Attendance','Audit','Items','Customers'].indexOf(table)>=0,'Unknown data type');
 if(table==='Audit')moriRequire_(actor,['ADMIN']);
 var requested=opts.branchId||'ALL';if(actor.role!=='ADMIN'&&requested!=='ALL')moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],requested);
 var scan=Math.min(10000,Math.max(10,Number(opts.scan)||2000)),rows=moriReadFilter_(actor,table,moriRecent_(table,scan,requested));
 if(opts.status)rows=rows.filter(function(x){return x.status===opts.status;});
 var size=Math.min(100,Math.max(1,Number(opts.pageSize)||10)),page=Math.max(1,Number(opts.page)||1);
 return {rows:rows.slice((page-1)*size,page*size),total:rows.length,page:page,pageSize:size,scanned:scan,hasMoreOutsideScan:moriSheet_(table).getLastRow()-1>scan};
}
function moriPublicBootstrap(){var s=moriFind_('Settings','global')||{},p=moriFind_('PublishSite','site')||{},store=moriFind_('Stores','1');
 if(!s.modules?.publishSite||!p.published)return {published:false,store:{name:store?.name||'Cửa hàng'}};
 var branches=moriAll_('Branches',true).filter(function(b){return b.isActive!==false;}).map(function(b){return {id:b.id,code:b.code,name:b.name,phone:b.phone,address:b.address,email:b.email};});
 var items=moriAll_('Items',true).filter(function(x){return x.isActive!==false&&x.type!=='MATERIAL'&&p.categoryVisibility?.[x.cat]!==false&&p.itemRules?.[x.id]?.visible!==false;}).map(function(x){
  var r=(p.itemRules||{})[x.id]||{},pricing=typeof moriItemPrice_==='function'?moriItemPrice_(x,s.holidayPricing,moriDate_()):{price:Number(x.price)||0,source:'REGULAR'},base=pricing.price,price=base;if(r.type==='PERCENT')price=Math.round(base*(1-Math.min(100,Math.max(0,Number(r.value)||0))/100));else if(r.type==='FIXED')price=Math.max(0,base-(Math.max(0,Number(r.value)||0)));
  return {id:x.id,name:x.name,cat:x.cat,type:x.type,price:price,originalPrice:base,regularPrice:x.price,priceType:pricing.source,publicFinalPrice:true,emoji:x.emoji||'📦',imageUrl:x.imageUrl||'',baseUnit:x.baseUnit||'cái',stock:x.stock||0};
 });
 return {published:true,store:{name:store.name,phone:store.phone,email:store.email,address:store.address,logoUrl:store.logoUrl},branches:branches,settings:{modules:{publishSite:true,booking:!!s.modules.booking,onlineOrder:!!s.modules.onlineOrder},site:p},items:items,loadedAt:moriNow_()};
}
function moriPublicCreateOrder(request){moriPublicThrottle_(request.shipping?.phone||request.phone,'order');var result=moriLock_(function(){
 if(request.customerToken){var guest=moriCustomerActor_(request.customerToken);moriEnsure_(moriCustomerEmail_(request.shipping?.email)===guest.email,'Email đặt hàng không khớp tài khoản xác thực');request.guestIdentityId=guest.id;request.verifiedMemberId=guest.memberId||0;}
 else {delete request.guestIdentityId;delete request.verifiedMemberId;}var idempotency=String(request.requestId||'');moriEnsure_(idempotency.length>=12&&idempotency.length<=128,'Missing unique requestId');
 var cache=CacheService.getScriptCache(),key='mori:publicOrder:'+idempotency,old=cache.get(key);if(old){var existing=moriFind_('Bills',old);if(existing)return {id:existing.id,no:existing.no,trackingToken:existing.trackingToken,orderStatus:existing.orderStatus};}
 var recent=moriFindJsonString_('Bills','requestId',idempotency);if(recent)return {id:recent.id,no:recent.no,trackingToken:recent.trackingToken,orderStatus:recent.orderStatus};
 var doc=moriOnlineCreate_(null,request,true);cache.put(key,String(doc.id),21600);
 return {id:doc.id,no:doc.no,trackingToken:doc.trackingToken,orderStatus:doc.orderStatus};
});moriNotify_(result,'ORDER');return result;}
function moriPublicCreateBooking(request){moriPublicThrottle_(request.phone,'booking');var result=moriLock_(function(){var req=String(request.requestId||'');moriEnsure_(req.length>=12,'Missing requestId');var found=moriFindJsonString_('Booking','requestId',req);if(found)return {id:found.id,code:found.code,trackingToken:found.trackingToken};
 var doc=moriBookingCreate_(null,request,true);return {id:doc.id,code:doc.code||'BK-'+doc.id,trackingToken:doc.trackingToken};
});moriNotify_(result,'BOOKING');return result;}
function moriNotify_(result,kind){try{var email=moriProp_('OWNER_EMAIL');if(!email||!result?.id)return;var key='mori:notice:'+kind+':'+result.id,cache=CacheService.getScriptCache();if(cache.get(key))return;
 var text=kind==='ORDER'?'Có đơn hàng online mới':'Có booking online mới';MailApp.sendEmail({to:email,subject:'Mori POS · '+text,body:text+'\nMã: '+(result.no||result.code||result.id)+'\nVào Mori POS để xác nhận.'});cache.put(key,'1',21600);
 }catch(e){console.error('Mori notification failure: '+e.message)}}
function moriPublicTrack(token,type){moriEnsure_(typeof token==='string'&&token.length>=64&&token.length<160,'Mã theo dõi không hợp lệ');var table=type==='BOOKING'?'Booking':'Bills',data=moriFindJsonString_(table,'trackingToken',token);if(!data)return {found:false};
 if(type==='BOOKING')return {found:true,id:data.id,code:data.code,status:data.status,date:data.date,time:data.time,guestCount:data.guests};
 return {found:true,id:data.id,no:data.no,orderStatus:data.orderStatus,paymentStatus:data.paymentStatus,items:(data.items||[]).map(function(x){return {name:x.name,qty:x.qty};}),total:data.finalTotal};
}
/** Narrow refresh. Avoid reloading all seven spreadsheets after every button click. */
function moriDelta(token,kinds,options){var started=Date.now(),user=moriActor_(token);moriEnsure_(Array.isArray(kinds)&&kinds.length<=5,'Too many data groups');kinds=Array.from(new Set(kinds));var out={Complete:[]},cached=!(options&&options.fresh===true);
 var scope=x=>user.role==='ADMIN'||user.branchIds.map(Number).indexOf(Number(x.branchId))>=0;
 kinds.forEach(function(k){switch(k){
 case 'Items':out.Items=moriReadFilter_(user,'Items',moriAll_('Items',cached));break;
 case 'Bills':out.Bills=moriReadFilter_(user,'Bills',moriRecent_('Bills',250));break;
 case 'StockIn':out.StockIn=moriReadFilter_(user,'StockIn',moriRecent_('StockIn',150));break;
 case 'Booking':out.Booking=moriReadFilter_(user,'Booking',moriRecent_('Booking',200));break;
 case 'Customers':out.Customers=moriReadFilter_(user,'Customers',moriAll_('Customers',cached));break;
 case 'Settings':out.Settings=moriForActor_(user,'Settings',moriFind_('Settings','global'));break;
 case 'PublishSite':out.PublishSite=moriForActor_(user,'PublishSite',moriFind_('PublishSite','site'));break;
 case 'Branches':out.Branches=moriAll_('Branches',cached).filter(function(x){return user.role==='ADMIN'||user.branchIds.map(Number).includes(Number(x.id));}).map(function(x){return moriForActor_(user,'Branches',x);});break;
 case 'Stores':out.Stores=moriForActor_(user,'Stores',moriFind_('Stores','1'));break;
 case 'Employees':out.Employees=moriReadFilter_(user,'Employees',moriAll_('Employees',cached));break;
 case 'Audit':if(user.role==='ADMIN')out.Audit=moriRecent_('Audit',80);break;
 default:throw new Error('Unknown delta group');
 }if(['Items','Customers','Branches','Employees'].indexOf(k)>=0)out.Complete.push(k);});out.timing={serverMs:Date.now()-started};return out;}
/** Run from Apps Script editor to verify installation, without disclosing any data rows. */
function moriHealthCheck(){moriEditorOnly_();var ready=moriProp_('READY')==='1',report={ready:ready,at:moriNow_(),files:{},warnings:[]};
 if(!ready){report.warnings.push('Run moriSetup(ownerEmail)');return report;}
 Object.keys(MORI_FILE_NAMES).forEach(function(key){try{var id=moriProp_('FILE_'+key),book=SpreadsheetApp.openById(id);report.files[key]={id:id,name:book.getName(),sheets:book.getSheets().map(function(s){return {tab:s.getName(),rows:Math.max(0,s.getLastRow()-1)};})};}catch(e){report.warnings.push(key+': '+e.message);}});
 return report;}
/** Read-only probe for owner during QC. Run from editor; does not create data. */
function moriPerformanceProbe(){moriEditorOnly_();var rows=[];['Items','Branches','Settings','Bills','StockIn','Booking'].forEach(function(t){var start=Date.now(),size=t==='Bills'||t==='StockIn'||t==='Booking'?moriRecent_(t,500).length:moriAll_(t,false).length;rows.push({table:t,rowsRead:size,readMs:Date.now()-start});});return {at:moriNow_(),rows:rows};}

function moriPublicThrottle_(contact,kind){var phone=String(contact||'').replace(/\s/g,''),hash=Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,phone)).slice(0,20);var cache=CacheService.getScriptCache(),key='mori:public:rate:'+kind+':'+hash,count=Number(cache.get(key)||0);moriEnsure_(count<5,'Quá nhiều yêu cầu, hãy thử lại sau');cache.put(key,String(count+1),600);}
