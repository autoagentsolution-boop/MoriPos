# Sửa lỗi `moriBootstrapFor_ is not defined` — Mori POS 3.1.0

## Nguyên nhân

Trong ZIP 3.1.0, `Security.gs` gọi hàm `moriBootstrapFor_(user, true)` sau khi OTP được xác thực. Hàm này nằm ở `ApiRead.gs`. Nếu `ApiRead.gs` thiếu, bị bỏ sót khi cập nhật, hoặc deployment vẫn chạy version chưa có file đó, xác thực OTP vẫn thành công nhưng dữ liệu cửa hàng không tải được.

## Cách sửa (không động tới dữ liệu)

1. Vào đúng **Google Apps Script project** đang phục vụ trang POS.
2. Mở file `ApiRead.gs`. Thay **toàn bộ nội dung** bằng `ApiRead.gs` trong gói sửa này (không dán nối cuối file cũ). Nếu chưa có, tạo Script file tên `ApiRead`.
3. Tạo Script file tên `MoriPreflight310`, dán `MoriPreflight310.gs`.
4. Save. Chọn hàm `moriPreflight310` trong Editor và bấm **Run**. Kết quả cần có `ok: true` và `missing: []`. Nếu không, bổ sung các file được nêu trong `missing` từ ZIP v3.1.0 gốc.
5. Có thể chạy `moriFrontendCheck()` để kiểm tra đúng `Index.html` bản 3.1.0.
6. Vào **Deploy > Manage deployments > Edit** (đúng deployment `/exec` hiện tại) **> New version > Deploy**.
7. Reload trang `/exec`, kiểm tra OTP. Nếu đang có session cũ thì thoát/đăng nhập lại.

**Lưu ý:** Nếu preflight `ok: true` nhưng `/exec` vẫn lỗi cũ, bạn đang truy cập deployment/version khác hoặc chưa chọn New version. Kiểm tra URL và Deployment ID.

**KHÔNG chạy** `moriSetup`, `moriInstallOnce`, `moriSeedQC`, không xóa Script Properties hoặc Sheet hiện tại.

Gói này giữ nguyên `ApiRead.gs` của ZIP 3.1.0 gốc và thêm một hàm kiểm tra trước deployment; nó không phải bản sửa logic mới.
