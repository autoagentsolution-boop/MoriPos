# MoriPOS v3.2.2 — Staff Modal & Publish Site Save Fix

## Scope
This release is based on MoriPOS v3.2.1. No Google Sheet schema, script properties, storage migrations, dashboard backfills, authentication APIs, or checkout logic are changed.

### Updated
- **Staff modal:** Manager/Employee role selection is a real/native dropdown; the general Mori select enhancer intentionally excludes it through `data-use-native`.
- **Fixed underlying click bug:** the staff overlay event handler no longer prevents default clicks on inner form elements. Only a click on the backdrop itself dismisses the modal.
- **Branches:** one compact dropdown with multiple selectable branches; names remain on one line and backend still receives the `branchIds` array.
- **Account status:** compact toggle switch, no giant native checkbox.
- **Publish Site:** input/link buttons and icon/text alignment improved in desktop and mobile layout.
- **Save button:** `Lưu cài đặt` on Order and Booking settings.
- **One write and one notification:** `savePublicSite()` validates the form, submits one `publish.save` RPC, waits for confirmation and shows one `Đã lưu cài đặt` toast. No optimistic success message and no separate queued save request. If the write fails, the settings are not applied locally.

## Quick upgrade from 3.2.1
1. Backup the current Google Apps Script project and Google Sheets.
2. Replace **Index.html** and **Code.gs** with the same-release versions from this ZIP. They must be deployed together due to SHA-256 verification.
3. Replace the old MoriPreflight321.gs with **MoriPreflight322.gs** (optional diagnostic; remove the old version to avoid confusion).
4. Save; run `moriFrontendCheck()` and `moriPreflight322()` in Apps Script Editor. Confirm build `3.2.2`, `exactFileMatch: true`, and `ok: true`.
5. Deploy > Manage deployments > Edit > **New version** > Deploy. Open the existing `/exec` deployment.
6. Smoke test: Settings > Staff, add a test Manager and select a branch; save and reopen. In Publish > Online Orders modify a non-critical setting, click `Lưu cài đặt`, verify no premature or duplicate toasts. Then verify it persists after reload. Repeat for Booking if enabled.

## No changes required
- Do NOT run `moriSetup`, `moriAnalyticsInstall`, `moriCustomerInstall`, or backfill again.
- No change to `POS_Master`, `POS_Customers` or `POS_Dashboard`.
- Staff permission enforcement stays on server in StaffAccess.gs and Security.gs.

## URL shortening (not implemented in this release)
The official Apps Script public URL remains `https://script.google.com/macros/s/.../exec?view=shop`. A short link or custom-domain HTTP redirect can point to this URL. A redirect does not change the target browser address bar, while serving the full application from a custom domain requires an additional hosting layer. No redirect or link shortener is included in v3.2.2, per request.

## Test status
Local Node/VM simulation only: see TEST_REPORT_3_2_2.md. Production performance, Chrome mobile layout and actual Apps Script authorization remain to be verified by the owner on a staging deployment.
