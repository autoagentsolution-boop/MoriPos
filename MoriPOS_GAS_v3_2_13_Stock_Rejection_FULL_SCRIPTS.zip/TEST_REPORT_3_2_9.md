# Kiểm tra MoriPOS 3.2.9

Ngày kiểm tra: 17/11/2026.

## Kết quả

- `node tests/run-tests.js`: 21 bộ kiểm tra, 167 nhóm PASS. Log đầy đủ: `tests/TEST_329_RUN.log`.
- Kiểm tra bổ sung sau đó cho đường đi của nút Tạo mặt hàng: thu thập đầy đủ nguyên liệu, đơn vị, lượng và hao hụt ở tất cả dòng cho PRODUCT/SERVICE — PASS. Log: `tests/TEST_329_CATALOG_FINAL.log`.
- `node tests/holiday-ui-325.test.js`: 5 nhóm PASS.
- `Code.gs` chứa SHA-256 đúng của `Index.html`; hai marker và build đều là 3.2.9.
- `Units.gs`, `ForecastCore.gs`, `Forecast.gs`, `Operations.gs` và các runtime khác ngoài `Index.html`/`Code.gs` khớp byte với gói gốc v3.2.8.

## Các tình huống đã kiểm tra

- ID dropdown duy nhất khi thêm/xóa dòng; khởi tạo lại không thêm nút trùng.
- Dropdown cập nhật đúng nhãn sau khi thay nguyên liệu/đơn vị; ô tìm nguyên liệu luôn được cung cấp.
- Không tạo phần tử loading nổi; khóa nút, chống nhấn lặp, phục hồi nút khi hoàn tất hoặc lỗi vẫn qua kiểm tra hiện có.
- Giao diện chỉ áp dụng dữ liệu đã được API xác nhận. Lưu danh mục dùng một lượt gọi API, không chờ `moriDelta` hay `moriBootstrap` bổ sung.
- PRODUCT và SERVICE lưu đủ thành phần, đơn vị, hao hụt, chi phí chế biến; kiểm tra bản ghi server, form mở lại và bootstrap mới.
- Bản cập nhật cũ không ghi đè phiên bản mới. Phản hồi đến sau khi đổi phiên đăng nhập không khôi phục dữ liệu phiên cũ.
- Form đang chỉnh sửa không bị tái tạo khi trang cập nhật nền.
- Lưu lỗi giữ form và dữ liệu cũ; thử lại thủ công ghi đúng lượng mới.
- Các bộ hồi quy thanh toán, tồn kho, phân quyền, lịch giá đặc biệt, audit, Forecast và khởi động đều qua.

## Giới hạn kiểm chứng

Các kết quả trên là kiểm tra Node với DOM và RPC/Sheets mô phỏng. Môi trường không khởi chạy được Chromium nên chưa có kiểm tra bố cục bằng trình duyệt thật. Chưa xác minh deployment hoặc độ trễ Google Apps Script thực tế. Việc giảm từ hai lượt RPC xuống một lượt đã được xác nhận bằng kiểm tra luồng gọi, không phải số đo thời gian thực tế.
