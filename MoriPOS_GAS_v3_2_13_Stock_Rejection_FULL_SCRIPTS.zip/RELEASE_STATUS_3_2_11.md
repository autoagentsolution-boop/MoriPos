# MoriPOS 3.2.11

Gói full scripts đã kiểm tra, chưa triển khai Web App.

Bao gồm chỉnh sửa Đơn vị/Loại, lọc danh mục, dropdown Mori đồng nhất và lưu định lượng; tối ưu phản hồi lưu, gộp đọc trùng, cache theo phiên bản, ghi nhập kho theo lô, tìm kiếm chính xác và archive/xóa lịch sử có giới hạn mỗi lượt.

Đã đạt 23 bộ / 193 nhóm kiểm tra mô phỏng. Số đo mẫu: duyệt phiếu + cập nhật UI giảm 2 → 1 RPC, 86 → 22 dòng đọc; phiếu 20 mặt hàng giảm 23 → 4 lần setValues. Chưa đo độ trễ Google thực tế.

Nâng cấp từ 3.2.9/3.2.10: thay đầy đủ 8 file nêu trong `README_UPGRADE_3_2_11.md`, kiểm tra checksum rồi deploy New version. Không chạy lại Setup/migration. Đổi đơn vị khai báo giữ nguyên giá trị số; không tự quy đổi tồn/giá. Công thức combo và Forecast giữ nguyên.
