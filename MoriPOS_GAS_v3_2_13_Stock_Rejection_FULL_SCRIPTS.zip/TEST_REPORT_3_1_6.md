# MoriPOS v3.1.6 — Local Test Report

**Result: 12 test suites, 112 groups PASS** (Node VM fixtures, not live GAS). Source: `tests/LAST_RUN.txt`.

Migration regression coverage:
- `POS_Master` legacy ledger/daily are copied to a **separate** `POS_Dashboard` spreadsheet, verified, then routing is switched.
- Rerunning installer never overwrites new Dashboard records using stale old Master copies.
- Failure during second-tab copy leaves dashboard `ready` flag OFF; retry succeeds.
- Fresh install creates analytics tabs inside Dashboard, not Master.
- Conflicting rows in existing Dashboard prevent cutover; source is untouched.
- Identical Spreadsheet IDs for MASTER and DASHBOARD are rejected.

Other suites cover POS transactional integrity, access control, Forecast math, audit, startup, cache, and analytics idempotency/retry/rebuild.

Additionally: 19 `.gs` files parse; `Code.gs` expected frontend SHA-256 equals the SHA-256 of `Index.html`. No live deployment/Google Sheets performance test was conducted.
