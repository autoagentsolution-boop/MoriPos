# MoriPOS v3.2.6 — Action Processing & Double-click Guard

Nâng cấp từ **v3.2.5**. Không thay đổi nghiệp vụ, Google Sheets schema hay các API Apps Script.

## File cần cập nhật (Quick Patch)

- `Index.html` — thêm Action Feedback dùng chung cho các nút gọi backend.
- `Code.gs` — cập nhật build 3.2.6 + hash SHA-256 của Index mới.

**Không chỉ thay Index.html** vì `moriFrontendCheck()` và bộ kiểm tra frontend sẽ báo lệch checksum.

## Hành vi mới

1. Nút xử lý chuyển thành spinner + `Đang xử lý…`, tạm khóa và chống click lặp trong cùng tác vụ.
2. Thông báo tiến trình nhỏ màu Mori xuất hiện ngay cả khi trang render lại; nếu xử lý quá 25 giây sẽ nhắc không bấm lại.
3. Với API thành công: giao diện trở lại trạng thái bình thường và hiển thị kết quả/thông báo thành công của thao tác.
4. Với API lỗi: nút được mở lại và thông báo lỗi hiển thị để người dùng kiểm tra rồi thử lại khi phù hợp.
5. Các thao tác liên quan gồm: thanh toán, lưu bill, nhập/duyệt kho, lưu mặt hàng, bật/ngừng bán, cập nhật giá ngày lễ, cấu hình cửa hàng, nhân sự, khách hàng/OTP, đơn online, đặt lịch, Forecast, đồng bộ và làm mới thủ công.
6. Các thao tác chỉ thay đổi giao diện tại chỗ (chọn tab, tăng/giảm số lượng, mở modal...) không bị loading thừa.
7. Các đơn order/booking từ Publish Site giữ cùng `requestId` trong lần thử lại với cùng nội dung ở cùng tab; khi máy chủ xác nhận thành công mới bỏ requestId. Backend vẫn quyết định tính idempotent của đơn.

## Lưu ý về độ tin cậy

- Trạng thái *đang xử lý* là cơ chế ở trình duyệt, **không thay thế** kiểm tra quyền, transaction lock, request ID và idempotency ở backend.
- Khi mất mạng giữa lúc lưu và nhận phản hồi, kết quả có thể **đã lưu ở server dù trình duyệt chưa nhận xác nhận**. Đối chiếu bill / lịch / dữ liệu trong hệ thống trước khi thử lại, nhất là với các thao tác tạo mới chưa có idempotency ở backend.
- Không tự động gửi lại các API ghi dữ liệu khi hết thời gian. Giao diện tiếp tục giữ trạng thái đang xử lý nếu máy chủ chưa có phản hồi để tránh ghi trùng.

## Cài đặt

1. Sao lưu project Apps Script và deployment cũ.
2. Thay **cả `Index.html` và `Code.gs`** bằng hai file trong Quick Patch.
3. Trong Editor chạy `moriFrontendCheck()` và kiểm tra `build: "3.2.6"`, `exactFileMatch: true`, `ok: true`, `startMarker: true`, `endMarker: true`.
4. Deploy > Manage deployments > Edit > **New version** > Deploy.
5. Thử 5 luồng trên môi trường test: lưu mặt hàng, lưu cấu hình, duyệt nhập kho, thanh toán bill test, gửi đơn từ Publish Site. Trong mỗi luồng click liên tục 2 lần, chỉ một thao tác được gửi và chỉ một kết quả được ghi. Kiểm tra cả trường hợp máy chủ báo lỗi.

Không chạy lại `moriSetup`, `moriAnalyticsInstall`, `moriCustomerInstall`, migration hoặc backfill.

## Kiểm thử

- 19 bộ kiểm thử mô phỏng, 157 nhóm PASS trong môi trường Node.js.
- Có kiểm thử trực tiếp cho khóa click lặp, khôi phục trạng thái sau xử lý, cập nhật nút bị render lại, các action ghi/chấm công/Forecast, và checksum frontend.
- **Chưa kiểm chứng trên Google Apps Script production**; cần staging và test với bill thử trước khi áp dụng vào cửa hàng.
