# Kiểm tra MoriPOS 3.2.10

Ngày kiểm tra: 17/11/2026.

`node tests/run-tests.js` — **22 bộ kiểm tra, 174 nhóm PASS**. Log: `tests/TEST_3210_RUN.log`.

Tình huống mới đã qua:

- Sửa cái → phần, Sản phẩm → Combo; lưu và bootstrap mới giữ đúng loại, đơn vị, định lượng và chi phí chế biến.
- Công thức khác đang dùng tên đơn vị đếm cũ tiếp tục tính được; lịch sử bill đã thanh toán giữ nguyên.
- Sửa nhãn đơn vị giữ nguyên số lượng tồn, giá vốn theo chi nhánh và giá bán. Quy đổi đóng gói xung đột hoặc đơn vị làm hỏng công thức tham chiếu bị từ chối trước khi ghi.
- Chuyển Sản phẩm/Dịch vụ/Combo giữ thành phần; Combo trống và Nguyên liệu có công thức vẫn bị từ chối. Kiểm tra quyền và version conflict vẫn hoạt động.
- Danh mục và trạng thái lọc kết hợp; đếm kết quả, phân trang, Chưa phân loại và bỏ lọc khi danh mục không còn đều đúng.
- Form sửa mở đúng loại/đơn vị đã lưu, hỗ trợ đơn vị tùy chỉnh đã tồn tại và hiện ghi chú khi đổi đơn vị.
- Chạy handler thực của nút Lưu chỉnh sửa: gửi loại/đơn vị mới cùng đầy đủ các dòng định lượng, nhận bản ghi server và mở lại đúng; một lượt RPC.

Các kiểm tra hồi quy về dropdown, lưu công thức, loading, thanh toán, tồn kho, Forecast, audit, lịch giá và phân quyền đều qua.

Kiểm tra toàn vẹn: build và marker 3.2.10; SHA-256 của Index.html khớp Code.gs. So với v3.2.9, chỉ ba runtime Index.html, Code.gs và Operations.gs thay đổi. Units.gs và các module Forecast giữ nguyên.

Giới hạn: các kết quả dùng Node với DOM/RPC/Sheets mô phỏng; chưa có kiểm tra trình duyệt thật hoặc deployment Google Apps Script của người dùng. Không có số đo độ trễ production.
