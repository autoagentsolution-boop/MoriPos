# MoriPOS 3.2.12

Bản giao diện: bỏ số đếm thừa ở header và đặt bộ lọc Danh mục/Trạng thái trên một dòng.

Runtime khác 3.2.11: Index.html, Code.gs (hằng phiên bản/checksum). Không triển khai thay đổi lưu nền hoặc cache mới.

3 bộ kiểm thử hiện có / 46 nhóm kiểm tra mô phỏng đạt. Chưa triển khai Web App. Hướng dẫn nâng cấp: README_UPGRADE_3_2_12.md.
