# MoriPOS v3.2.7 — Rounded Dropdown UI / Local QC

- 21/21 Node.js test suites passed (legacy assertions updated for the new UI contract).
- Main executable JavaScript parsed successfully with Node.js.
- Chromium browser smoke tests: item status changed to `false` via rounded menu, holiday pricing enabled via rounded menu, holiday recurrence changed via rounded menu.
- Existing `<select>` controls and `change` events preserved, including backend persistence mappings.
- Multi-branch staff selector remains a multiselect, styled consistently with other menus.
- `Index.html` SHA-256 matches `MORI_FRONTEND_SHA256` in `Code.gs`.
- This does not verify an actual Google Apps Script production deployment or persistent backend writes.
