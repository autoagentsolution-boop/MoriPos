/** Mori POS 3.2.3 — verified frontend loading.
 * Keep Code.gs and Index.html together for SHA-256 integrity.
 * Authentication checks remain in Security.gs and StaffAccess.gs.
 */
var MORI_SERVER_BUILD = '3.2.13';
var MORI_FRONTEND_BUILD = '3.2.13';
var MORI_FRONTEND_SHA256 = 'aff192cc361739129b6bc46bcc0dbb045ee8d55767ccb183ce32613bdb752bef';

function doGet(e){
 try {
  var p=e&&e.parameter||{},view=p.view==='shop'?'shop':'admin';
  var allowed=['home','catalog','booking','tracking'],tab=allowed.indexOf(p.tab)>=0?p.tab:'home';
  // Read the actual file before HtmlOutput processing. No evaluate() is needed:
  // this package is a single, self-contained Index without Apps Script scriptlets.
  var html=moriRawIndex_();
  if(html.indexOf('MORI_FRONTEND_BUILD:'+MORI_FRONTEND_BUILD)<0 || html.indexOf('MORI_FRONTEND_END:'+MORI_FRONTEND_BUILD)<0){
   // Missing comments do not prove an incomplete file. Continue serving the page.
   console.warn('Mori: source markers differ. Run moriFrontendCheck for details; startup is not blocked.');
  }
  // Keep the large executable script out of the initial HtmlService document.
  // Index stays a single source file; only its transport changes.
  var runtime=moriRuntimeSource_(html),meta=moriRuntimeMetadata_(runtime.source);
  var loader='<script id="mori-runtime-loader">('+moriRuntimeLoader_.toString()+')('+JSON.stringify(meta)+');</script>';
  html=html.slice(0,runtime.start)+loader+html.slice(runtime.end);
  var parts=moriDocumentParts_(html);
  if(!parts.head||!parts.body||parts.head.index>=parts.body.index)throw new Error('Index.html thiếu thẻ head hoặc body đúng vị trí.');
  // Insert by actual document offsets, ignoring tag-like strings in JS/CSS/comments.
  // Body is edited first so the earlier head offset remains valid.
  var body=parts.body[0].slice(0,-1)+' data-mori-view="'+view+'" data-mori-tab="'+tab+'" data-mori-source="'+(p.source==='facebook'?'facebook':'')+'">';
  html=html.slice(0,parts.body.index)+body+html.slice(parts.body.index+parts.body[0].length);
  var headEnd=parts.head.index+parts.head[0].length;
  html=html.slice(0,headEnd)+'<script>window.MORI_BACKEND=true;window.MORI_BUILD="'+MORI_SERVER_BUILD+'";</script>'+html.slice(headEnd);
  return HtmlService.createHtmlOutput(html).setTitle('Mori').addMetaTag('viewport','width=device-width, initial-scale=1.0');
 }catch(err){
  console.error('Mori doGet: '+err.message);
  var message=String(err.message||err).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});
  return HtmlService.createHtmlOutput('<!doctype html><html lang="vi"><head><meta charset="utf-8"></head><body style="font:16px Arial,sans-serif;padding:32px;color:#213b31"><h1>Không thể mở Mori</h1><p>'+message+'</p><p>Kiểm tra tên file HTML là Index; lưu code và cập nhật deployment sang New version.</p><small>Build '+MORI_SERVER_BUILD+'</small></body></html>').setTitle('Mori - Lỗi khởi tạo').addMetaTag('viewport','width=device-width, initial-scale=1.0');
 }
}

/** Return the actual deployed /exec URL; never derive a customer link from the iframe URL. */
function moriPublishLinks(token){var actor=moriActor_(token);moriRequire_(actor,['ADMIN']);
 var base='';try{base=String(ScriptApp.getService().getUrl()||'').trim();}catch(e){}
 if(!/^https:\/\/script\.google\.com\/macros\/s\/[^/?#]+\/exec$/.test(base)){
  return {ok:true,publicUrl:'',bookingUrl:'',error:'Không lấy được URL /exec. Hãy deploy Web App và kiểm tra quyền truy cập cho khách.'};
 }
 var cfg=moriFind_('PublishSite','site')||{},s=moriFind_('Settings','global')||{};
 return {ok:true,publicUrl:base+'?view=shop',bookingUrl:base+'?view=shop&tab=booking',published:cfg.published===true&&s.modules?.publishSite!==false};
}

function moriRawIndex_(){return HtmlService.createTemplateFromFile('Index').getRawContent();}

/** Select exactly one self-contained Mori app closure. Ignore script-looking text
 * in comments and do not silently deliver a different or partial script.
 */
function moriRuntimeSource_(html){
 var re=/<!--[\s\S]*?-->|<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi,match,candidates=[];
 while((match=re.exec(html))!==null){
  if(match[1]!==undefined&&/^\s*\(\(\)\s*=>\s*\{\s*['"]use strict['"];/.test(match[1])&&match[1].indexOf('function moriStart(')>=0){
   candidates.push({start:match.index,end:re.lastIndex,source:match[1]});
  }
 }
 if(candidates.length!==1)throw new Error('Không tìm thấy duy nhất khối JavaScript chính trong Index. Hãy dùng Index.html của bộ Boot Fix 3.0.4.');
 return candidates[0];
}
function moriRuntimeMetadata_(source){
 var sha=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,source,Utilities.Charset.UTF_8).map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2);}).join('');
 return {build:MORI_SERVER_BUILD,sha256:sha,characters:source.length};
}

/** Public static source only: no tokens, Sheets records or private configuration.
 * google.script.run transports this as data after the HTML shell has loaded.
 */
function moriFrontendRuntime(expectedSha256){
 var source=moriRuntimeSource_(moriRawIndex_()).source,meta=moriRuntimeMetadata_(source);
 if(expectedSha256&&expectedSha256!==meta.sha256)throw new Error('Mã giao diện đã thay đổi giữa hai lần tải. Hãy tải lại trang để dùng cùng một phiên bản.');
 meta.base64=Utilities.base64Encode(source,Utilities.Charset.UTF_8);
 return meta;
}

/** This private function is serialized into the HTML shell, never run on server.
 * It inserts trusted application source via a script element, not document.write.
 */
function moriRuntimeLoader_(expected){
 var settled=false,timer=null,boot=window.MoriBoot,loaderNode=document.currentScript;
 var nonce=loaderNode&&loaderNode.nonce||'';
 function fail(error){
  if(settled)return;
  settled=true;clearTimeout(timer);
  var message=String(error&&error.message||error||'Runtime load failed');
  if(boot)boot.fail(new Error('Loader '+expected.build+' | '+message));
 }
 function detail(event){
  var message=event.message||event.error&&event.error.message||'JavaScript runtime error';
  if(event.filename)message+='\nSource: '+event.filename;
  if(event.lineno)message+='\nLine: '+event.lineno+' | Column: '+(event.colno||0);
  fail(new Error(message));
 }
 function install(source){
  if(settled)return;
  if(boot)boot.stage('Đang khởi chạy giao diện…');
  var script=document.createElement('script');
  script.id='mori-loaded-runtime';
  if(nonce)script.nonce=nonce;
  script.text=source+'\n;window.__MORI_RUNTIME_OK='+JSON.stringify(expected.sha256)+';\n//# sourceURL=MoriRuntime_'+expected.build+'.js\n';
  window.addEventListener('error',detail);
  try{
   document.head.appendChild(script);
   if(!settled&&window.__MORI_RUNTIME_OK!==expected.sha256)fail(new Error('Khối JavaScript chính chưa chạy xong. Kiểm tra dòng lỗi trong Console.'));
   if(!settled){settled=true;clearTimeout(timer);}
  }catch(error){fail(error);}
  finally{window.removeEventListener('error',detail);}
 }
 function loaded(payload){
  if(settled)return;
  try{
   if(!payload||payload.sha256!==expected.sha256||payload.characters!==expected.characters||typeof payload.base64!=='string')throw new Error('Thông tin mã giao diện không khớp. Hãy tải lại trang.');
   if(boot)boot.stage('Đang kiểm tra mã giao diện…');
   var binary=atob(payload.base64),bytes=new Uint8Array(binary.length);
   for(var i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
   if(!window.crypto||!window.crypto.subtle||typeof TextDecoder==='undefined')throw new Error('Trình duyệt chưa hỗ trợ kiểm tra mã giao diện. Hãy mở /exec bằng Chrome hoặc Edge đã cập nhật.');
   window.crypto.subtle.digest('SHA-256',bytes).then(function(digest){
    if(settled)return;
    try{
     var hash=Array.prototype.map.call(new Uint8Array(digest),function(b){return ('0'+b.toString(16)).slice(-2);}).join('');
     if(hash!==expected.sha256)throw new Error('Mã giao diện nhận được khác mã trên máy chủ (SHA-256). Hãy tải lại trang.');
     var source=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
     if(source.length!==expected.characters)throw new Error('Độ dài mã giao diện không khớp.');
     install(source);
    }catch(error){fail(error);}
   },fail);
  }catch(error){fail(error);}
 }
 if(!boot){throw new Error('Thiếu bộ khởi động MoriBoot. Hãy dùng Index.html của bộ Boot Fix 3.0.4.');}
 boot.stage('Đang tải mã giao diện…');
 if(typeof google==='undefined'||!google.script||!google.script.run){fail(new Error('Không kết nối được Google Apps Script. Hãy mở đường dẫn /exec.'));return;}
 timer=setTimeout(function(){fail(new Error('Không nhận được mã giao diện sau 20 giây (moriFrontendRuntime).'));},20000);
 try{google.script.run.withSuccessHandler(loaded).withFailureHandler(fail).moriFrontendRuntime(expected.sha256);}
 catch(error){fail(error);}
}
function moriDocumentParts_(html){
 var markup=html.replace(/<!--[\s\S]*?-->|<(script|style)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,function(block){return block.replace(/[^\r\n]/g,' ');});
 return {markup:markup,head:/<head\b[^>]*>/i.exec(markup),body:/<body\b[^>]*>/i.exec(markup)};
}

/** Read-only editor diagnostic. ok means basic structure is present, not a runtime pass.
 * Marker/hash differences are advisory and never stop doGet().
 */
function moriFrontendCheck(){
 var html=moriRawIndex_();
 var parts=moriDocumentParts_(html);
 var hash=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,html,Utilities.Charset.UTF_8).map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2);}).join('');
 var starts=(html.match(/<script\b/gi)||[]).length,ends=(html.match(/<\/script\s*>/gi)||[]).length;
 var report={build:MORI_SERVER_BUILD,expectedFrontendBuild:MORI_FRONTEND_BUILD,source:'HtmlTemplate.getRawContent',characters:html.length,sha256:hash,exactFileMatch:hash===MORI_FRONTEND_SHA256,
  startMarker:html.indexOf('MORI_FRONTEND_BUILD:'+MORI_FRONTEND_BUILD)>=0,endMarker:html.indexOf('MORI_FRONTEND_END:'+MORI_FRONTEND_BUILD)>=0,
  hasHead:!!parts.head,hasBody:!!parts.body,hasAppRoot:/\bid\s*=\s*["']app["']/i.test(parts.markup),
  hasDocumentEnd:/<\/html\s*>\s*$/i.test(parts.markup),scriptOpen:starts,scriptClose:ends,warnings:[]};
 try{
  var runtime=moriRuntimeSource_(html),meta=moriRuntimeMetadata_(runtime.source);
  report.runtimeCharacters=meta.characters;report.runtimeSha256=meta.sha256;report.runtimeTransport='google.script.run + Base64 + SHA-256';
 }catch(runtimeError){report.warnings.push(runtimeError.message);}
 report.ok=report.hasHead&&report.hasBody&&report.hasAppRoot&&report.hasDocumentEnd&&starts>0&&starts===ends;
 if(!report.startMarker||!report.endMarker)report.warnings.push('Marker không khớp bản tham chiếu. Đây là thông tin đối chiếu, không phải kết luận file thiếu/hỏng.');
 if(!report.exactFileMatch)report.warnings.push('Nội dung khác bản Index 3.0.4 tham chiếu. Thay đổi xuống dòng/khoảng trắng cũng làm SHA-256 khác.');
 console.log(JSON.stringify(report,null,2));
 return report;
}
function getGoogleSession(){return {email:Session.getActiveUser().getEmail()||'',verified:false};}
