# MoriPOS v3.2.7 — UI-only release

Scope: Staff Role, Staff Branch multi-select, Item Sale Status, Holiday Pricing and Holiday Calendar option menus.

Changed code files: `Index.html` and `Code.gs` only. No Sheets schema, transaction logic, API contract or data migrations.

Recommended for v3.2.6 deployment: Quick Patch. Run `moriFrontendCheck()` and deploy a **New version**.
