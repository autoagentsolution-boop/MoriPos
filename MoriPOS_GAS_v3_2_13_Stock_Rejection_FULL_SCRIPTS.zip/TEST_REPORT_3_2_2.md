# MoriPOS 3.2.2 local tests

- 16 Node.js suites, **135 PASS groups**.
- Regression checks cover POS bootstrap, login/OTP allowlist, authorization, invoice/POS, Forecast, Analytics, Customer identity and Publish URL.
- New checks: native Manager role selector, many-branch compact dropdown, inner-modal click not blocked by backdrop, status toggle, Publish Site button alignment/copy, one `publish.save` call, no premature success toast, and local-state update only after server success.
- SHA-256 of Index.html matches Code.gs build 3.2.2, no stale version markers.
- No real browser or Google Apps Script production deployment tests were run. These checks do not guarantee behavior on the deployed web app.
