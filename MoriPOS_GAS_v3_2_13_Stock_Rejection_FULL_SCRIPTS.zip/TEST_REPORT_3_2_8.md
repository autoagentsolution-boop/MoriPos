# MoriPOS v3.2.8 — Shared Mori Dropdown UI QC

- `node tests/run-tests.js`: **19 suites, 157 reported PASS groups** (existing regression cases; assertions updated for 3.2.8 where necessary).
- `node tests/rounded-dropdown-327.test.js`: **4 PASS groups** for the new shared dropdown contract.
- `node tests/holiday-ui-325.test.js`: **5 PASS groups** for Settings/Calendar.
- Chromium browser smoke: **Items** active status, **Holiday Settings** enabled switch and annual recurrence; opening a dropdown does not auto-focus/highlight the first option; Escape closes only the popup.
- Chromium staff modal smoke: Manager selection works; multi-branch selection remains open and retains both selected branches; Escape closes only its popup.
- Frontend runtime syntax verified with Node; `Index.html` SHA-256 matches `Code.gs`.
- Backend business files untouched. This is **not** a live Apps Script deployment or Sheets persistence test.
