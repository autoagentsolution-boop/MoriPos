# MoriPOS v3.2.1

Status: locally validated release candidate, **not yet production verified**.

Three modified files: `Index.html`, `Code.gs`, `Security.gs`.
One added file: `MoriPreflight321.gs`.

No schema migration and no need to reinstall Analytics or Customers. Full ZIP is a complete project source set based on v3.2.0; quick patch has only files needed for this release. See `README_UPGRADE_3_2_1.md`.
