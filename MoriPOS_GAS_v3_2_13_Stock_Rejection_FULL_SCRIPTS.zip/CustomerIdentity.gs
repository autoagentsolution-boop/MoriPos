/** Mori 3.2.0 B - verified customer identity, separate from staff sessions and POS privileges. */
function moriCustomerReady_(){return moriProp_('CUSTOMERS_READY')==='1'&&!!moriProp_('FILE_CUSTOMERS');}
function moriCustomerEmail_(v){var email=String(v||'').toLowerCase().trim();moriEnsure_(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)&&email.length<=180,'Email khách hàng không hợp lệ');return email;}
function moriCustomerDigest_(v){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(v),Utilities.Charset.UTF_8).map(function(b){return ('0'+((b+256)%256).toString(16)).slice(-2);}).join('');}
function moriCustomerIdentityId_(email){return moriCustomerDigest_(moriCustomerEmail_(email));}
function moriCustomerTokenKey_(token){return 'mori:cust:session:'+moriCustomerDigest_(token).slice(0,36);}
function moriCustomerActor_(token){
 moriEnsure_(moriCustomerReady_(),'Chức năng khách hàng chưa được khởi tạo');
 moriEnsure_(typeof token==='string'&&token.length>40,'Vui lòng xác thực email khách hàng');
 var cache=CacheService.getScriptCache(),raw=cache.get(moriCustomerTokenKey_(token));moriEnsure_(raw,'Phiên khách hàng đã hết hạn');
 var data=JSON.parse(raw),ident=moriFind_('GuestIdentities',data.id);moriEnsure_(ident&&ident.isActive!==false&&ident.email===data.email,'Danh tính không còn hợp lệ');
 var link=moriFind_('CustomerIdentityLinks',ident.id);
 return {id:ident.id,email:ident.email,memberId:link&&link.active!==false?Number(link.customerId)||0:0};
}
function moriCustomerAuthStart(email){
 moriEnsure_(moriCustomerReady_(),'POS_Customers chưa được khởi tạo bởi chủ cửa hàng');
 email=moriCustomerEmail_(email);
 var digest=moriCustomerIdentityId_(email),cache=CacheService.getScriptCache(),cool='mori:cust:cool:'+digest.slice(0,24);
 moriEnsure_(!cache.get(cool),'Vui lòng chờ 60 giây trước khi lấy mã tiếp');cache.put(cool,'1',60);
 var salt=Utilities.getUuid()+'-'+Utilities.getUuid(),bytes=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,salt),num=bytes.slice(0,4).reduce(function(v,b){return v*256+(b+256)%256;},0)%1000000,code=('000000'+num).slice(-6);
 var hash=moriCustomerDigest_(code+':'+salt);
 cache.put('mori:cust:otp:'+digest.slice(0,32),JSON.stringify({email:email,salt:salt,hash:hash,tries:0}),300);
 MailApp.sendEmail({to:email,subject:'Mori — Mã xác thực email',body:'Mã xác thực: '+code+'\nHiệu lực 5 phút. Không chia sẻ mã này.'});
 return {ok:true,message:'Mã xác thực đã được gửi đến email.'};
}
function moriCustomerAuthVerify(email,code){
 moriEnsure_(moriCustomerReady_(),'Chức năng khách hàng chưa được khởi tạo');email=moriCustomerEmail_(email);
 var id=moriCustomerIdentityId_(email),cache=CacheService.getScriptCache(),key='mori:cust:otp:'+id.slice(0,32),raw=cache.get(key);
 moriEnsure_(raw,'Mã đã hết hạn hoặc chưa được yêu cầu');var data=JSON.parse(raw);moriEnsure_(data.email===email&&data.tries<3,'Mã không hợp lệ');
 if(!/^\d{6}$/.test(String(code||''))||moriCustomerDigest_(String(code)+':'+data.salt)!==data.hash){data.tries++;cache.put(key,JSON.stringify(data),300);throw Error('Mã xác thực không đúng');}
 cache.remove(key);
 moriLock_(function(){var prev=moriFind_('GuestIdentities',id);if(!prev)moriInsert_('GuestIdentities',{id:id,email:email,verifiedAt:moriNow_(),isActive:true});else{prev.verifiedAt=moriNow_();moriPut_('GuestIdentities',prev,prev.version);}});
 var token=Utilities.getUuid()+'-'+Utilities.getUuid();cache.put(moriCustomerTokenKey_(token),JSON.stringify({id:id,email:email}),21600);
 return {ok:true,token:token,profile:moriCustomerSession(token)};
}
function moriCustomerAuthLogout(token){if(typeof token==='string'&&token.length>40)CacheService.getScriptCache().remove(moriCustomerTokenKey_(token));return {ok:true};}
function moriCustomerSession(token){var actor=moriCustomerActor_(token),member=actor.memberId?moriFind_('Customers',actor.memberId):null;
 return {ok:true,email:actor.email,member:member?{id:member.id,name:member.name,phone:member.phone,tier:member.tier||null}:null};
}
/** Guest verification is proof of email ownership, not consent to receive marketing. */
function moriCustomerMemberSave_(staff,p){
 moriRequire_(staff,['ADMIN','MANAGER','EMPLOYEE']);moriEnsure_(moriCustomerReady_(),'Chủ cửa hàng cần khởi tạo POS_Customers trước');p=p||{};
 var name=String(p.name||'').trim(),phone=String(p.phone||'').replace(/\s/g,'').trim();
 moriEnsure_(name.length>=2&&name.length<=120,'Nhập tên khách hàng');
 moriEnsure_(/^[+0-9().-]{8,22}$/.test(phone),'Số điện thoại khách hàng không hợp lệ');
 var proof=p.customerProofToken?moriCustomerActor_(p.customerProofToken):null;
 if(p.email&&proof)moriEnsure_(moriCustomerEmail_(p.email)===proof.email,'Email chứng thực không khớp');
 var old=p.id?moriFind_('Customers',p.id):null;
 if(p.id)moriEnsure_(old,'Không tìm thấy thành viên');if(old)moriRequire_(staff,['ADMIN','MANAGER'],old.branchId||staff.branchIds[0]);
 if(!old&&moriAll_('Customers',false).some(function(c){return String(c.phone||'').replace(/\s/g,'')===phone;}))throw Error('Số điện thoại đã tồn tại. Hãy chọn thành viên hiện có để cập nhật.');
 var id=old?old.id:moriNext_('CUSTOMER'),doc=old?moriDeep_(old):{id:id,memberSince:moriNow_(),status:'MEMBER'};
 doc.name=name;doc.phone=phone;doc.customerGroup=p.customerGroup||doc.customerGroup||'Member';doc.consentMarketing=p.consentMarketing===true;
 doc.status='MEMBER';doc.branchId=Number(p.branchId||staff.branchIds[0]||1);moriRequire_(staff,['ADMIN','MANAGER','EMPLOYEE'],doc.branchId);
 if(proof){
  var current=moriFind_('CustomerIdentityLinks',proof.id);
  moriEnsure_(!current||current.active===false||Number(current.customerId)===Number(id),'Email này đã thuộc về thành viên khác');
  doc.email=proof.email;doc.emailVerifiedAt=moriNow_();
 }else if(p.email)doc.pendingEmail=moriCustomerEmail_(p.email); // pending only: no merge/link from unverified email
 doc=old?moriPut_('Customers',doc,p.version??old.version):moriInsert_('Customers',doc);
 if(proof){
  var prev=moriFind_('CustomerIdentityLinks',proof.id),link={id:proof.id,identityId:proof.id,email:proof.email,customerId:id,active:true,verifiedAt:moriNow_()};
  if(prev)moriPut_('CustomerIdentityLinks',Object.assign(prev,link),prev.version);else moriInsert_('CustomerIdentityLinks',link);
  if(typeof moriCustomerMarkIdentityDays_==='function')moriCustomerMarkIdentityDays_(proof.id);
 }
 moriAudit_(staff.email,old?'UPDATE':'CREATE','MEMBER',id,old,doc);
 return {id:doc.id,name:doc.name,phone:doc.phone,email:doc.email||'',linked:!!proof};
}
function moriCustomerMemberSave(token,p){return moriLock_(function(){return moriCustomerMemberSave_(moriActor_(token),p);});}
/** Claim an older email-only online order with BOTH verified email and its private tracking token. */
function moriCustomerClaimOrder_(customerToken,trackingToken){
 var actor=moriCustomerActor_(customerToken),token=String(trackingToken||'').trim();
 moriEnsure_(token.length>=64&&token.length<=160,'Mã theo dõi đơn không hợp lệ');
 var b=moriFindJsonString_('Bills','trackingToken',token);
 moriEnsure_(b&&b.channel==='ONLINE'&&String(b.shipping?.email||'').toLowerCase()===actor.email,'Đơn không thuộc email đã xác thực hoặc mã không đúng');
 moriEnsure_(!b.guestIdentityId||b.guestIdentityId===actor.id,'Đơn đã liên kết với tài khoản khác');
 moriEnsure_(!Number(b.customerId)||Number(b.customerId)===actor.memberId,'Đơn đã thuộc thành viên khác');
 if(b.guestIdentityId===actor.id)return {ok:true,alreadyLinked:true,billNo:b.no};
 var before=moriDeep_(b);b.guestIdentityId=actor.id;if(actor.memberId)b.customerId=actor.memberId;
 b=moriPut_('Bills',b,b.version);moriAudit_(actor.email,'LINK','CUSTOMER_ORDER',b.id,before,b);
 // Make the claimed order visible immediately, while the CustomerDaily worker handles KPIs.
 moriCustomerProcessBill_(b);
 return {ok:true,linked:true,billNo:b.no};
}
function moriCustomerClaimMyOrder(customerToken,trackingToken){return moriLock_(function(){return moriCustomerClaimOrder_(customerToken,trackingToken);});}
function moriCustomerClaimForMember(staffToken,customerToken,trackingToken){return moriLock_(function(){var staff=moriActor_(staffToken),bill=moriFindJsonString_('Bills','trackingToken',String(trackingToken||''));moriEnsure_(bill,'Mã theo dõi không tồn tại');moriRequire_(staff,['ADMIN','MANAGER','EMPLOYEE'],bill.branchId);return moriCustomerClaimOrder_(customerToken,trackingToken);});}
function moriCustomerOrders(token,page,pageSize){
 var actor=moriCustomerActor_(token),keys=[actor.id];if(actor.memberId)keys.push('member|'+actor.memberId);
 var s=moriSheet_('CustomerOrderLinks'),last=s.getLastRow(),found=[];
 if(last>1)keys.forEach(function(key){s.getRange(2,3,last-1,1).createTextFinder(key).matchCase(true).matchEntireCell(true).findAll().forEach(function(cell){found.push(cell.getRow());});});
 found=Array.from(new Set(found)).sort(function(a,b){return b-a;});var max=Math.min(50,Math.max(1,Number(pageSize)||10)),p=Math.max(1,Number(page)||1);
 var docs=found.slice((p-1)*max,p*max).map(function(row){try{return JSON.parse(s.getRange(row,8).getValue());}catch(_){return null;}}).filter(Boolean);
 return {ok:true,page:p,total:found.length,rows:docs.map(function(x){return {billId:x.billId,no:x.no,channel:x.channel,branchId:x.branchId,day:x.day,createdAt:x.day+'T00:00:00+07:00',status:x.status,orderStatus:x.orderStatus,finalTotal:x.total,total:x.total,items:x.items||[]};})};
}
/** Staff may check an email history only after the customer supplied a valid OTP. */
function moriCustomerGuestLookup(staffToken,customerProofToken){
 var staff=moriActor_(staffToken);moriRequire_(staff,['ADMIN','MANAGER','EMPLOYEE']);var guest=moriCustomerActor_(customerProofToken);
 var sh=moriSheet_('CustomerOrderLinks'),last=sh.getLastRow(),orders=0;
 if(last>1)orders=sh.getRange(2,3,last-1,1).createTextFinder(guest.id).matchEntireCell(true).matchCase(true).findAll().filter(function(c){if(staff.role==='ADMIN')return true;try{var x=JSON.parse(sh.getRange(c.getRow(),8).getValue());return staff.branchIds.map(Number).indexOf(Number(x.branchId))>=0;}catch(_){return false;}}).length;
 return {ok:true,email:guest.email,linkedMemberId:guest.memberId||0,verified:true,onlineHistoryCount:orders};
}
function moriCustomerVerifyImport_(source,target){
 moriEnsure_(source.getLastRow()===target.getLastRow(),'Customers nguồn/đích khác số dòng');
 var last=source.getLastRow();for(var row=1;row<=last;row+=400){var n=Math.min(400,last-row+1),a=source.getRange(row,1,n,8).getValues(),b=target.getRange(row,1,n,8).getValues();
  moriEnsure_(JSON.stringify(a)===JSON.stringify(b),'Customers khác nhau ở dòng '+row+'; chưa chuyển dữ liệu');}
}
/** Migration: new workbook is a copy; old MASTER Customers is retained as rollback. */
function moriCustomerInstall(){moriEditorOnly_();return moriLock_(function(){
 var fileId=moriProp_('FILE_CUSTOMERS'),root=moriProp_('ROOT_FOLDER'),book=fileId?SpreadsheetApp.openById(fileId):SpreadsheetApp.create('POS_Customers');
 if(!fileId){moriSetProp_('FILE_CUSTOMERS',book.getId());if(root)DriveApp.getFileById(book.getId()).moveTo(DriveApp.getFolderById(root));}
 MORI_BOOK_HANDLES_.CUSTOMERS=book;
 var master=SpreadsheetApp.openById(moriProp_('FILE_MASTER'));moriEnsure_(master.getId()!==book.getId(),'POS_Customers không được trùng POS_Master');
 var source=master.getSheetByName('Customers'),target=book.getSheetByName('Customers');
 if(moriProp_('CUSTOMERS_READY')!=='1'&&source&&source.getLastRow()>1){
  if(!target||target.getLastRow()<=1){
   var copy=source.copyTo(book);copy.setName('__CUSTOMER_IMPORT_'+Utilities.getUuid().slice(0,6));
   moriCustomerVerifyImport_(source,copy);
   if(target)book.deleteSheet(target);copy.setName('Customers');target=copy;
  }else moriCustomerVerifyImport_(source,target);
 }
 ['Customers','GuestIdentities','CustomerIdentityLinks','CustomerOrderLinks','CustomerDayIndex'].forEach(function(t){var sh=book.getSheetByName(t)||book.insertSheet(t);if(sh.getLastRow()===0){sh.getRange(1,1,1,8).setValues([MORI_HEADERS]);sh.setFrozenRows(1);sh.getRange('A:A').setNumberFormat('@');sh.getRange('H:H').setNumberFormat('@');}moriEnsure_(JSON.stringify(sh.getRange(1,1,1,8).getValues()[0])===JSON.stringify(MORI_HEADERS),'Cấu trúc '+t+' không hợp lệ');});
 // Preserve numeric Customer IDs when migrating existing members: new IDs must never collide.
 var memberSheet=book.getSheetByName('Customers'),memberLast=memberSheet.getLastRow(),maxMember=Number(moriProp_('SEQ_CUSTOMER')||0);
 if(memberLast>1)memberSheet.getRange(2,1,memberLast-1,1).getValues().forEach(function(row){var n=Number(row[0]);if(Number.isSafeInteger(n)&&n>maxMember)maxMember=n;});
 if(maxMember>Number(moriProp_('SEQ_CUSTOMER')||0))moriSetProp_('SEQ_CUSTOMER',maxMember);
 moriEnsure_(moriProp_('FILE_DASHBOARD'),'Cần cài Analytics và POS_Dashboard trước');
 var dashboard=SpreadsheetApp.openById(moriProp_('FILE_DASHBOARD')),daily=dashboard.getSheetByName('CustomerDaily')||dashboard.insertSheet('CustomerDaily');
 if(daily.getLastRow()===0){daily.getRange(1,1,1,8).setValues([MORI_ANALYTICS_HEADERS_]);daily.setFrozenRows(1);}moriEnsure_(JSON.stringify(daily.getRange(1,1,1,8).getValues()[0])===JSON.stringify(MORI_ANALYTICS_HEADERS_),'CustomerDaily chưa đúng cấu trúc');
 moriSetProp_('CUSTOMERS_READY','1');if(!moriProp_('CUSTOMER_BACKFILL_CURSOR'))moriSetProp_('CUSTOMER_BACKFILL_CURSOR','2');delete MORI_SHEET_HANDLES_.Customers;delete MORI_DATA_STATE_.Customers;
 var old=ScriptApp.getProjectTriggers().filter(function(t){return t.getHandlerFunction()==='moriCustomerAnalyticsWorker_';});
 if(!old.length)ScriptApp.newTrigger('moriCustomerAnalyticsWorker_').timeBased().everyMinutes(5).create();
 return {ok:true,customersUrl:'https://docs.google.com/spreadsheets/d/'+book.getId()+'/edit',dashboardUrl:'https://docs.google.com/spreadsheets/d/'+dashboard.getId()+'/edit',legacyPreserved:true,triggerCreated:!old.length};
});}
