/** Billing, online order and shipping transitions; checked under one Apps Script lock. */
function moriPricing_(raw,branchId,online,index){
 index=index||moriItemIndex_();var publish=online?(moriFind_('PublishSite','site')||{}):{};
 var settings=moriFind_('Settings','global')||{},day=moriDate_();
 moriEnsure_(Array.isArray(raw)&&raw.length>0&&raw.length<=80,'Danh sách mặt hàng không hợp lệ');
 return raw.map(function(l){var i=index[String(l.id)];moriEnsure_(i&&i.isActive!==false,'Mặt hàng không còn bán');
  var q=Number(l.qty);moriEnsure_(q>0&&q<=100000&&isFinite(q),'Số lượng không hợp lệ');
  if(online&&publish.categoryVisibility&&publish.categoryVisibility[i.cat]===false)throw new Error('Danh mục không công khai');
  if(online&&publish.itemRules&&publish.itemRules[i.id]&&publish.itemRules[i.id].visible===false)throw new Error('Mặt hàng không công khai');
  var pricing=typeof moriItemPrice_==='function'?moriItemPrice_(i,settings.holidayPricing,day):{price:Number(i.price)||0,source:'REGULAR'};var base=pricing.price,price=base;
  if(online){var r=(publish.itemRules||{})[i.id]||{};if(r.type==='PERCENT')price=Math.round(base*(1-Math.min(100,Math.max(0,Number(r.value)||0))/100));if(r.type==='FIXED')price=Math.max(0,base-(Number(r.value)||0));}
  return {id:i.id,name:i.name,qty:q,unitPrice:price,catalogPriceAtAdd:base,priceType:pricing.source,cost:moriRecipe_(i.id,index,branchId,1).cost,lineKey:String(l.lineKey||'').slice(0,100),employeeId:String(l.employeeId||'')};
 });
}
function moriBillTotals_(items,discount,discountFixed,tip){var subtotal=items.reduce(function(n,l){return n+Number(l.qty)*Number(l.unitPrice);},0),disc=Math.min(subtotal,Math.round(subtotal*Math.min(100,Math.max(0,Number(discount)||0))/100)+Math.max(0,Number(discountFixed)||0));
 return {subtotal:subtotal,discountTotal:disc,tipAmount:Math.max(0,Number(tip)||0),finalTotal:Math.max(0,subtotal-disc)+Math.max(0,Number(tip)||0)};}
function moriCreateOfflineBill_(actor,raw,paid){
 moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],raw.branchId);
 var requestId=String(raw.clientRequestId||'');moriEnsure_(requestId.length<=128,'Mã yêu cầu quá dài');
 var oldBill=requestId?moriFindJsonString_('Bills','clientRequestId',requestId):null;
 // Only a server-versioned draft may use the ID fallback. New browser IDs are temporary.
 if(!oldBill&&raw.id&&raw.persisted===true){
  oldBill=moriFind_('Bills',raw.id);moriEnsure_(oldBill,'Bill không còn tồn tại');
  moriEnsure_(!oldBill.clientRequestId||oldBill.clientRequestId===requestId,'Mã yêu cầu không khớp Bill');
 }
 if(oldBill){
  moriEnsure_(oldBill.channel==='OFFLINE'&&Number(oldBill.branchId)===Number(raw.branchId),'Bill không thuộc chi nhánh/kênh hợp lệ');
  moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],oldBill.branchId);
  moriRecordBillEdits_(actor,raw.auditBatches||[],{clientRequestId:requestId,branchId:raw.branchId});
  if(oldBill.status==='COMMITTING'&&paid){
   moriStockDelta_(oldBill.inventoryNeeds||{},oldBill.branchId,'BILL:'+oldBill.id,-1,moriItemIndex_());
   oldBill.status='PAID';oldBill.inventoryConsumed=true;oldBill.paymentStatus='CONFIRMED';oldBill.paidAt=oldBill.paidAt||moriNow_();
   var resumed=moriPut_('Bills',oldBill,oldBill.version);moriAudit_(actor.email,'PAY','BILL',resumed.id,null,resumed);return resumed;
  }
  if(oldBill.status!=='OPEN')return oldBill;
 }
 if(!oldBill)moriRecordBillEdits_(actor,raw.auditBatches||[],{clientRequestId:requestId,branchId:raw.branchId});
 var beforeBill=oldBill?moriDeep_(oldBill):null;
 var settings=moriFind_('Settings','global')||{},branch=moriFind_('Branches',raw.branchId);moriEnsure_(branch,'Chi nhánh không tồn tại');
 var index=moriItemIndex_(),lines=moriPricing_(raw.items||[],raw.branchId,false,index);
 lines.forEach(function(line,j){var custom=Number(raw.items[j].unitPrice);if(raw.items[j].unitPrice!==undefined&&raw.items[j].unitPrice!==null&&Number.isFinite(custom)&&custom>=0&&custom<=1000000000){if(custom!==line.unitPrice)line.priceType='MANUAL';line.unitPrice=custom;line.catalogPriceAtAdd=Number(raw.items[j].catalogPriceAtAdd??line.catalogPriceAtAdd);}});
 var tot=moriBillTotals_(lines,raw.discount,raw.discountFixed,raw.tipAmount);
 var needs=paid?moriInventoryValidate_(lines,raw.branchId,oldBill?.id,index,settings):{};
 if(Number(raw.customerId)>0){var member=moriFind_('Customers',raw.customerId);moriEnsure_(member&&(!member.status||member.status==='MEMBER'),'Thành viên không tồn tại');}
 var id=oldBill?oldBill.id:moriNext_('BILL'),doc={...(oldBill||{}),id:id,no:oldBill?.no||branch.code+'-'+moriDate_().replace(/-/g,'')+'-'+String(id).padStart(5,'0'),branchId:Number(raw.branchId),channel:'OFFLINE',status:paid?'COMMITTING':'OPEN',orderStatus:'',paymentStatus:'PENDING',method:raw.method||'BANK_TRANSFER',items:lines,customerId:raw.customerId||0,customerName:String(raw.customerName||'Khách lẻ').slice(0,160),resource:String(raw.resource||'').slice(0,100),clientRequestId:requestId,discount:Number(raw.discount)||0,discountFixed:Number(raw.discountFixed)||0,billEmployeeId:raw.billEmployeeId||'',tipEmployeeIds:raw.tipEmployeeIds||[],createdBy:actor.email,inventoryNeeds:needs,inventoryConsumed:false};
 Object.assign(doc,tot);doc.paidAmountAtCheckout=paid?tot.finalTotal:(oldBill?.paidAmountAtCheckout||0);doc.tipAtCheckout=paid?tot.tipAmount:0;
 doc=oldBill?moriPut_('Bills',doc,raw.version??oldBill.version):moriInsert_('Bills',doc);
 if(paid){
  moriStockDelta_(needs,doc.branchId,'BILL:'+doc.id,-1,index);
  doc.status='PAID';doc.inventoryConsumed=true;doc.paymentStatus='CONFIRMED';doc.paidAt=moriNow_();doc=moriPut_('Bills',doc,doc.version);
 }
 moriAudit_(actor.email,paid?'PAY':oldBill?'UPDATE':'CREATE','BILL',id,beforeBill,doc);return doc;
}
/** One authenticated commit + its authorized UI changes. No post-payment reload. */
function moriCheckout(token,payload){
 var started=Date.now(),p=payload||{};moriEnsure_(typeof p.clientRequestId==='string'&&p.clientRequestId.length>=12&&p.clientRequestId.length<=128,'Thiếu mã yêu cầu thanh toán');
 var result=moriLock_(function(){
  var authStart=Date.now(),actor=moriActor_(token),authMs=Date.now()-authStart,commitStart=Date.now(),bill=moriCreateOfflineBill_(actor,p,true),commitMs=Date.now()-commitStart;
  moriEnsure_(bill.status==='PAID','Bill chưa hoàn tất thanh toán');
  var ids=Object.keys(bill.inventoryNeeds||{}),items=ids.map(function(id){return moriFind_('Items',id);}).filter(Boolean);
  var audits=Object.keys(MORI_CHANGED_DOCS_.Audit||{}).map(function(id){return MORI_CHANGED_DOCS_.Audit[id];});
  return {ok:true,stageTiming:{authMs:authMs,commitMs:commitMs},bill:moriForActor_(actor,'Bills',bill),changes:{Bills:[moriForActor_(actor,'Bills',bill)],ItemUpdates:moriReadFilter_(actor,'Items',items),AuditUpdates:actor.role==='ADMIN'?audits:[]}};
 });
 result.timing={serverMs:Date.now()-started,lockWaitMs:MORI_LOCK_WAIT_MS_,authMs:result.stageTiming.authMs,commitMs:result.stageTiming.commitMs};delete result.stageTiming;
 console.info('Mori checkout timing '+JSON.stringify(result.timing));return result;
}
function moriPaidBillEdit_(actor,id,version,patch){var doc=moriFind_('Bills',id);moriEnsure_(doc&&doc.status==='PAID','Chỉ cho sửa Bill đã thanh toán');moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],doc.branchId);
 var settings=moriFind_('Settings','global')||{},allowed=(settings.paidBillEditRoles||{});moriEnsure_(allowed[actor.role]===true||actor.role==='ADMIN','Bạn không được chỉnh sửa Bill');
 moriEnsure_(Number(doc.version)===Number(version),'VERSION_CONFLICT');var before=moriDeep_(doc),tip=Number(patch.tipAmount);
 moriEnsure_(Number.isSafeInteger(tip)&&tip>=0&&tip<=9999999999,'Tip không hợp lệ');
 moriEnsure_(Array.isArray(patch.itemEmployees)&&patch.itemEmployees.length===doc.items.length,'Sai số dòng sản phẩm');
 var valid=new Set(moriAll_('Employees',false).filter(function(e){return e.isActive!==false;}).map(function(e){return String(e.email);}));valid.add('');
 moriEnsure_(valid.has(String(patch.billEmployeeId||''))&&patch.itemEmployees.every(function(x){return valid.has(String(x||''));})&&(patch.tipEmployeeIds||[]).every(function(x){return valid.has(String(x||''));}),'Nhân viên không hợp lệ');
 doc.tipAmount=tip;doc.tipEmployeeIds=(patch.tipEmployeeIds||[]).map(String);doc.billEmployeeId=String(patch.billEmployeeId||'');doc.items.forEach(function(l,j){l.employeeId=String(patch.itemEmployees[j]||'');});
 doc.finalTotal=Number(doc.subtotal)-Number(doc.discountTotal||0)+tip; // paidAmountAtCheckout never changes
 doc=moriPut_('Bills',doc,version);moriAudit_(actor.email,'UPDATE_TIP_ASSIGNMENT','BILL',id,before,doc);return doc;
}
function moriOnlineCreate_(actor,request,isPublic){var publish=moriFind_('PublishSite','site')||{},settings=moriFind_('Settings','global')||{};
 if(isPublic)moriEnsure_(publish.published===true&&settings.modules&&settings.modules.onlineOrder===true&&publish.mode==='ORDER_ONLINE','Không nhận đơn online');
 var branchId=Number(request.branchId),branch=moriFind_('Branches',branchId);moriEnsure_(branch&&branch.isActive!==false,'Chi nhánh không tồn tại');
 if(!isPublic)moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],branchId);
 var permitted=publish.orderBranches||'ALL';moriEnsure_(permitted==='ALL'||Array.isArray(permitted)&&permitted.map(Number).indexOf(branchId)>=0,'Chi nhánh không nhận đơn online');
 var ship=request.shipping||{},name=String(ship.name||request.name||'').trim(),phone=String(ship.phone||request.phone||'').trim(),address=String(ship.address||request.address||'').trim();
 moriEnsure_(name.length>=2&&/^\+?[0-9\s-]{9,16}$/.test(phone)&&address.length>=6,'Thiếu thông tin nhận hàng');
 var lines=moriPricing_(request.items||[],branchId,isPublic),tot=moriBillTotals_(lines,0,0,0),id=moriNext_('BILL');
 var doc={id:id,no:'ON-'+moriDate_().replace(/-/g,'')+'-'+String(id).padStart(5,'0'),branchId:branchId,channel:'ONLINE',status:'OPEN',orderStatus:isPublic?'PENDING_CONFIRMATION':'CONFIRMED',shippingStatus:isPublic?'PENDING_CONFIRMATION':'CONFIRMED',paymentStatus:'PENDING',method:request.method||'COD',items:lines,customerName:name,createdBy:isPublic?'PUBLIC_SITE':actor.email,requestId:String(request.requestId||''),shipping:{name:name,phone:phone,email:String(ship.email||'').toLowerCase(),address:address,note:String(ship.note||'')},trackingToken:Utilities.getUuid()+Utilities.getUuid(),guestIdentityId:isPublic?String(request.guestIdentityId||''):'',customerId:isPublic?Number(request.verifiedMemberId)||0:Number(request.customerId)||0,inventoryConsumed:false};
 Object.assign(doc,tot);
 if(!isPublic){var index=moriItemIndex_();doc.inventoryNeeds=moriInventoryValidate_(doc.items,branchId,null,index,settings);}
 doc=moriInsert_('Bills',doc);moriAudit_(isPublic?'PUBLIC_SITE':actor.email,'CREATE','ONLINE_ORDER',id,null,doc);return doc;
}
function moriOnlineMove_(actor,id,next){var b=moriFind_('Bills',id);moriEnsure_(b&&b.channel==='ONLINE','Không có đơn online');moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],b.branchId);
 var allowed={PENDING_CONFIRMATION:['CONFIRMED','CANCELLED'],CONFIRMED:['PREPARING','CANCELLED'],PREPARING:['SHIPPED','CANCELLED'],ALLOCATING:['SHIPPED'],SHIPPED:['DELIVERED']},from=b.orderStatus||'PENDING_CONFIRMATION';
 moriEnsure_((allowed[from]||[]).indexOf(next)>=0,'Trạng thái không hợp lệ: '+from+' → '+next);var before=moriDeep_(b);
 if(next==='CONFIRMED'){b.inventoryNeeds=moriInventoryValidate_(b.items,b.branchId,b.id,moriItemIndex_());}
 if(next==='SHIPPED'&&b.inventoryConsumed!==true){var needs=b.inventoryNeeds||moriInventoryValidate_(b.items,b.branchId,b.id,moriItemIndex_());
  if(b.orderStatus!=='ALLOCATING'){b.orderStatus='ALLOCATING';b=moriPut_('Bills',b,b.version);}
  moriStockDelta_(needs,b.branchId,'ONLINE:'+b.id,-1,moriItemIndex_());b.inventoryConsumed=true;
 }
 b.orderStatus=next;b.shippingStatus=next;if(next==='DELIVERED'&&b.paymentStatus!=='CONFIRMED')b.status='FULFILLED';b=moriPut_('Bills',b,b.version);moriAudit_(actor.email,'STATUS','ONLINE_ORDER',id,before,b);return b;
}
function moriOnlinePayment_(actor,id){var b=moriFind_('Bills',id);moriEnsure_(b&&b.channel==='ONLINE','Đơn hàng không tồn tại');moriRequire_(actor,['ADMIN','MANAGER'],b.branchId);
 moriEnsure_(b.orderStatus==='DELIVERED','Chỉ chốt thu tiền sau giao trong MVP');if(b.paymentStatus==='CONFIRMED')return b;
 var before=moriDeep_(b);b.paymentStatus='CONFIRMED';b.status='PAID';b.paidAt=moriNow_();b.paidAmountAtCheckout=b.finalTotal;b.tipAtCheckout=b.tipAmount||0;b=moriPut_('Bills',b,b.version);moriAudit_(actor.email,'PAYMENT_CONFIRM','BILL',id,before,b);return b;
}
function moriOnlineShipping_(actor,id,shippingPatch){var b=moriFind_('Bills',id);moriEnsure_(b&&b.channel==='ONLINE','Không có đơn online');moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],b.branchId);
 moriEnsure_(['CONFIRMED','PREPARING','SHIPPED'].indexOf(b.orderStatus)>=0,'Không thể sửa vận chuyển ở trạng thái này');
 var before=moriDeep_(b);b.shipping=b.shipping||{};
 ['carrier','shippingRef','note'].forEach(function(k){if(shippingPatch[k]!==undefined)b.shipping[k]=String(shippingPatch[k]).slice(0,250);});
 b=moriPut_('Bills',b,b.version);moriAudit_(actor.email,'UPDATE','SHIPPING',id,before,b);return b;
}
