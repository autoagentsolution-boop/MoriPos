# MoriPOS 3.1.4 — Forecast load optimization

## Tối ưu hóa

1. `moriForecastLoad` luôn kiểm tra token và quyền chi nhánh trước khi đọc cache. CacheService lưu snapshot theo chi nhánh, ngày bắt đầu/kết thúc, số ngày tham chiếu, với TTL 300 giây. Dữ liệu snapshot bị vô hiệu hóa khi app ghi Bills, StockIn, Items, Stores, Branches, Employees, ForecastPlans, Settings. Thay đổi thủ công trực tiếp trong Sheets có thể trễ tối đa 5 phút nếu không bấm làm mới.
2. Đọc một cột `H` (`data_json`) của Bills, thay vì lấy cả 8 cột và lưu deep-copy từng Bill. Vẫn duyệt toàn bộ bill đang hoạt động để giữ chính xác logic kỳ/tham chiếu và các khoản trả muộn; lần tải cache lạnh vẫn có thể mất thời gian với bảng lớn.
3. Đo `timing.phases` trên phản hồi API: `readCatalogAndBillsMs`, `aggregateBillsMs`, `readInventoryMs`, `readCostsMs`, `readPlansAndShapeMs`. `timing.fromCache` chỉ đúng khi cache hit. Đây là số đo server, **không** phải thời gian mạng/trình duyệt.
4. Tự làm mới từ 60 giây thành 180 giây để tránh tải Sheets liên tục. Nút **Cập nhật từ doanh số** yêu cầu tải dữ liệu mới, không dùng cache.
5. Tùy chọn: Admin chạy `moriForecastInstallWarmup()` trong Apps Script Editor để tạo trigger 5 phút gọi hàm riêng tư `moriForecastWarmup_` để prewarm tối đa 2 chi nhánh đang hoạt động theo kỳ mặc định (từ hôm nay đến 6 ngày sau). Trigger chỉ đọc, không tự động bật; cần đảm bảo tài khoản chạy trigger là owner.

## Deploy

- Backup Apps Script và toàn bộ Sheets.
- Thay toàn bộ `.gs` và `Index.html`, xóa `MoriPreflight313.gs` cũ, thêm `MoriPreflight314.gs`. Không thêm `Original_UI_Offline.html`, thư mục tests/docs.
- Giữ Script Properties/Sheet IDs; không chạy lại moriSetup / seed.
- Chạy `moriPreflight314()` và `moriFrontendCheck()` -> ok:true, exactFileMatch:true, build 3.1.4.
- Deploy > Manage deployments > Edit > New version > Deploy.
- Kiểm tra đăng nhập, tạo bill, nhập kho, Forecast thay đổi đúng khi nhấn cập nhật.
- Nếu muốn prewarm: Chạy `moriForecastInstallWarmup()` từ Apps Script Editor, xác nhận quyền lần đầu. Có thể tắt bằng `moriForecastRemoveWarmup()`. Không tự động kích hoạt khi deploy.

## Giới hạn

Vẫn cần quét toàn bộ Bills khi cache lạnh. Với hàng chục nghìn/hàng trăm nghìn bills, nên xây dựng `ForecastDaily` rollup incremental từ bill đã thanh toán, thay vì chỉ dùng cache. Trigger warm-up không đảm bảo luôn có cache vì CacheService có thể evict.
