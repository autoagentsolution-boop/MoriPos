/** Store photos privately on Drive; only catalog images explicitly published may be public. */
function moriUploadImage(token,input){var actor=moriActor_(token),kind=String(input.kind||''),allowed=['ProductImages','Receipts','StockInProof','AttendancePhotos','Branding'];moriEnsure_(allowed.indexOf(kind)>=0,'Loại ảnh không hợp lệ');
 if(kind==='Branding')moriRequire_(actor,['ADMIN']);
 if(kind==='ProductImages')moriRequire_(actor,['ADMIN','MANAGER']);
 if(actor.role!=='ADMIN'&&input.branchId!==undefined)moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],input.branchId);
 var fileName=String(input.name||'photo.jpg').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,110),mime=String(input.mime||'image/jpeg');
 moriEnsure_(['image/jpeg','image/png','image/webp'].indexOf(mime)>=0,'Chỉ nhận ảnh JPEG, PNG, WebP');
 var encoded=String(input.base64||''),m=encoded.match(/^data:image\/[^;]+;base64,(.*)$/);if(m)encoded=m[1];
 moriEnsure_(encoded.length>0&&encoded.length<2900000,'Ảnh tối đa khoảng 2MB, cần nén trước khi gửi');var bytes=Utilities.base64Decode(encoded);moriEnsure_(bytes.length<=2100000,'Ảnh vượt quá 2MB');
 var folder=DriveApp.getFolderById(moriProp_('FOLDER_'+kind.toUpperCase())),blob=Utilities.newBlob(bytes,mime,Utilities.getUuid()+'_'+fileName),file=folder.createFile(blob);
 if((kind==='ProductImages'||kind==='Branding')&&input.makePublic===true){moriRequire_(actor,['ADMIN','MANAGER']);file.setSharing(DriveApp.Access.ANYONE_WITH_LINK,DriveApp.Permission.VIEW);}
 moriLock_(function(){moriAudit_(actor.email,'UPLOAD','MEDIA',file.getId(),null,{kind:kind,name:fileName,branchId:input.branchId||null});});
 return {fileId:file.getId(),url:(kind==='ProductImages'||kind==='Branding')&&input.makePublic===true?'https://drive.google.com/uc?export=view&id='+file.getId():'',private:!((kind==='ProductImages'||kind==='Branding')&&input.makePublic===true)};
}
function moriFilePreview(token,fileId){var actor=moriActor_(token);moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE']);var file=DriveApp.getFileById(fileId),mime=file.getMimeType();moriEnsure_(mime.indexOf('image/')===0,'Chỉ xem ảnh');
 var permitted=false,parents=file.getParents();while(parents.hasNext()){var parentId=parents.next().getId();['PRODUCTIMAGES','RECEIPTS','STOCKINPROOF','ATTENDANCEPHOTOS','BRANDING'].forEach(function(k){if(moriProp_('FOLDER_'+k)===parentId)permitted=true;});}
 moriEnsure_(permitted,'Ảnh không thuộc thư mục Mori POS');
 if(actor.role!=='ADMIN'){
  var sameBranch=function(x){return (actor.branchIds||[]).map(Number).includes(Number(x.branchId));};
  var docs=moriRecent_('StockIn',500).filter(function(x){return sameBranch(x)&&(actor.role!=='EMPLOYEE'||x.employee===actor.email);});
  var clocks=moriRecent_('Attendance',500).filter(function(x){return sameBranch(x)&&(actor.role!=='EMPLOYEE'||x.email===actor.email);});
  var linked=docs.some(function(x){return (x.photoIds||[]).includes(fileId);})||clocks.some(function(x){return (x.photoIds||[]).includes(fileId);});
  moriEnsure_(linked,'Không có quyền xem ảnh này');
 }
 var blob=file.getBlob(),bytes=blob.getBytes();moriEnsure_(bytes.length<2000000,'Ảnh quá lớn để preview');return {mime:mime,data:'data:'+mime+';base64,'+Utilities.base64Encode(bytes)};
}
