# MoriPOS v3.2.7 — Mori Rounded Dropdown UI

## Files to update
- `Index.html`
- `Code.gs` (frontend SHA-256 and version)

## What changed
- Replaces native select popups for Staff Role, Item Sale Status, Holiday Pricing Settings, and Holiday Date Frequency with MoriPOS rounded select menus.
- Unifies staff multi-branch selector border, popover and selected-option style.
- Keeps the original `<select>` nodes as data source and emits their existing `change` events; backend, role logic, holiday pricing, and Google Sheets are unchanged.
- Unifies selection highlight and removes the redundant search field for short 2–3 option menus.

## Deploy
1. Backup current Apps Script project.
2. Replace the two files above, and save.
3. Run `moriFrontendCheck()`; confirm `build: 3.2.7` and `exactFileMatch: true`.
4. Deploy > Manage deployments > Edit > New version > Deploy.
5. Test editing item status, selecting Manager, multiple branch toggles, enabling holiday pricing, selecting recurring holiday, and saving.

No Sheets migration or setup is required. Browser UI has not been verified in the deployed production Google Apps Script environment.
