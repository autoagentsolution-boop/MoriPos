# MoriPOS 3.2.13 — Từ chối nhập hàng

## Cách dùng

Trong **Nhập kho → Phiếu gần đây**, Admin/Quản lý có hai lựa chọn cho phiếu **Chờ duyệt**:

- **Duyệt**: nhập hàng theo luồng hiện có.
- **Từ chối nhập hàng**: nhập lý do (bắt buộc, tối đa 500 ký tự), sau đó xác nhận.

Phiếu được giữ lại với trạng thái **Đã từ chối**, lý do, người xử lý và thời gian. Nhân viên tạo phiếu xem được lý do trong lịch sử. Tồn kho, giá vốn và tiền nhập kho đã xác nhận không tăng khi từ chối. Phiếu đang nhập hoặc đã nhập không thể từ chối bằng thao tác này; đây không phải chức năng trả hàng/đảo tồn kho.

Máy chủ kiểm tra vai trò, chi nhánh và phiên bản phiếu. Khi mất phản hồi sau khi đã ghi, gửi lại cùng lý do trả về phiếu đã từ chối, không tạo thêm lần từ chối/nhật ký. Nếu chưa ghi được, giao diện giữ hộp thoại và lý do để thử lại. Loading dùng nút xác nhận hiện có.

Các trạng thái hiển thị đúng: Chờ duyệt, Đang nhập kho, Đã nhập, Đã từ chối, Đã hủy. Phiếu bị gián đoạn ở bước nhập kho có nút **Tiếp tục nhập kho** dùng cơ chế chống cộng tồn trùng đã có. Nút tạo phiếu của bản Web App được đổi thành **Gửi phiếu nhập**, khớp trạng thái chờ duyệt mà máy chủ đang lưu.

Phiếu từ chối được đưa vào nhóm phiếu kết thúc cho lịch lưu trữ hiện có; chỉ được chuyển sau thời hạn cấu hình và các kiểm tra copy/verify. Bản cập nhật không chạy lưu trữ hoặc xóa dữ liệu hiện tại.

## Nâng cấp từ 3.2.12

Thay đúng 6 file bằng nội dung trong gói này:

1. Index.html (file HTML tên Index trong Apps Script).
2. Code.gs.
3. Inventory.gs.
4. Operations.gs.
5. AuditFormat.gs.
6. Archive.gs.

Không chạy lại Setup; không cần tạo cột/sheet hay migration. Các trường mới nằm trong data_json hiện có.

Chạy `moriFrontendCheck()` để thấy build **3.2.13**, `ok: true`, `exactFileMatch: true`. Sau đó **Deploy → Manage deployments → Edit → New version → Deploy** và tải lại trang.

Từ bản cũ hơn 3.2.12: dùng đầy đủ các file .gs và Index.html trong gói; giữ các Script Properties/deployment hiện tại. Không chép tests, docs, Markdown hoặc Original_UI_Offline.html vào Apps Script.

## Tốc độ ghi

Người dùng đo thực tế khoảng 6–10 giây. Bản này **chưa thay đổi cơ chế lưu nền/cache**, không cam kết giảm còn 3 giây.

Qua đọc code: API đã trả kết quả và dữ liệu thay đổi trong cùng một RPC, nên UI bình thường không gọi lại bootstrap/delta sau mỗi lần ghi. Đường ghi vẫn kiểm tra quyền, lấy khóa, đọc dữ liệu cần kiểm chứng, ghi bản ghi/nhật ký, flush và cập nhật thông tin cache/queue. Lưu ảnh chứng từ có RPC tải ảnh riêng trước khi tạo phiếu. Chưa có số đo trực tiếp từng bước trên deployment của người dùng để kết luận bước nào chiếm phần lớn 6–10 giây.

Các dòng **[Mori timing]** trong Console trình duyệt đã có các số `clientMs`, `serverMs`, `authMs`, `commitMs`, `lockWaitMs` khi API hỗ trợ. `commitMs` gồm xử lý nghiệp vụ và chuẩn bị dữ liệu trả về; phần chênh còn lại có thể gồm flush/hậu xử lý. Đây là phép đo phục vụ chẩn đoán, không phải benchmark thời gian từ mô phỏng local.

## Kiểm tra

`node tests/run-tests.js` đạt **24 suites / 202 nhóm kiểm tra**. Có kiểm tra mới cho từ chối, lý do và phiên bản, quyền/chi nhánh, không đổi tồn/giá vốn, không tính tiền nhập bị từ chối, thử lại sau khi mất phản hồi, bảo toàn dữ liệu khi ghi lỗi, nút/hộp thoại và lưu trữ phiếu kết thúc. Log: tests/TEST_3213_RUN.log.

Tất cả là mô phỏng Node/DOM/RPC/Sheets. Chưa kiểm tra trong trình duyệt thật hoặc triển khai lên Web App của người dùng.
