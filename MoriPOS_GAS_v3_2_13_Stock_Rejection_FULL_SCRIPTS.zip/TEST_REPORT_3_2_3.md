# MoriPOS v3.2.3 — Local QC report

- Full regression: **17 suites, 145 PASS**.
- New performance-323 suite: **10 PASS**.
- Includes: no customer read during OTP bootstrap, lazy per-module reads, restricted history groups, role projection and Audit protection, exact customer lookup, checkout timing and one-time commit, independent POS catalog startup, Booking-on-demand load.
- Existing suites cover POS checkout idempotency, partial-write retry, stock reservations, OTP, Customer/Analytics, Forecast, UI, SHA-256 matching.
- Tests use Node VM/Sheet mocks; **no real Google API latency measurement is claimed**.
