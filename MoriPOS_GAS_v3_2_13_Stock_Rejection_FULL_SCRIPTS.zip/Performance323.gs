/** Manual owner-only diagnostic. This is NOT called on login/checkout.
 * Measures actual Sheet service calls in the owner's Apps Script environment.
 * No customer PII, tokens, IDs or bill contents are returned.
 */
function moriPerformanceProbe323(){
 moriEditorOnly_();
 var groups=[['Items',null],['AccessControl',null],['Bills',100],['StockIn',100],['Customers',100]],rows=[];
 groups.forEach(function(g){
  var started=Date.now(),count=0,error=null;
  try{count=g[1]===null?moriAll_(g[0],false).length:moriRecent_(g[0],g[1]).length;}
  catch(e){error=String(e.message||e);}
  rows.push({group:g[0],sampleRows:count,serverMs:Date.now()-started,error:error});
 });
 return {version:'3.2.3',at:moriNow_(),samples:rows,
  notes:'Dữ liệu đo được trên Google Apps Script thực tế. Không phải benchmark từ máy local. Tránh chạy đồng thời với giờ cao điểm.'};
}
