# MoriPOS v3.1.6 — Tách Analytics sang Google Spreadsheet `POS_Dashboard`

## Phạm vi

- **`POS_Master`** tiếp tục lưu `Stores`, `Branches`, `Employees`, `AccessControl`, `Settings`, `ForecastPlans` và các dữ liệu vận hành thuộc master.
- **`POS_Dashboard`** là Google **Spreadsheet riêng** (file Google Sheets mới), nằm trong folder `MoriPOS_Data`; có tab `AnalyticsLedger` và `AnalyticsDaily`. Đây **không** phải chỉ đổi tên tab hay tạo thêm tab trong `POS_Master`.
- `POS_Bills`, `POS_StockIn`, `POS_Items` và các workbook vận hành khác giữ nguyên.
- `moriSheet_('AnalyticsLedger')` và `moriSheet_('AnalyticsDaily')` trỏ qua Script Property `MORI_FILE_DASHBOARD`. Forecast và `moriAnalyticsQuery` đều dùng các bảng tổng hợp trong workbook này.
- `AnalyticsLedger` phục vụ đối soát theo chứng từ; `AnalyticsDaily` chứa số liệu ngày/chi nhánh/mặt hàng cho Forecast và dashboard. Giá vốn không cộng lại tiền nhập kho.

## Nâng cấp project đã chạy v3.1.5 (bảo toàn dữ liệu)

1. **Backup toàn bộ** project GAS và tất cả Google Sheets (đặc biệt là `POS_Master`, `POS_Bills`, `POS_StockIn`); ghi lại Script Properties.
2. Thay **toàn bộ** các file `.gs` và `Index.html` trong ZIP trên **cùng Apps Script project**; xóa file `MoriPreflight315.gs` nếu đang có, sử dụng `MoriPreflight316.gs`. KHÔNG đưa `Original_UI_Offline.html`, `tests/`, Markdown lên GAS.
3. Trong Apps Script Editor chạy `moriPreflight316()` rồi `moriFrontendCheck()`: kiểm tra `ok: true`, `exactFileMatch: true`, build `3.1.6`.
4. **Deploy → Manage deployments → Edit → New version → Deploy**, cùng Deployment ID/URL `/exec`. Nên thực hiện vào thời điểm ít người thao tác. Forecast sẽ tạm thông báo thiếu `POS_Dashboard` cho đến khi bước 5 hoàn tất. **Không chạy migration khi vẫn còn deploy v3.1.5 đang ghi dữ liệu.**
5. Trong Apps Script Editor, bằng tài khoản owner, chạy **`moriAnalyticsInstall()`**. Hàm sẽ tạo `POS_Dashboard` nếu chưa có (hoặc dùng `MORI_FILE_DASHBOARD` đã cấu hình), nằm trong `MoriPOS_Data`; chuyển bản sao các tab `AnalyticsLedger`, `AnalyticsDaily` hiện có từ `POS_Master` sang `POS_Dashboard`; đối chiếu số dòng và các điểm kiểm tra; sau đó mới bật định tuyến mới. Script Properties `MORI_FILE_DASHBOARD` được tạo tự động, không cần tự copy ID.
6. Kiểm tra return của `moriAnalyticsInstall()`: `dashboard.url`, `dashboard.sourceRows`, `dashboard.targetRows`, `dashboard.legacyBackupInMaster`. Mở URL để chắc chắn hai tab mới nằm trong **file riêng**.
7. Chạy **`moriAnalyticsStatus()`**. Phải có `dashboardReady: true`. Nếu đã sync đầy đủ ở v3.1.5, kỳ vọng giữ nguyên `ready/backfillComplete` và checkpoint; nếu mới bắt đầu, chạy `moriAnalyticsSyncNow()` nhiều lượt hoặc để worker 5 phút xử lý cho đến khi `ready: true`, `backfillComplete: true`.
8. So sánh ít nhất một ngày có bill Paid, có giảm giá và có phiếu nhập kho, trước/sau migration; kiểm tra Forecast và dashboard query. Sau khi đối soát thành công và có backup độc lập, có thể xóa thủ công hai tab `AnalyticsLedger`, `AnalyticsDaily` **cũ** trong `POS_Master` nếu muốn giảm dung lượng file. **Installer không tự xóa.**

Không chạy lại `moriSetup`, `moriInstallOnce`, `moriSeedQC`, không tạo lại các bảng giao dịch. Không cần sửa code endpoint frontend hay URL.

## Nếu đang bắt đầu mới / chưa chạy Analytics 3.1.5

`moriAnalyticsInstall()` tạo `POS_Dashboard` với hai tab có header chuẩn; không phát sinh tab Analytics ở `POS_Master`. Sau đó chạy `moriAnalyticsSyncNow()` hoặc đợi trigger để materialize lịch sử. `moriSetup()` khi được dùng cho một cửa hàng mới cũng biết tên workbook `POS_Dashboard`, nhưng dự án đã có dữ liệu **không được** chạy lại setup chỉ để tạo workbook.

## Cơ chế bảo vệ và khôi phục

- Migration phải lấy **analytics worker lease**: nếu worker đang chạy, installer báo thử lại; không copy đồng thời với worker.
- Giao dịch POS mới vẫn được đưa vào outbox, không mất khi Analytics tạm ngừng. Worker chỉ bắt đầu xử lý trên Dashboard khi hai tab được xác nhận hợp lệ.
- `MORI_ANALYTICS_DASHBOARD_READY` chỉ đặt thành `1` **sau** khi xong cả hai tab; Forecast không đọc nhầm bảng Master khi quá trình chuyển bị lỗi.
- Nếu lệnh copy gặp lỗi, chạy lại `moriAnalyticsInstall()` sau khi xử lý lỗi; không xóa workbook/Script Properties để thử lại. Nếu bảng đích đã có dữ liệu khác nguồn cũ, installer **dừng** thay vì overwrite.
- Hai tab gốc trong `POS_Master` được giữ nguyên làm bản dự phòng. Sau khi chạy thật trên v3.1.6, dữ liệu mới được ghi vào `POS_Dashboard`, nên tab Master cũ **không cập nhật nữa**.
- Nếu rollback source sang v3.1.5, worker cũ sẽ sử dụng tab Master (và dữ liệu có thể tách nhánh). Sau khi quay lại v3.1.6 cần chạy `moriAnalyticsRebuildHistory()` rồi sync đủ, tránh tin vào dữ liệu cũ. **Ưu tiên backup và khôi phục theo runbook** thay vì rollback chéo bản tùy ý.
- Script Property `MORI_FILE_DASHBOARD` là ID Spreadsheet, **không phải** URL hoặc ID sheet tab. Không đặt trùng `MORI_FILE_MASTER`.

## Kiểm tra & giới hạn

`moriPreflight316()` là kiểm tra code trong Editor. 12 bộ kiểm thử Node mô phỏng bao gồm di trú thành công, copy lỗi giữa chừng, chống ghi đè dữ liệu đích, chống trùng Spreadsheet ID, Forecast/Analytics POS cũ. Chưa chạy kiểm thử tích hợp thực tế với Google Drive/Sheets tại môi trường của bạn. `Sheet.copyTo()` có thể tốn thời gian khi nguồn rất lớn; chạy vào giờ ít hoạt động và giám sát Apps Script **Executions**.
