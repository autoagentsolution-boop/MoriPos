# MoriPOS 3.2.6 — Local Test Report

- Baseline: v3.2.5 — 18 suites, 151 reported groups PASS.
- Updated: v3.2.6 — 19 suites, 157 reported groups PASS.
- Node.js main JavaScript syntax: PASS.
- Index.html / Code.gs SHA-256 integrity: PASS.
- New Action UI tests: duplicate-checkout suppression, restoration after API completion, approval/attendance/stock/Forecast/holiday/public API coverage, early failure reset, persistent busy state through UI rerenders, offline isolation and public retry id stability.
- Tests run against local simulations; real-world network latency and concurrent Apps Script sessions were not benchmarked.
