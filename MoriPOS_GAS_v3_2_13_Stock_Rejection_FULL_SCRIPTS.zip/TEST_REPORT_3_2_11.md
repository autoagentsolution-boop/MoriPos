# Báo cáo kiểm tra MoriPOS 3.2.11

## Kết quả

**PASS: 23 suites, 193 nhóm kiểm tra.** Môi trường: Node VM với DOM/RPC và Google Sheets/Cache/Lock mô phỏng. Không phải kiểm thử trình duyệt thật hoặc triển khai Google Apps Script.

Lệnh chạy: `node tests/run-tests.js`. Có thể đặt `MORI_3210_BASELINE_DIR` tới thư mục giải nén v3.2.10 để chạy đối chiếu số lời gọi. Log kèm gói đã đối chiếu với bản v3.2.10 trong phiên làm việc này.

## Số đo đối chiếu

| Tình huống mô phỏng | v3.2.10 | v3.2.11 |
| --- | ---: | ---: |
| Duyệt phiếu 1 mặt hàng + cập nhật UI: RPC | 2 | 1 |
| Cùng tình huống: lần mở Spreadsheet | 8 | 4 |
| Cùng tình huống: getValues | 7 | 3 |
| Cùng tình huống: dòng đọc | 86 | 22 |
| Duyệt phiếu 20 mặt hàng liền nhau: setValues toàn giao dịch | 23 | 4 |
| Cùng tình huống: số dòng ghi | 23 | 23 |

Bộ dữ liệu đối chiếu có 20 mặt hàng, 40 phiếu cũ và 4.000 bill cho phép đo RPC/read; phép đo batch 20 mặt hàng không cần lịch sử bill. Cấu trúc dữ liệu và cùng đầu vào được dùng cho cả hai bản. Số dòng ghi giữ nguyên trong phép đo batch, chỉ giảm số lời gọi dịch vụ.

## Các tình huống đã kiểm tra

- Đơn vị, Loại, thành phần, đơn vị định lượng, hao hụt và chi phí chế biến giữ đúng sau lưu/mở lại.
- Bộ lọc danh mục kết hợp trạng thái, đếm kết quả, phân trang, nhóm chưa phân loại; không phát RPC khi lọc.
- Phản hồi lưu chỉ gồm dữ liệu được phân quyền. Nhân viên không nhận cost/ACL/nhật ký Admin; phiên bản cũ bị từ chối.
- Lưu được xác nhận sau flush và nhả lock; giữ tương thích endpoint cũ.
- Thử lại phiếu đã xác nhận và phiếu ghi dở: không cộng tồn hai lần, trả toàn bộ tồn liên quan để UI khớp dữ liệu đã lưu.
- Ghi theo lô 20 mặt hàng và nhiều dòng cùng mặt hàng giữ giá vốn bình quân, tồn và dấu chống lặp.
- Cache cũ trả muộn/eviction không thay thế phiên bản cache mới; snapshot trong một lần thực thi trả bản sao độc lập; thao tác ghi đọc dữ liệu gốc.
- Gộp các yêu cầu tải trùng; xử lý phản hồi sai thứ tự, phản hồi sau khi ghi và phản hồi sau đăng xuất.
- Snapshot danh mục đầy đủ bỏ dòng không còn tồn tại; cập nhật cục bộ không xóa các dòng khác.
- Lỗi đọc/lưu không làm mất dữ liệu đã xác nhận; có thể thử lại thủ công.
- Lưu tài khoản ngân hàng dùng một lần branch.save; lỗi lưu giữ dữ liệu ngân hàng đã xác nhận.
- Mã theo dõi tìm được bản ghi ngoài giới hạn 3.000 dòng cũ; chỉ đọc JSON của dòng khớp.
- Booking không có tài nguyên không đọc toàn bộ Booking.
- Archive giới hạn 2.000 dòng nguồn/lượt, tiếp tục qua các bản ghi chưa đủ điều kiện, xóa theo lô.
- Archive không xóa khi đối chiếu đầy đủ nội dung thất bại; thử lại không tạo bản sao trùng.
- Xóa dở thất bại: nhả lock, xóa bộ nhớ số dòng, khôi phục vị trí quét; thử lại giữ các booking còn mở.
- Các bộ kiểm tra cũ về checkout, quyền truy cập, công thức, Forecast, analytics, đăng nhập, dropdown và phản hồi nút tiếp tục đạt.

## Phạm vi thực tế

Không đo thời gian mạng, độ trễ Apps Script, quota hoặc hành vi bố cục trong trình duyệt thật. Chưa triển khai lên tài khoản người dùng và chưa chạy archive trên dữ liệu thật.

8 file runtime thay đổi so với v3.2.9/v3.2.10: `Index.html`, `Code.gs`, `Operations.gs`, `ApiRead.gs`, `Data.gs`, `Config.gs`, `Inventory.gs`, `Archive.gs`. Không đổi schema, Units.gs, Forecast.gs, ForecastCore.gs hoặc hàm tính giá combo.

Tham khảo API và hướng dẫn gốc khi thực hiện: [Apps Script best practices](https://developers.google.com/apps-script/guides/support/best-practices), [Cache](https://developers.google.com/apps-script/reference/cache/cache), [Sheet](https://developers.google.com/apps-script/reference/spreadsheet/sheet).
