/** Controlled application API. ALL staff writes require a server-side role/branch check. */
function moriApi(token,action,payload,withChanges){var p=payload||{},started=Date.now();
 var reply=moriLock_(function(){var authStart=Date.now(),actor=moriActor_(token),authMs=Date.now()-authStart,commitStart=Date.now();
  var result=moriDispatch_(actor,action,p);
  if(withChanges!==true)return result;
  var table=({bill:'Bills',online:'Bills',stock:'StockIn',catalog:'Items',booking:'Booking',attendance:'Attendance'})[String(action).split('.')[0]];
  return {ok:true,result:table?moriForActor_(actor,table,result):result,changes:moriCommittedChanges_(actor,table,result,action),timing:{authMs:authMs,commitMs:Date.now()-commitStart}};
 });
 if(withChanges===true){reply.timing.serverMs=Date.now()-started;reply.timing.lockWaitMs=MORI_LOCK_WAIT_MS_;}
 return reply;
}
function moriCommittedChanges_(actor,primaryTable,result,action){var out={},keys={Items:'Items',Bills:'Bills',StockIn:'StockIn',Booking:'Booking',Customers:'CustomerUpdates',Branches:'BranchUpdates',Employees:'EmployeeUpdates',Attendance:'Attendance',Audit:'AuditUpdates',Settings:'Settings',Stores:'Stores',PublishSite:'PublishSite'};
 Object.keys(keys).forEach(function(table){
  if(table==='Audit'&&actor.role!=='ADMIN')return;
  var changed=MORI_CHANGED_DOCS_[table];if(!changed)return;
  var docs=moriReadFilter_(actor,table,Object.keys(changed).map(function(id){return changed[id];}));
  if(docs.length)out[keys[table]]=['Settings','Stores','PublishSite'].indexOf(table)>=0?docs[0]:docs;
 });
 // An acknowledged retry may not write a row. Still return its current state.
 if(primaryTable&&result&&result.id!==undefined)out[primaryTable]=moriReadFilter_(actor,primaryTable,[result]);
 var inventoryIds=primaryTable==='StockIn'&&action==='stock.confirm'?(result.lines||[]).map(function(line){return line.id;}):primaryTable==='Bills'&&result.inventoryConsumed?Object.keys(result.inventoryNeeds||{}):[];
 if(inventoryIds.length){var items=Object.create(null);(out.Items||[]).forEach(function(item){items[String(item.id)]=item;});Array.from(new Set(inventoryIds.map(String))).forEach(function(id){var item=moriFind_('Items',id);if(item)items[id]=item;});out.Items=moriReadFilter_(actor,'Items',Object.keys(items).map(function(id){return items[id];}));}
 return out;
}
function moriDispatch_(actor,action,p){switch(action){
  case 'bill.create':return moriCreateOfflineBill_(actor,p,false);
  case 'bill.draft':return moriCreateOfflineBill_(actor,p,false);
  case 'bill.pay':return moriCreateOfflineBill_(actor,p,true);
  case 'bill.paidEdit':return moriPaidBillEdit_(actor,p.id,p.version,p.patch||{});
  case 'online.create':return moriOnlineCreate_(actor,p,false);
  case 'online.transition':return moriOnlineMove_(actor,p.id,p.stage);
  case 'online.payment':return moriOnlinePayment_(actor,p.id);
  case 'online.shipping':return moriOnlineShipping_(actor,p.id,p.shipping||{});
  case 'stock.create':return moriStockCreate_(actor,p);
  case 'stock.confirm':return moriStockConfirm_(actor,p.id);
  case 'stock.reject':return moriStockReject_(actor,p);
  case 'catalog.save':return moriCatalogSave_(actor,p);
  case 'catalog.status':return moriCatalogStatus_(actor,p);
  case 'settings.holiday.save':return moriHolidaySettingsSave_(actor,p);
  case 'customer.save':return moriCustomerMemberSave_(actor,p);
  case 'employee.save':return moriStaffSave_(actor,p);
  case 'branch.save':return moriBranchSave_(actor,p);
  case 'store.save':return moriStoreSave_(actor,p);
  case 'settings.save':return moriSettingsSave_(actor,p);
  case 'publish.save':return moriPublishSave_(actor,p);
  case 'booking.create':return moriBookingCreate_(actor,p,false);
  case 'booking.status':return moriBookingStatus_(actor,p.id,p.status);
  case 'attendance.clock':return moriAttendance_(actor,p);
  default:throw new Error('API action không được hỗ trợ: '+action);
 }}
function moriCatalogSave_(actor,p){moriRequire_(actor,['ADMIN','MANAGER']);var before=p.id?moriFind_('Items',p.id):null;if(before)moriRequire_(actor,['ADMIN','MANAGER'],p.branchId||before.branchId||actor.branchIds[0]);
 var name=String(p.name||'').trim();moriEnsure_(name.length>1&&name.length<160,'Tên sản phẩm không hợp lệ');
 moriEnsure_(!moriAll_('Items',false).some(function(i){return String(i.id)!==String(p.id)&&moriNorm_(i.name)===moriNorm_(name);}), 'Tên sản phẩm đã tồn tại (không phân biệt dấu / hoa thường)');
 var unit=moriUnitName_(p.baseUnit||before?.baseUnit||(p.type==='MATERIAL'?'g':'cái')),type=String(p.type||before?.type||'PRODUCT'),track=type!=='SERVICE'&&p.track!==false,price=Number(p.price),cost=Number(p.cost||0);
 moriEnsure_(['PRODUCT','MATERIAL','COMBO','SERVICE'].indexOf(type)>=0,'Loại mặt hàng không hợp lệ');
 moriEnsure_(price>=0&&price<=1000000000&&cost>=0&&cost<=1000000000,'Giá không hợp lệ');
 moriEnsure_(unit.length>0&&unit.length<=30,'Đơn vị cơ sở không hợp lệ');
 var doc=before?moriDeep_(before):{id:moriNext_('ITEM'),stock:0,stockByBranch:{},costByBranch:{}};
 ['name','cat','type','imageFileId','imageUrl','sku','barcode'].forEach(function(k){if(p[k]!==undefined)doc[k]=String(p[k]);});
 doc.name=name;doc.type=type;doc.baseUnit=unit;doc.price=price;doc.cost=cost;doc.track=track;doc.isActive=p.isActive!==false;
 var hp=p.holidayPrice;if(hp===null||hp===undefined||hp==='')doc.holidayPrice=null;else{moriEnsure_(Number.isSafeInteger(Number(hp))&&Number(hp)>=0&&Number(hp)<=1000000000,'Giá ngày lễ không hợp lệ');doc.holidayPrice=Number(hp);}
 if(Array.isArray(p.components)){moriEnsure_(p.components.length<=25,'Tối đa 25 thành phần');doc.components=p.components.map(function(c){moriEnsure_(Number(c.itemId)!==Number(doc.id)&&Number(c.qty)>0,'Thành phần không hợp lệ');return {itemId:Number(c.itemId),qty:Number(c.qty),unit:moriUnitName_(c.unit||moriBaseUnit_(moriFind_('Items',c.itemId))),wastePercent:moriForecastNumber_(c.wastePercent??0,0,100,'Hao hụt')};});}
 if(p.unitFactors&&typeof p.unitFactors==='object'){doc.unitFactors={};Object.keys(p.unitFactors).forEach(function(u){moriEnsure_(u.length<=30,'Tên đơn vị quá dài');doc.unitFactors[moriUnitName_(u)]=moriForecastNumber_(p.unitFactors[u],0.000001,1000000,'Hệ số quy đổi');});}
 if(p.processingCost!==undefined)doc.processingCost=moriForecastNumber_(p.processingCost,0,1e9,'Chi phí chế biến');
 moriEnsure_(type!=='COMBO'||doc.components?.length>0,'Combo cần ít nhất một thành phần định lượng');
 moriEnsure_(type!=='MATERIAL'||!doc.components?.length,'Nguyên liệu nhập kho không có công thức thành phần');
 if(type==='COMBO'||type==='SERVICE'||doc.components?.length)doc.track=false;
 // Catalog edits correct the unit label, not stock quantities or historical prices.
 // Keep previous count-unit labels usable by recipes/receipts after cái -> phần, etc.
 if(before&&moriBaseUnit_(before)!==unit){
  var oldUnit=moriBaseUnit_(before),metric=['kg','g','mg','l','ml'];
  if(metric.indexOf(oldUnit)<0&&metric.indexOf(unit)<0){
   var known;Object.keys(before.unitFactors||{}).forEach(function(k){if(moriUnitName_(k)===unit)known=before.unitFactors[k];});
   moriEnsure_(known===undefined||Math.abs(Number(known)-1)<1e-9,'Đơn vị '+unit+' đang có hệ số quy đổi khác 1. Chỉ sửa tên đơn vị khi hai đơn vị tương đương 1:1.');
   doc.unitFactors=Object.assign({},doc.unitFactors||{});delete doc.unitFactors[unit];doc.unitFactors[oldUnit]=1;
  }
 }
 var recipeIndex=moriItemIndex_();recipeIndex[String(doc.id)]=doc;moriRecipe_(doc.id,recipeIndex,actor.branchIds[0]||1,1);
 // Reject a unit edit that would leave another saved recipe with an invalid conversion.
 if(before&&moriBaseUnit_(before)!==unit)Object.keys(recipeIndex).forEach(function(id){
  var parent=recipeIndex[id];if((parent.components||[]).some(function(c){return String(c.itemId)===String(doc.id);})){
   try{moriRecipe_(parent.id,recipeIndex,actor.branchIds[0]||1,1);}catch(e){throw new Error('Không lưu được đơn vị mới: công thức '+parent.name+' cần được cập nhật quy đổi. '+e.message);}
  }
 });
 // Never allow direct overwrite of stock balances via catalog editor.
 doc=before?moriPut_('Items',doc,p.version??before.version):moriInsert_('Items',doc);
 moriAudit_(actor.email,before?'UPDATE':'CREATE','ITEM',doc.id,before,doc);return doc;
}
/** Soft stop/resume sales. Existing bills and stock balances remain intact. */
function moriCatalogStatus_(actor,p){moriRequire_(actor,['ADMIN','MANAGER']);var doc=moriFind_('Items',p.id);moriEnsure_(doc,'Không tìm thấy mặt hàng');
 moriEnsure_(typeof p.isActive==='boolean','Thiếu trạng thái bán');moriEnsure_(Number(p.version)===Number(doc.version),'VERSION_CONFLICT');
 var before=moriDeep_(doc);doc.isActive=p.isActive;doc=moriPut_('Items',doc,p.version);moriAudit_(actor.email,'UPDATE','ITEM',doc.id,before,doc);return doc;}
function moriPersonSave_(actor,table,p){moriRequire_(actor,table==='Employees'?['ADMIN']:['ADMIN','MANAGER']);
 var id=p.id|| (table==='Employees'?String(p.email||'').toLowerCase():moriNext_('CUSTOMER'));
 var before=moriFind_(table,id),doc=before?moriDeep_(before):{id:id};
 if(table==='Employees'){moriEnsure_(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(p.email||'')),'Nhân viên cần email hợp lệ');
  Object.assign(doc,{email:String(p.email).toLowerCase(),name:String(p.name||''),phone:String(p.phone||''),role:p.role||'EMPLOYEE',branchId:Number(p.branchId)||1,isActive:p.isActive!==false});
  moriRequire_(actor,['ADMIN'],doc.branchId);
  // Salary/CCCD are private. Only Admin can write; never send in employee list to ordinary users.
  if(p.salaryBase!==undefined)doc.salaryBase=Math.max(0,Number(p.salaryBase)||0);
  if(p.rate!==undefined)doc.rate=Math.max(0,Number(p.rate)||0);
  if(p.payType!==undefined)doc.payType=String(p.payType);
  if(p.cccd!==undefined)doc.cccd=String(p.cccd||'');
  moriUpsert_('AccessControl',{id:doc.email,email:doc.email,role:doc.role,branchIds:[doc.branchId],isActive:doc.isActive});
 } else {Object.assign(doc,{name:String(p.name||''),phone:String(p.phone||''),email:String(p.email||''),customerGroup:p.customerGroup||'Guest',notes:String(p.notes||'')});}
 doc=before?moriPut_(table,doc,p.version??before.version):moriInsert_(table,doc);moriAudit_(actor.email,before?'UPDATE':'CREATE',table.toUpperCase(),id,before,doc);return doc;
}
function moriStoreSave_(actor,p){moriRequire_(actor,['ADMIN']);var doc=moriFind_('Stores','1');var before=moriDeep_(doc);['name','type','phone','email','address','logoFileId','logoUrl'].forEach(function(k){if(p[k]!==undefined)doc[k]=String(p[k]);});
 ['monthlyRent','monthlyOtherCost'].forEach(function(k){if(p[k]!==undefined){moriEnsure_(Number(p[k])>=0,'Chi phí không thể âm');doc[k]=Number(p[k]);}});
 doc=moriPut_('Stores',doc,p.version??doc.version);moriAudit_(actor.email,'UPDATE','STORE',1,before,doc);return doc;}
function moriBranchSave_(actor,p){moriRequire_(actor,['ADMIN']);var id=p.id||moriNext_('BRANCH'),before=moriFind_('Branches',id),doc=before?moriDeep_(before):{id:id,storeId:1};
 var code=String(p.code||doc.code||'').trim().toUpperCase(),name=String(p.name||doc.name||'').trim();moriEnsure_(code&&name,'Thiếu mã hoặc tên chi nhánh');
 moriEnsure_(!moriAll_('Branches',false).some(function(b){return String(b.id)!==String(id)&&(moriNorm_(b.name)===moriNorm_(name)||moriNorm_(b.code)===moriNorm_(code));}),'Chi nhánh đã tồn tại');
 ['phone','email','address','bankName','bankCode','bankAccount','bankHolder','bankId','bankAccountNo','bankAccountName','bankQRFileId','bankQRUrl'].forEach(function(k){if(p[k]!==undefined)doc[k]=String(p[k]);});
 doc.name=name;doc.code=code;doc.isActive=(p.isActive??p.active)!==false;doc.monthlyRent=Math.max(0,Number(p.monthlyRent??doc.monthlyRent??0));doc.monthlyOtherCost=Math.max(0,Number(p.monthlyOtherCost??doc.monthlyOtherCost??0));
 doc=before?moriPut_('Branches',doc,p.version??before.version):moriInsert_('Branches',doc);moriAudit_(actor.email,before?'UPDATE':'CREATE','BRANCH',id,before,doc);return doc;}
function moriSettingsSave_(actor,p){moriRequire_(actor,['ADMIN']);var old=moriFind_('Settings','global'),doc=moriDeep_(old);
 var permitted=['modules','paidBillEditRoles','showItemImages','lowStockThreshold','lowStockPolicy','costMethod','archive','receipt','attendanceVerifyMethod','tiers','commissionRate','schedule','history'];
 permitted.forEach(function(k){if(p[k]!==undefined)doc[k]=p[k];});
 moriEnsure_(Number(doc.lowStockThreshold)>=0&&Number(doc.lowStockThreshold)<=100000,'Ngưỡng tồn không hợp lệ');
 doc=moriPut_('Settings',doc,p.version??old.version);moriAudit_(actor.email,'UPDATE','SETTINGS','global',old,doc);return doc;}
function moriPublishSave_(actor,p){moriRequire_(actor,['ADMIN']);var old=moriFind_('PublishSite','site'),doc=moriDeep_(old);
 ['published','mode','tagline','zalo','phone','bookingChannels','bookingOpen','bookingClose','bookingDurationMin','orderBranches','bookingBranches','categoryVisibility','itemRules','facebookUrl'].forEach(function(k){if(p[k]!==undefined)doc[k]=p[k];});
 doc=moriPut_('PublishSite',doc,p.version??old.version);moriAudit_(actor.email,'UPDATE','PUBLISH_SITE','site',old,doc);return doc;}
function moriBookingCreate_(actor,p,publicCreate){var branchId=Number(p.branchId),branch=moriFind_('Branches',branchId),settings=moriFind_('Settings','global')||{},site=moriFind_('PublishSite','site')||{};
 moriEnsure_(branch&&branch.isActive!==false,'Chi nhánh không tồn tại');
 if(publicCreate){moriEnsure_(settings.modules?.booking===true&&site.published===true&&site.bookingChannels?.PUBLISH_SITE===true,'Không nhận booking online');var allowed=site.bookingBranches||'ALL';moriEnsure_(allowed==='ALL'||allowed.map(Number).includes(branchId),'Chi nhánh không nhận booking');}
 else moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],branchId);
 var start=String(p.startAt||''),date=new Date(start);moriEnsure_(!isNaN(date.getTime())&&date.getTime()>Date.now()-60000,'Ngày giờ không hợp lệ');
 var guests=Number(p.guestCount)||1;moriEnsure_(guests>=1&&guests<=100,'Số khách không hợp lệ');
 var duration=Math.max(15,Math.min(480,Number(p.duration)||90));
 var conflicted=!!p.resource&&moriAll_('Booking',false).some(function(b){if(b.branchId!==branchId||!p.resource||b.resource!==p.resource||['CANCELLED','REJECTED','COMPLETED'].indexOf(b.status)>=0)return false;var a=new Date(b.startAt).getTime(),c=date.getTime();return c<a+Number(b.duration||90)*60000&&a<c+duration*60000;});
 moriEnsure_(!conflicted,'Bàn/ghế đã có booking trong khung giờ này');
 var id=moriNext_('BOOKING'),doc={id:id,branchId:branchId,name:String(p.name||''),phone:String(p.phone||''),email:String(p.email||''),guestCount:guests,startAt:date.toISOString(),duration:duration,resource:p.resource||'',note:p.note||'',source:publicCreate?(p.source==='FACEBOOK'?'FACEBOOK':'PUBLISH_SITE'):p.source||'PHONE',date:String(p.date||'').slice(0,10),time:String(p.time||''),guests:guests,code:'BK-'+moriDate_(date).replace(/-/g,'')+'-'+id,createdBy:publicCreate?'PUBLIC_SITE':actor.email,requestId:String(p.requestId||''),status:'PENDING',trackingToken:Utilities.getUuid()+Utilities.getUuid()};
 doc=moriInsert_('Booking',doc);moriAudit_(publicCreate?'PUBLIC_SITE':actor.email,'CREATE','BOOKING',id,null,doc);return doc;}
function moriBookingStatus_(actor,id,status){var doc=moriFind_('Booking',id);moriEnsure_(doc,'Booking không tồn tại');moriRequire_(actor,['ADMIN','MANAGER'],doc.branchId);moriEnsure_(['CONFIRMED','REJECTED','ARRIVED','COMPLETED','CANCELLED'].indexOf(status)>=0,'Trạng thái không hợp lệ');var before=moriDeep_(doc);doc.status=status;doc=moriPut_('Booking',doc,doc.version);moriAudit_(actor.email,'STATUS','BOOKING',id,before,doc);return doc;}
function moriAttendance_(actor,p){moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE']);moriClockOtpVerify_(actor,p.code);
 var emp=moriFind_('Employees',actor.email);moriEnsure_(emp&&emp.isActive!==false,'Không có hồ sơ nhân viên');moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],emp.branchId);
 var day=moriDate_(),id=actor.email+'|'+day,doc=moriFind_('Attendance',id),now=moriNow_();
 if(actor.role==='EMPLOYEE')moriEnsure_(Array.isArray(p.photoIds)&&p.photoIds.length>0,'Cần ảnh chấm công');moriEnsure_(p.direction==='IN'||p.direction==='OUT','Sai loại chấm công');
 if(!doc){moriEnsure_(p.direction==='IN','Chưa chấm vào');doc={id:id,email:actor.email,branchId:emp.branchId,date:day,checkinAt:now,checkoutAt:null,photoIds:p.photoIds||[],status:'PRESENT'};doc=moriInsert_('Attendance',doc);}
 else{moriEnsure_(p.direction==='OUT','Giờ vào ca đầu tiên đã được ghi nhận');doc.checkoutAt=now;var ended=String(emp.scheduledEnd||'18:00'),shiftEnd=new Date(day+'T'+ended+':00+07:00');doc.otMinutes=Math.max(0,Math.floor((new Date(now).getTime()-shiftEnd.getTime())/60000));doc.photoIds=(doc.photoIds||[]).concat(p.photoIds||[]);doc=moriPut_('Attendance',doc,doc.version);}
 moriAudit_(actor.email,p.direction==='IN'?'CHECKIN':'CHECKOUT','ATTENDANCE',id,null,doc);return doc;
}
