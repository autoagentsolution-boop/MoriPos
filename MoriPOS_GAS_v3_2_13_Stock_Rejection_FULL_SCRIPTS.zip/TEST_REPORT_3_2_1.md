# MoriPOS v3.2.1 — Test Report

- `node tests/run-tests.js`: 15 test suites, **130 reported groups PASS**.
- Source syntax: all `.gs`, HTML JavaScript và manifest parse trong Node VM.
- Staff access: Owner/Admin-only updates; multiple branch permissions; account deactivation invalidates session.
- Staff OTP: no allowlist → explicit error, no email; disabled account → explicit error, no email; active staff → OTP issued, cooldown enforced. Frontend only advances to code entry after backend success.
- Staff UI: modal instead of inline form; compact roles/branches/status, close/save handlers.
- Publish links: Admin-only endpoint; correct `/exec?view=shop` and booking route; `/dev` is rejected; copy/open/QR hooks exist.
- Regression: Forecast, Customer Identity, Analytics Materialization, dashboard migration, Billing and Audit suites pass unchanged.
- Frontend: Index.html SHA-256 matches Code.gs; 3.2.1 markers present.

All results are local simulations, not real browser/Google Apps Script production benchmarks.
