/** Pure unit/BOM functions, also embedded verbatim in Index for consistent previews. */
function moriUnitName_(value){
 var u=String(value||'').trim().toLowerCase(),aliases={gam:'g',gram:'g',grams:'g',gr:'g',kilogram:'kg',kilograms:'kg',lit:'l',litre:'l',liter:'l','lít':'l',liters:'l',milliliter:'ml','miligam':'mg'};
 return aliases[u]||u;
}
function moriBaseUnit_(item){return moriUnitName_(item&&item.baseUnit||(item&&item.type==='MATERIAL'?'g':'cái'));}
function moriUnitFactor_(item,unit,manualFactor){
 var base=moriBaseUnit_(item),from=moriUnitName_(unit||base),metric={kg:['MASS',1000],g:['MASS',1],mg:['MASS',0.001],l:['VOLUME',1000],ml:['VOLUME',1]};
 if(from===base)return 1;
 if(metric[from]&&metric[base]){
  if(metric[from][0]!==metric[base][0])throw new Error('Không thể đổi '+from+' sang '+base+' cho '+item.name);
  return metric[from][1]/metric[base][1];
 }
 var factors=item&&item.unitFactors||{},factor;
 Object.keys(factors).forEach(function(k){if(moriUnitName_(k)===from)factor=Number(factors[k]);});
 if(factor===undefined&&manualFactor!==undefined&&!metric[from])factor=Number(manualFactor);
 if(!Number.isFinite(factor)||factor<=0||factor>1000000)throw new Error('Chưa có quy đổi '+from+' → '+base+' cho '+item.name);
 return factor;
}
function moriComponentQty_(component,child){
 var qty=Number(component.qty),waste=Number(component.wastePercent||0);
 if(!Number.isFinite(qty)||qty<=0||qty>1000000||!Number.isFinite(waste)||waste<0||waste>100)throw new Error('Định lượng hoặc hao hụt không hợp lệ');
 return qty*moriUnitFactor_(child,component.unit||moriBaseUnit_(child))*(1+waste/100);
}
function moriRecipe_(itemId,index,branchId,quantity,trail){
 quantity=quantity===undefined?1:Number(quantity);trail=trail||[];
 var key=String(itemId),item=index[key];
 if(!item)throw new Error('Thiếu thành phần '+key);
 if(trail.indexOf(key)>=0||trail.length>12)throw new Error('Công thức bị lặp hoặc lồng quá sâu: '+item.name);
 if(!Number.isFinite(quantity)||quantity<0||quantity>100000000)throw new Error('Định lượng vượt giới hạn');
 var result={cost:0,needs:{},missingCost:[]};
 if(item.components&&item.components.length){
  item.components.forEach(function(c){
   var child=index[String(c.itemId)];if(!child)throw new Error('Thiếu nguyên liệu trong '+item.name);
   var part=moriRecipe_(child.id,index,branchId,quantity*moriComponentQty_(c,child),trail.concat(key));
   result.cost+=part.cost;Object.keys(part.needs).forEach(function(id){result.needs[id]=(result.needs[id]||0)+part.needs[id];});result.missingCost=result.missingCost.concat(part.missingCost);
  });
  var processing=Number(item.processingCost||0);if(!Number.isFinite(processing)||processing<0)throw new Error('Chi phí chế biến không hợp lệ');
  result.cost+=quantity*processing;
 }else{
  var branchCosts=item.costByBranch||{},cost=Object.prototype.hasOwnProperty.call(branchCosts,String(branchId))?branchCosts[String(branchId)]:item.cost;
  if(cost===undefined||cost===null||cost==='')result.missingCost.push(item.name);
  cost=Number(cost||0);if(!Number.isFinite(cost)||cost<0)throw new Error('Giá vốn không hợp lệ: '+item.name);
  result.cost=quantity*cost;
  if(item.track!==false&&item.type!=='SERVICE')result.needs[key]=quantity;
 }
 return result;
}
