/** Eight-column JSON storage. Fresh snapshots below live for ONE execution only. */
var MORI_SHEET_HANDLES_={},MORI_BOOK_HANDLES_={},MORI_DATA_STATE_={},MORI_CHANGED_DOCS_={},MORI_SHARED_READS_={},MORI_INVALIDATED_={};
var MORI_CACHE_TABLES_=['Items','Stores','Branches','Employees','Resources','Promotions','Customers','Settings','PublishSite'];
function moriResetReads_(){MORI_DATA_STATE_={};MORI_CHANGED_DOCS_={};MORI_SHARED_READS_={};MORI_INVALIDATED_={};}
function moriCacheRevision_(table,rotate){
 var cache=CacheService.getScriptCache(),key='mori:revision:3211:'+table,revision=rotate?null:cache.get(key);
 // Never reuse a default generation when a cache entry has been evicted.
 if(!revision){revision=Utilities.getUuid();cache.put(key,revision,21600);}return revision;
}
function moriState_(table){return MORI_DATA_STATE_[table]||(MORI_DATA_STATE_[table]={entries:Object.create(null),complete:false,last:null});}
function moriSheet_(table){
 if(MORI_SHEET_HANDLES_[table])return MORI_SHEET_HANDLES_[table];
 var ref=table==='Customers'&&moriProp_('CUSTOMERS_READY')==='1'?['CUSTOMERS','Customers']:MORI_TABLES[table];moriEnsure_(!!ref,'Unknown table '+table);
 var book=MORI_BOOK_HANDLES_[ref[0]];
 if(!book){var id=moriProp_('FILE_'+ref[0]);moriEnsure_(id,'Not set up: '+ref[0]);book=MORI_BOOK_HANDLES_[ref[0]]=SpreadsheetApp.openById(id);}
 var sheet=book.getSheetByName(ref[1]);moriEnsure_(sheet,'Missing sheet: '+ref[1]);
 return MORI_SHEET_HANDLES_[table]=sheet;
}
function moriLastRow_(table){var s=moriState_(table);if(s.last===null)s.last=moriSheet_(table).getLastRow();return s.last;}
function moriRow_(doc){var date=moriNow_();return [String(doc.id),String(doc.branchId||doc.branch_id||''),String(doc.email||'').toLowerCase(),String(doc.status||doc.orderStatus||''),String(doc.createdAt||date),String(doc.updatedAt||date),Number(doc.version||1),moriJson_(doc)];}
function moriDecode_(row){if(!row||!row[0]||!row[7])return null;try{var x=JSON.parse(row[7]);x.id=x.id===undefined?row[0]:x.id;x.version=Number(row[6])||1;return x;}catch(e){return null;}}
function moriRemember_(table,row,doc){if(doc)moriState_(table).entries[String(doc.id)]={row:row,doc:moriDeep_(doc)};return doc;}
function moriInvalidateShared_(table,force){
 delete MORI_SHARED_READS_[table];if(MORI_INVALIDATED_[table]&&!force)return;MORI_INVALIDATED_[table]=true;
 var cache=CacheService.getScriptCache();cache.remove('mori:'+table);cache.remove('mori:public');
 if(MORI_CACHE_TABLES_.indexOf(table)>=0)moriCacheRevision_(table,true);
 if(['Bills','StockIn','Items','Stores','Branches','Employees','ForecastPlans','Settings','AnalyticsDaily'].indexOf(table)>=0)cache.remove('mori:fc:epoch:315');
}
/** Rotate again AFTER flush: a concurrent old reader cannot repopulate the current cache. */
function moriFlushInvalidations_(){Object.keys(MORI_INVALIDATED_).forEach(function(table){moriInvalidateShared_(table,true);});}
// Also used after archive row deletion: discard every remembered row offset.
function moriClear_(table){delete MORI_DATA_STATE_[table];moriInvalidateShared_(table);}
function moriChanged_(table,row,doc){
 MORI_WRITE_DIRTY_=true;moriRemember_(table,row,doc);
  if((table==='Bills'||table==='StockIn')&&typeof moriAnalyticsCaptureChange_==='function')moriAnalyticsCaptureChange_(table,doc);
  if(table==='Bills'&&typeof moriCustomerCaptureBill_==='function')moriCustomerCaptureBill_(doc);
 (MORI_CHANGED_DOCS_[table]||(MORI_CHANGED_DOCS_[table]=Object.create(null)))[String(doc.id)]=moriDeep_(doc);
}
function moriAll_(table,useCache){
 var state=moriState_(table);
 if(state.complete)return Object.keys(state.entries).map(function(k){return state.entries[k];}).filter(function(e){return e&&e.doc;}).sort(function(a,b){return a.row-b.row;}).map(function(e){return moriDeep_(e.doc);});
 var cache=CacheService.getScriptCache(),key=null;
 var cacheable=useCache&&!MORI_LOCK_ACTIVE_&&MORI_CACHE_TABLES_.indexOf(table)>=0;
 if(cacheable){
  if(MORI_SHARED_READS_[table])return moriDeep_(MORI_SHARED_READS_[table]);
  key='mori:data:3211:'+table+':'+moriCacheRevision_(table,false);
  var raw=cache.get(key);if(raw){try{var cached=JSON.parse(raw);if(Array.isArray(cached)){MORI_SHARED_READS_[table]=cached;return moriDeep_(cached);}}catch(_){}}
 }
 var sh=moriSheet_(table),last=moriLastRow_(table),docs=[];
 if(last>=2)sh.getRange(2,1,last-1,8).getValues().forEach(function(row,j){var doc=moriDecode_(row);if(doc){moriRemember_(table,j+2,doc);docs.push(doc);}});
 state.complete=true;
 if(cacheable){MORI_SHARED_READS_[table]=moriDeep_(docs);var data=JSON.stringify(docs);if(data.length<24000)cache.put(key,data,45);}
 return docs;
}
function moriCachedOne_(table,id){return moriAll_(table,true).find(function(d){return String(d.id)===String(id);})||null;}
function moriFindRow_(table,id){
 var s=moriState_(table),key=String(id);
 if(Object.prototype.hasOwnProperty.call(s.entries,key))return s.entries[key]?s.entries[key].row:null;
 if(s.complete||((table==='AnalyticsLedger'||table==='AnalyticsDaily')&&s.analyticsIndexComplete))return null;
 var last=moriLastRow_(table);if(last<2)return null;
 var cell=moriSheet_(table).getRange(2,1,last-1,1).createTextFinder(key).matchCase(true).matchEntireCell(true).findNext();
 s.entries[key]=cell?{row:cell.getRow(),doc:null}:null;return cell?cell.getRow():null;
}
function moriFind_(table,id){
 var row=moriFindRow_(table,id);if(row===null)return null;
 var entry=moriState_(table).entries[String(id)];
 if(entry&&entry.doc)return moriDeep_(entry.doc);
 var doc=moriDecode_(moriSheet_(table).getRange(row,1,1,8).getValues()[0]);
 return moriRemember_(table,row,doc);
}
/** Search on the server; transfer matching records, never the entire Bill history. */
function moriRegexEscape_(value){return String(value).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
function moriFindJsonString_(table,field,value){
 var last=moriLastRow_(table);if(last<2)return null;
 var pattern=moriRegexEscape_(JSON.stringify(field))+'\\s*:\\s*'+moriRegexEscape_(JSON.stringify(String(value)))+'\\s*[,}]';
 var cells=moriSheet_(table).getRange(2,8,last-1,1).createTextFinder(pattern).matchCase(true).useRegularExpression(true).findAll();
 for(var i=0;i<cells.length;i++){
  var row=cells[i].getRow(),doc=moriDecode_(moriSheet_(table).getRange(row,1,1,8).getValues()[0]);
  if(doc&&doc[field]===String(value))return moriRemember_(table,row,doc);
 }
 return null;
}
function moriOpenBills_(){
 if(moriState_('Bills').complete)return moriAll_('Bills',false).filter(function(b){return b.status==='OPEN';});
 var last=moriLastRow_('Bills');if(last<2)return [];
 var rows=moriSheet_('Bills').getRange(2,4,last-1,1).createTextFinder('OPEN').matchCase(true).matchEntireCell(true).findAll().map(function(c){return c.getRow();}).sort(function(a,b){return a-b;}),groups=[],out=[];
 rows.forEach(function(row){var g=groups[groups.length-1];if(g&&g.start+g.count===row)g.count++;else groups.push({start:row,count:1});});
 groups.forEach(function(g){moriSheet_('Bills').getRange(g.start,1,g.count,8).getValues().forEach(function(row,j){var doc=moriDecode_(row);if(doc){moriRemember_('Bills',g.start+j,doc);out.push(doc);}});});
 return out;
}
function moriInsert_(table,doc){
 moriEnsure_(doc&&doc.id!==undefined,'Missing id');moriEnsure_(moriFindRow_(table,doc.id)===null,'ID already exists');
 doc.createdAt=doc.createdAt||moriNow_();doc.updatedAt=moriNow_();doc.version=Number(doc.version)||1;
 var row=moriLastRow_(table)+1;moriSheet_(table).getRange(row,1,1,8).setValues([moriRow_(doc)]);
 moriState_(table).last=row;moriChanged_(table,row,doc);moriInvalidateShared_(table);return moriDeep_(doc);
}
function moriPut_(table,doc,expectedVersion){return moriPutMany_(table,[{doc:doc,expectedVersion:expectedVersion}])[0];}
/** Validate all versions first; batch adjacent changed rows without overwriting gaps. */
function moriPutMany_(table,updates){
 var seen=Object.create(null),prepared=updates.map(function(u){
  var doc=moriDeep_(u.doc),id=String(doc.id);moriEnsure_(!seen[id],'Duplicate update');seen[id]=true;
  var existing=moriFind_(table,id),row=moriFindRow_(table,id);moriEnsure_(existing&&row!==null,'Record not found: '+table+'/'+id);
  if(u.expectedVersion!==undefined&&u.expectedVersion!==null)moriEnsure_(Number(existing.version)===Number(u.expectedVersion),'VERSION_CONFLICT: Dữ liệu đã được cập nhật trên thiết bị khác');
  doc.createdAt=existing.createdAt;doc.updatedAt=moriNow_();doc.version=Number(existing.version)+1;
  return {row:row,doc:doc,values:moriRow_(doc)};
 }),groups=[];
 prepared.slice().sort(function(a,b){return a.row-b.row;}).forEach(function(p){var g=groups[groups.length-1];if(g&&g[0].row+g.length===p.row)g.push(p);else groups.push([p]);});
 groups.forEach(function(g){
  moriSheet_(table).getRange(g[0].row,1,g.length,8).setValues(g.map(function(p){return p.values;}));
  g.forEach(function(p){moriChanged_(table,p.row,p.doc);});
  // Invalidate after each successful group, including a partial failure later.
  moriInvalidateShared_(table);
 });
 return prepared.map(function(p){return moriDeep_(p.doc);});
}
function moriUpsert_(table,doc,expectedVersion){return moriFindRow_(table,doc.id)===null?moriInsert_(table,doc):moriPut_(table,doc,expectedVersion);}
function moriAudit_(actor,action,entity,recordId,before,after){var changes={};
 if(before&&after){Object.keys(after).forEach(function(k){if(JSON.stringify(before[k])!==JSON.stringify(after[k]))changes[k]={before:before[k],after:after[k]};});}
 var doc={id:moriNext_('AUDIT'),branchId:after&&after.branchId||before&&before.branchId||'',at:moriNow_(),email:actor||'SYSTEM',action:action,entity:entity,recordId:String(recordId),changes:changes};
 var human=moriAuditDescribe_(action,entity,recordId,before,after);doc.description=human.description;doc.details=human.details;if(after?.clientRequestId)doc.clientRequestId=after.clientRequestId;
 moriInsert_('Audit',doc);return doc;
}
function moriRecent_(table,limit,branchId){var last=moriLastRow_(table),max=Math.min(last-1,Math.max(1,Number(limit)||1000));if(last<2)return [];
 var data=moriSheet_(table).getRange(last-max+1,1,max,8).getValues().map(moriDecode_).filter(Boolean).reverse();if(branchId!==undefined&&branchId!==null&&branchId!=='ALL')data=data.filter(function(x){return Number(x.branchId)===Number(branchId);});return data;
}
function moriListPage_(table,opts){opts=opts||{};var all=moriRecent_(table,Math.min(Math.max(Number(opts.scan)||2000,1),10000),opts.branchId);if(opts.status)all=all.filter(function(x){return x.status===opts.status;});
 var page=Math.max(1,Number(opts.page)||1),size=Math.min(100,Math.max(1,Number(opts.pageSize)||10));return {rows:all.slice((page-1)*size,page*size),total:all.length,page:page,pageSize:size,scanned:Number(opts.scan)||2000,hasMoreOutsideScan:moriLastRow_(table)-1>(Number(opts.scan)||2000)};
}

function moriInsertMany_(table,docs){
 if(!docs.length)return [];var seen={};
 var rows=docs.map(function(doc){var key=String(doc.id);moriEnsure_(!seen[key]&&moriFindRow_(table,key)===null,'ID already exists');seen[key]=true;doc.createdAt=doc.createdAt||moriNow_();doc.updatedAt=moriNow_();doc.version=1;return moriRow_(doc);});
 var start=moriLastRow_(table)+1;moriSheet_(table).getRange(start,1,rows.length,8).setValues(rows);moriState_(table).last=start+rows.length-1;
 docs.forEach(function(doc,j){moriChanged_(table,start+j,doc);});moriInvalidateShared_(table);return docs.map(moriDeep_);
}
