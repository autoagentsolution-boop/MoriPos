# Test Report — MoriPOS v3.2.5

- Source: MoriPOS v3.2.4
- Scope: holiday settings UI only, with frontend checksum/version bump in Code.gs
- Existing regression: 18 suites, 151 PASS groups (local simulated tests; hardcoded version expectations adjusted from 3.2.4 to 3.2.5)
- Additional test: preserved IDs and actions, aligned layout classes, success-only navigation, unchanged backend logic
- JavaScript syntax of Index scripts and all .gs files: PASS
- SHA-256 of Index.html equals Code.gs: PASS
- Production Google Apps Script execution/visual browser verification: not performed
