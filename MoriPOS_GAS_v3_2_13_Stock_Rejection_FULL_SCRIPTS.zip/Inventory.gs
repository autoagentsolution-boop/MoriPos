/** Server-authoritative inventory. Bill quantities and prices are NOT trusted from the browser. */
function moriItemIndex_(){var map={};moriAll_('Items',false).forEach(function(i){map[String(i.id)]=i;});return map;}
function moriInventorySource_(item,branchId){var by=item.stockByBranch||{},key=String(branchId);return Object.prototype.hasOwnProperty.call(by,key)?{scope:key,qty:Number(by[key])||0}:{scope:'STORE',qty:Number(item.stock)||0};}
function moriInventoryNeeds_(items,index){var needs={};
 items.forEach(function(line){var qty=Number(line.qty);moriEnsure_(Number.isFinite(qty)&&qty>0&&qty<=1000000,'Số lượng không hợp lệ');
  var recipe=moriRecipe_(line.id,index,0,qty);Object.keys(recipe.needs).forEach(function(id){needs[id]=(needs[id]||0)+recipe.needs[id];});
 });return needs;
}
function moriReservations_(branchId,exceptBillId,index){var out={};moriOpenBills_().forEach(function(b){
 if(String(b.id)===String(exceptBillId)||b.channel!=='ONLINE')return;
 if(['CANCELLED','REJECTED','DELIVERED','REFUNDED'].indexOf(b.orderStatus)>=0||b.inventoryConsumed===true)return;
 if(['CONFIRMED','PREPARING','SHIPPING','ALLOCATING'].indexOf(b.orderStatus)<0)return;
 var needs=b.inventoryNeeds||moriInventoryNeeds_(b.items||[],index);
 Object.keys(needs).forEach(function(itemId){var it=index[itemId];if(!it)return;var target=moriInventorySource_(it,branchId),other=moriInventorySource_(it,b.branchId);
  if(target.scope==='STORE'&&other.scope==='STORE'||target.scope===other.scope&&target.scope!=='STORE'&&Number(b.branchId)===Number(branchId))out[itemId]=(out[itemId]||0)+Number(needs[itemId]);
 });
 });return out;
}
function moriInventoryValidate_(lines,branchId,excludeId,index,settings){index=index||moriItemIndex_();settings=settings||moriFind_('Settings','global')||{};
 if(settings.modules&&settings.modules.stockIn===false)return {};
 var needs=moriInventoryNeeds_(lines,index);if(!Object.keys(needs).length)return needs;
 var res=moriReservations_(branchId,excludeId,index),block=settings.lowStockPolicy==='BLOCK'?Number(settings.lowStockThreshold)||0:0;
 Object.keys(needs).forEach(function(id){var item=index[id],source=moriInventorySource_(item,branchId),free=source.qty-(res[id]||0)-block;
  moriEnsure_(needs[id]<=free+1e-8,'Không đủ tồn: '+item.name+' · còn khả dụng '+Math.max(0,free).toFixed(2));
 });return needs;
}
/** Once-per-operation stock mutation, including retry after a partial failed spreadsheet write. */
function moriStockDelta_(needs,branchId,operationId,sign,index){index=index||moriItemIndex_();var changed=[],updates=[];
 Object.keys(needs).forEach(function(itemId){var item=index[itemId];moriEnsure_(item,'Không tìm thấy mặt hàng '+itemId);
  var ops=item.appliedOps||{},key=String(operationId);
  if(ops[key])return;
  var src=moriInventorySource_(item,branchId),delta=Number(needs[itemId])*sign;
  if(src.scope==='STORE'){item.stock=(Number(item.stock)||0)+delta;moriEnsure_(item.stock>=-0.000001,'Không đủ tồn cấp cửa hàng');}
  else{item.stockByBranch=item.stockByBranch||{};item.stockByBranch[src.scope]=(Number(item.stockByBranch[src.scope])||0)+delta;moriEnsure_(item.stockByBranch[src.scope]>=-0.000001,'Không đủ tồn cấp chi nhánh');}
  ops[key]=moriNow_();var ids=Object.keys(ops);if(ids.length>200)ids.sort(function(a,b){return ops[a]<ops[b]?-1:1;}).slice(0,ids.length-200).forEach(function(k){delete ops[k]});item.appliedOps=ops;
  updates.push({doc:item,expectedVersion:item.version});changed.push(itemId);
 });
 moriPutMany_('Items',updates).forEach(function(item){index[String(item.id)]=item;});
 return changed;
}
function moriStockCreate_(actor,request){moriRequire_(actor,['ADMIN','MANAGER','EMPLOYEE'],request.branchId);var lines=request.lines||[];
 moriEnsure_(Array.isArray(lines)&&lines.length>0&&lines.length<=100,'Chưa có hàng nhập');
 var index=moriItemIndex_(),normalized=lines.map(function(l){var it=index[String(l.id)];moriEnsure_(it,'Mặt hàng không tồn tại');var qty=Number(l.qty),unit=String(l.unit||(Number(l.factor||1)!==1?'quy đổi':moriBaseUnit_(it))),factor=moriUnitFactor_(it,unit,l.factor),price=Number(l.cost);
  moriEnsure_(qty>0&&qty<=100000&&factor>0&&factor<=1000000&&price>=0&&price<=1000000000,'Dữ liệu nhập kho không hợp lệ');
  return {id:it.id,name:it.name,qty:qty,unit:moriUnitName_(unit),factor:factor,baseQty:qty*factor,cost:price,unitCostBase:price/factor};
 });
 moriEnsure_(String(request.shipping||'').trim().length>0,'Thiếu thông tin giao hàng');
 if(actor.role==='EMPLOYEE')moriEnsure_(Array.isArray(request.photoIds)&&request.photoIds.length>0,'Nhân viên phải đính kèm ảnh chứng từ');
 var id=moriNext_('STOCKIN'),doc={id:id,branchId:Number(request.branchId),employee:actor.email,supplier:String(request.supplier||''),carrier:String(request.carrier||''),tracking:String(request.tracking||''),shipping:String(request.shipping||''),photoIds:request.photoIds||[],lines:normalized,totalCost:normalized.reduce(function(n,x){return n+x.qty*x.cost;},0),status:'SUBMITTED',date:moriNow_()};
 moriInsert_('StockIn',doc);moriAudit_(actor.email,'CREATE','STOCKIN',id,null,doc);return doc;
}
function moriStockConfirm_(actor,id){moriRequire_(actor,['ADMIN','MANAGER']);var doc=moriFind_('StockIn',id);moriEnsure_(doc,'Không có phiếu nhập');moriRequire_(actor,['ADMIN','MANAGER'],doc.branchId);
 moriEnsure_(['SUBMITTED','APPLYING','CONFIRMED'].indexOf(doc.status)>=0,'Phiếu không thể duyệt');if(doc.status==='CONFIRMED')return doc;
 var before=moriDeep_(doc),index=moriItemIndex_(),updates=Object.create(null);
 // Interruption-safe at item level: appliedOps on each item prevents a second stock addition on retry.
 if(doc.status==='SUBMITTED'){doc.status='APPLYING';doc=moriPut_('StockIn',doc,doc.version);}
 doc.lines.forEach(function(line,lineIndex){
   var it=index[String(line.id)],op='STOCKIN:'+doc.id+':'+lineIndex;
   if(it.appliedOps&&it.appliedOps[op])return;
   var src=moriInventorySource_(it,doc.branchId),old=Number(src.qty)||0,
       oldCost=Number(src.scope==='STORE'?(it.cost||0):((it.costByBranch||{})[String(doc.branchId)]??it.cost??0));
   var base=Number(line.baseQty),unitCost=Number(line.unitCostBase);
   moriEnsure_(base>0&&unitCost>=0,'Phiếu nhập không hợp lệ');
   if(src.scope==='STORE'){it.stock=old+base;it.cost=(old*oldCost+base*unitCost)/(old+base);}
   else{it.stockByBranch=it.stockByBranch||{};it.stockByBranch[src.scope]=old+base;it.costByBranch=it.costByBranch||{};it.costByBranch[src.scope]=(old*oldCost+base*unitCost)/(old+base);}
   it.appliedOps=it.appliedOps||{};it.appliedOps[op]=moriNow_();
   var keys=Object.keys(it.appliedOps);if(keys.length>200)keys.sort(function(a,b){return it.appliedOps[a]<it.appliedOps[b]?-1:1;}).slice(0,keys.length-200).forEach(function(k){delete it.appliedOps[k]});
   // Several receipt lines can refer to the same item: aggregate in memory,
   // keep one expected version, and batch adjacent rows after every line validates.
   if(!updates[String(line.id)])updates[String(line.id)]={doc:it,expectedVersion:it.version};
 });
 moriPutMany_('Items',Object.keys(updates).map(function(id){return updates[id];})).forEach(function(item){index[String(item.id)]=item;});

 doc.status='CONFIRMED';doc.confirmedAt=moriNow_();doc.confirmedBy=actor.email;doc=moriPut_('StockIn',doc,doc.version);moriAudit_(actor.email,'CONFIRM','STOCKIN',id,before,doc);return doc;
}

/** Reject only a pending receipt. Confirmed/applying receipts must never be reversed here. */
function moriStockReject_(actor,request){
 moriRequire_(actor,['ADMIN','MANAGER']);
 var doc=moriFind_('StockIn',request.id);moriEnsure_(doc,'Không có phiếu nhập');
 moriRequire_(actor,['ADMIN','MANAGER'],doc.branchId);
 var reason=String(request.reason||'').trim();
 moriEnsure_(reason.length>0&&reason.length<=500,'Nhập lý do từ chối (tối đa 500 ký tự)');
 // A retry after a lost response returns the committed receipt without another write/audit.
 if(doc.status==='REJECTED'){
  moriEnsure_(doc.rejectionReason===reason,'Phiếu đã bị từ chối với lý do khác. Hãy làm mới dữ liệu.');
  return doc;
 }
 moriEnsure_(doc.status==='SUBMITTED','Chỉ được từ chối phiếu đang chờ duyệt');
 moriEnsure_(Number.isInteger(Number(request.version))&&Number(request.version)===Number(doc.version),'VERSION_CONFLICT: Phiếu đã thay đổi. Hãy làm mới và mở lại phiếu.');
 var before=moriDeep_(doc);
 doc.status='REJECTED';doc.rejectionReason=reason;doc.rejectedAt=moriNow_();doc.rejectedBy=actor.email;
 doc=moriPut_('StockIn',doc,request.version);
 moriAudit_(actor.email,'REJECT','STOCKIN',doc.id,before,doc);
 return doc;
}
