/** Deterministic planning math. Shared verbatim with the browser; no service calls. */
function moriForecastDefaults_(){return {lookbackDays:28,fixedCosts:0,fixedCostMode:'MANUAL',extraFixedCosts:0,goal:{mode:'FIXED',value:1000000,baselineMode:'PREVIOUS',baselineProfit:0}};}
function moriForecastCalculate_(plan,snapshot){
 plan=moriForecastNormalize_(plan);
 var index={},selected=plan.items||[],stats=snapshot.byItem||{},periodDays=Number(snapshot.periodDays)||1,remainingDays=Math.max(0,Number(snapshot.remainingDays)||0),elapsedDays=Math.min(periodDays,Math.max(0,Number(snapshot.elapsedDays)||0));
 (snapshot.items||[]).forEach(function(it){index[String(it.id)]=it;});
 var fixed=Number(plan.fixedCosts)||0,goal=plan.goal||moriForecastDefaults_().goal,recipes={},actual={quantity:0,revenue:0,cost:0,extraCost:0,profit:0},previous={revenue:0,cost:0,extraCost:0,profit:0},referenceQty=0,warnings=[];
 selected.forEach(function(line){
  var id=String(line.itemId),st=stats[id]||{},extra=Number(line.extraCost)||0;
  recipes[id]=moriRecipe_(id,index,plan.branchId,1);
  actual.quantity+=Number(st.currentQty)||0;actual.revenue+=Number(st.currentRevenue)||0;actual.cost+=Number(st.currentCost)||0;actual.extraCost+=(Number(st.currentQty)||0)*extra;
  previous.revenue+=Number(st.previousRevenue)||0;previous.cost+=Number(st.previousCost)||0;previous.extraCost+=(Number(st.previousQty)||0)*extra;
  referenceQty+=Number(st.referenceQty)||0;
  recipes[id].missingCost.forEach(function(name){warnings.push('Chưa có giá vốn: '+name);});
  if(st.estimatedCostLines)warnings.push('Giá vốn cũ của '+index[id].name+' có dòng được ước tính theo giá vốn hiện tại.');
 });
 actual.profit=actual.revenue-actual.cost-actual.extraCost-fixed*elapsedDays/periodDays;
 previous.profit=previous.revenue-previous.cost-previous.extraCost-fixed;
 var baseline=goal.baselineMode==='MANUAL'?Number(goal.baselineProfit)||0:previous.profit;
 var fixedTarget=goal.mode==='GROWTH'?baseline*(1+Number(goal.value)/100):Number(goal.value)||0;
 var goalValid=goal.mode!=='GROWTH'||baseline>0;
 if(!goalValid)warnings.push('Mục tiêu tăng trưởng cần lợi nhuận tham chiếu dương. Chọn số tiền cố định hoặc nhập mức tham chiếu khác.');
 if(!referenceQty)warnings.push('Chưa có doanh số trong kỳ tham chiếu; số lượng kịch bản cần nhập theo giả định của bạn.');
 var extraMap={};selected.forEach(function(l){extraMap[String(l.itemId)]=Number(l.extraCost)||0;});
 var scenarios=(plan.scenarios||[]).map(function(scenario){
  var revenue=0,cost=0,quantity=0,remainingQty=0,remainingRevenue=0,needs={},lines=[],paceRevenue=0,paceCost=0,historicalRevenue=0,plannedRevenue=0,historicalCost=0,plannedCost=0,variableExtraCost=0,dailyReference=referenceQty/(Number(snapshot.lookbackDays)||28);
  (scenario.lines||[]).forEach(function(line){
   var id=String(line.itemId),st=stats[id]||{},recipe=recipes[id],extra=extraMap[id]||0,actualQty=Number(st.currentQty)||0,rest=remainingDays>0?Math.max(0,Number(line.quantity)-actualQty):0,price=Number(line.price),unitCost=recipe.cost+extra;
   var lineRevenue=(Number(st.currentRevenue)||0)+rest*price,lineCost=(Number(st.currentCost)||0)+actualQty*extra+rest*unitCost;
   revenue+=lineRevenue;cost+=lineCost;historicalRevenue+=Number(st.currentRevenue)||0;plannedRevenue+=rest*price;historicalCost+=Number(st.currentCost)||0;plannedCost+=rest*recipe.cost;variableExtraCost+=(actualQty+rest)*extra;quantity+=actualQty+rest;remainingQty+=rest;remainingRevenue+=rest*price;
   Object.keys(recipe.needs).forEach(function(k){needs[k]=(needs[k]||0)+recipe.needs[k]*rest;});
   var paceQty=(Number(st.referenceQty)||0)/(Number(snapshot.lookbackDays)||28)*remainingDays;
   paceRevenue+=(Number(st.currentRevenue)||0)+paceQty*price;paceCost+=(Number(st.currentCost)||0)+actualQty*extra+paceQty*unitCost;
   lines.push({itemId:line.itemId,name:index[id].name,unit:moriBaseUnit_(index[id]),plannedQuantity:Number(line.quantity),actualQuantity:actualQty,remainingQuantity:rest,forecastQuantity:actualQty+rest,price:price,unitCost:unitCost,unitProfit:price-unitCost,referenceDaily:(Number(st.referenceQty)||0)/(Number(snapshot.lookbackDays)||28),revenue:lineRevenue,cost:lineCost,overPlan:actualQty>Number(line.quantity)});
  });
  cost+=fixed;var profit=revenue-cost,rate=Number(goal.value)/100;
  var target=goal.mode==='MARGIN'?revenue*rate:goal.mode==='MARKUP'?cost*rate:fixedTarget;
  var requiredRevenue=goal.mode==='MARGIN'?cost/(1-rate):goal.mode==='MARKUP'?cost*(1+rate):cost+fixedTarget;
  var gap=Math.max(0,target-profit),requiredRemainingRevenue=Math.max(0,requiredRevenue-actual.revenue),priceScale=remainingRevenue>0?Math.max(1,requiredRemainingRevenue/remainingRevenue):null;
  var materialRows=Object.keys(needs).map(function(id){
   var item=index[id],available=Math.max(0,Number((snapshot.available||{})[id])||0),shortage=Math.max(0,needs[id]-available),costs=item.costByBranch||{},unitCost=Number(costs[String(plan.branchId)]??item.cost??0);
   return {itemId:item.id,name:item.name,unit:moriBaseUnit_(item),kind:item.type==='PRODUCT'?'Thành phẩm':'Nguyên liệu',needed:needs[id],available:available,afterPlan:Math.max(0,available-needs[id]),shortage:shortage,purchaseUnitCost:unitCost,purchaseCost:shortage*unitCost};
  }).sort(function(a,b){return b.shortage-a.shortage;});
  var canProduce=materialRows.every(function(r){return r.shortage<1e-8;}),extraChoice=null;
  if(materialRows.some(function(r){return r.shortage>1e-8&&r.purchaseUnitCost<=0;}))warnings.push('Có mặt hàng cần nhập thêm nhưng chưa có đơn giá nhập/giá vốn; tiền mua thêm có thể bị tính thiếu.');
  if(goalValid&&gap>1e-6&&remainingDays>0){
   lines.forEach(function(line){
    var contribution=goal.mode==='MARGIN'?line.price*(1-rate)-line.unitCost:goal.mode==='MARKUP'?line.price-line.unitCost*(1+rate):line.unitProfit;
    if(contribution>0&&(!extraChoice||contribution>extraChoice.contribution))extraChoice={itemId:line.itemId,name:line.name,unit:line.unit,contribution:contribution,quantity:Math.ceil((gap-1e-7)/contribution)};
   });
   if(extraChoice){
    var recipe=recipes[String(extraChoice.itemId)],limit=Infinity;
    Object.keys(recipe.needs).forEach(function(id){limit=Math.min(limit,Math.floor((Math.max(0,Number((snapshot.available||{})[id])||0)-(needs[id]||0)+1e-8)/recipe.needs[id]));});
    extraChoice.stockCapacity=Number.isFinite(limit)?Math.max(0,limit):null;extraChoice.requiresPurchase=extraChoice.stockCapacity!==null&&extraChoice.quantity>extraChoice.stockCapacity;
   }
  }
  lines.forEach(function(line){line.suggestedPrice=priceScale===null?null:Math.ceil(line.price*priceScale/100)*100;});
  var dailyNeeded=remainingDays>0?remainingQty/remainingDays:null,demandMultiple=dailyReference>0&&dailyNeeded!==null?dailyNeeded/dailyReference:null;
  return {id:scenario.id,name:scenario.name,lines:lines,quantity:quantity,remainingQuantity:remainingQty,revenue:revenue,cost:cost,profit:profit,costBreakdown:{historicalRevenue:historicalRevenue,plannedRevenue:plannedRevenue,historicalCOGS:historicalCost,plannedCOGS:plannedCost,extraPerUnit:variableExtraCost,operatingCost:fixed},margin:revenue>0?profit/revenue*100:null,targetProfit:target,goalValid:goalValid,gap:goalValid?gap:null,met:goalValid&&profit+1e-6>=target,additionalRevenue:goalValid?Math.max(0,requiredRevenue-revenue):null,extraChoice:extraChoice,materials:materialRows,purchaseCost:materialRows.reduce(function(n,r){return n+r.purchaseCost;},0),canProduce:canProduce,dailyNeeded:dailyNeeded,demandMultiple:demandMultiple,paceProfit:paceRevenue-paceCost-fixed,daysRemaining:remainingDays};
 });
 var sameAssumptions=scenarios.length===3&&scenarios.every(function(sc){return JSON.stringify(sc.lines.map(function(l){return [l.itemId,l.plannedQuantity,l.price];}))===JSON.stringify(scenarios[0].lines.map(function(l){return [l.itemId,l.plannedQuantity,l.price];}));});
 var candidates=sameAssumptions?[]:scenarios.filter(function(s){return s.met&&s.goalValid&&remainingDays>0&&s.canProduce&&(s.demandMultiple===null||s.demandMultiple<=1.2);});
 candidates.sort(function(a,b){return Number(b.met)-Number(a.met)||b.profit-a.profit;});
 return {actual:actual,previous:previous,baselineProfit:baseline,referenceDaily:referenceQty/(Number(snapshot.lookbackDays)||28),periodDays:periodDays,remainingDays:remainingDays,elapsedDays:elapsedDays,scenarios:scenarios,recommendedId:candidates[0]?candidates[0].id:null,warnings:Array.from(new Set(warnings)),scope:'SELECTED_ITEMS',identicalScenarios:sameAssumptions};
}
function moriForecastNumber_(value,min,max,label){var n=Number(value);if(!Number.isFinite(n)||n<min||n>max)throw new Error(label+' không hợp lệ');return n;}
function moriForecastDay_(value){var s=String(value||''),d=new Date(s+'T00:00:00Z');if(!/^\d{4}-\d{2}-\d{2}$/.test(s)||isNaN(d.getTime())||d.toISOString().slice(0,10)!==s)throw new Error('Ngày kế hoạch không hợp lệ');return s;}
function moriForecastShift_(day,n){return new Date(new Date(day+'T00:00:00Z').getTime()+n*86400000).toISOString().slice(0,10);}
function moriForecastConfig_(raw){
 raw=raw||moriForecastDefaults_();var g=raw.goal||moriForecastDefaults_().goal,mode=String(g.mode||'FIXED');
 if(['FIXED','MARKUP','MARGIN','GROWTH'].indexOf(mode)<0)throw new Error('Cách tính mục tiêu không hợp lệ');
 if(!Number.isInteger(Number(raw.lookbackDays??28)))throw new Error('Số ngày tham chiếu phải là số nguyên');
 return {lookbackDays:moriForecastNumber_(raw.lookbackDays??28,1,180,'Số ngày tham chiếu'),fixedCosts:moriForecastNumber_(raw.fixedCosts??0,0,1e12,'Chi phí vận hành kỳ'),fixedCostMode:raw.fixedCostMode==='AUTO'?'AUTO':'MANUAL',extraFixedCosts:moriForecastNumber_(raw.extraFixedCosts??0,0,1e12,'Chi phí vận hành bổ sung'),goal:{mode:mode,value:moriForecastNumber_(g.value??0,0,mode==='MARGIN'?95:mode==='FIXED'?1e12:10000,'Mục tiêu lợi nhuận'),baselineMode:g.baselineMode==='MANUAL'?'MANUAL':'PREVIOUS',baselineProfit:moriForecastNumber_(g.baselineProfit??0,-1e12,1e12,'Lợi nhuận tham chiếu')}};
}
function moriForecastNormalize_(raw){
 var config=moriForecastConfig_(raw),start=moriForecastDay_(raw.startDate),end=moriForecastDay_(raw.endDate),days=(Date.parse(end)-Date.parse(start))/86400000+1;
 if(days<1||days>366)throw new Error('Kỳ kế hoạch phải từ 1 đến 366 ngày');
 var items=raw.items||[],seen={};if(!items.length||items.length>40)throw new Error('Chọn từ 1 đến 40 mặt hàng');
 items=items.map(function(l){var id=String(l.itemId);if(!id||seen[id])throw new Error('Mặt hàng trong kế hoạch bị trùng');seen[id]=true;return {itemId:l.itemId,extraCost:moriForecastNumber_(l.extraCost??0,0,1e9,'Chi phí thêm mỗi đơn vị')};});
 if(!Array.isArray(raw.scenarios)||raw.scenarios.length!==3)throw new Error('Cần đúng 3 kịch bản');
 var scenarios=raw.scenarios.map(function(s,i){var ids={},lines=s.lines||[];if(lines.length!==items.length)throw new Error('Các kịch bản phải cùng danh sách mặt hàng');
  return {id:'S'+(i+1),name:String(s.name||['Thận trọng','Cơ sở','Tăng trưởng'][i]).slice(0,80),lines:lines.map(function(l){var id=String(l.itemId);if(!seen[id]||ids[id])throw new Error('Mặt hàng kịch bản không hợp lệ');ids[id]=true;return {itemId:l.itemId,quantity:moriForecastNumber_(l.quantity,0,1e6,'Số lượng kế hoạch'),price:moriForecastNumber_(l.price,0,1e9,'Giá bán kế hoạch')};})};
 });
 return Object.assign({},config,{id:raw.id,version:raw.version,clientRequestId:String(raw.clientRequestId||'').slice(0,128),name:String(raw.name||'Kế hoạch bán hàng').trim().slice(0,160),branchId:moriForecastNumber_(raw.branchId,1,1e9,'Chi nhánh'),startDate:start,endDate:end,items:items,scenarios:scenarios});
}
