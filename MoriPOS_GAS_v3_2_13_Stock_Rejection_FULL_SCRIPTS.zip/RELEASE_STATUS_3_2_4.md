# Release status — MoriPOS 3.2.4

**Status:** Candidate ready for staging / manual Apps Script verification.

**Scope:** Catalog UI, item active/inactive state, holiday prices, Admin holiday calendar configuration, server billing/public price selection.

**Scope unchanged:** authentication, customer identity, Forecast calculations, stock ledger, AnalyticsDaily, Store/Branch workbooks, receipt generation.

**Check:** local tests 18 suites / 151 groups PASS. No live deployment benchmark or production checkout tested.

**Rollback:** keep previous 3.2.3 source/deployment. Existing new JSON keys are backward-compatible; disabling holiday pricing or reverting code restores the prior normal-pricing behavior. Paid bills always keep their stored unit prices.
