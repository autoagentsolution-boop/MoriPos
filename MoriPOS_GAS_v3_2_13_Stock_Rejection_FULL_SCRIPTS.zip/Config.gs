/** Mori POS 3.0 — backend configuration. All IDs live in Script Properties, never in HTML. */
var MORI_TABLES = {
  Stores:['MASTER','Stores'], Branches:['MASTER','Branches'], Employees:['MASTER','Employees'],
  AccessControl:['MASTER','AccessControl'], Resources:['MASTER','Resources'], Promotions:['MASTER','Promotions'],
  GuestIdentities:['CUSTOMERS','GuestIdentities'], CustomerIdentityLinks:['CUSTOMERS','CustomerIdentityLinks'], CustomerOrderLinks:['CUSTOMERS','CustomerOrderLinks'], CustomerDayIndex:['CUSTOMERS','CustomerDayIndex'], CustomerDaily:['DASHBOARD','CustomerDaily'],
  ForecastPlans:['MASTER','ForecastPlans'], AnalyticsDaily:['DASHBOARD','AnalyticsDaily'], AnalyticsLedger:['DASHBOARD','AnalyticsLedger'], Customers:['MASTER','Customers'], Settings:['MASTER','Settings'], PublishSite:['MASTER','PublishSite'],
  Items:['ITEMS','Items'], StockIn:['STOCKIN','StockIn'], Bills:['BILLS','SalesBills'],
  Booking:['BOOKING','Booking'], Attendance:['ATTENDANCE','Attendance'], Audit:['AUDIT','Audit']
};
var MORI_HEADERS = ['id','branch_id','email','status','created_at','updated_at','version','data_json'];
var MORI_FILE_NAMES = {MASTER:'POS_Master',ITEMS:'POS_Items',STOCKIN:'POS_StockIn',BILLS:'POS_Bills',BOOKING:'POS_Booking',ATTENDANCE:'POS_Attendance',AUDIT:'POS_Audit',DASHBOARD:'POS_Dashboard',CUSTOMERS:'POS_Customers'};
var MORI_TZ='Asia/Ho_Chi_Minh';
function moriProp_(k){return PropertiesService.getScriptProperties().getProperty('MORI_'+k);}
function moriSetProp_(k,v){PropertiesService.getScriptProperties().setProperty('MORI_'+k,String(v));}
function moriNow_(){return new Date().toISOString();}
function moriEnsure_(ok,msg){if(!ok)throw new Error(msg||'Không hợp lệ');}
function moriDeep_(x){return JSON.parse(JSON.stringify(x));}
function moriJson_(x){var str=JSON.stringify(x);moriEnsure_(str.length<=46000,'Dữ liệu quá dài cho một ô Google Sheet');return str;}
function moriKey_(v){return String(v===undefined||v===null?'':v).trim();}
var MORI_LOCK_WAIT_MS_=0, MORI_WRITE_DIRTY_=false, MORI_LOCK_ACTIVE_=false;
function moriLock_(fn){
 var lock=LockService.getScriptLock(),started=Date.now();
 moriEnsure_(lock.tryLock(25000),'Hệ thống bận. Thử lại sau vài giây');
 MORI_LOCK_WAIT_MS_=Date.now()-started;MORI_LOCK_ACTIVE_=true;
 // A snapshot obtained before waiting for the lock cannot authorize a write.
 if(typeof moriResetReads_==='function')moriResetReads_();
 try{return fn();}finally{
  try{if(MORI_WRITE_DIRTY_)SpreadsheetApp.flush();}
  finally{
   // The analytics outbox is persisted while the writer lock is still held.
   // Failing to enqueue must not cause a paid bill to be retried/double-charged.
   try{if(typeof moriAnalyticsFlushPending_==='function')moriAnalyticsFlushPending_();}
   catch(e){console.error('Analytics outbox failure: '+e.message);try{moriSetProp_('ANALYTICS_REPAIR_REQUIRED','1');}catch(_){}}
   try{if(typeof moriCustomerFlushPending_==='function')moriCustomerFlushPending_();}
   catch(e){console.error('Customer outbox failure: '+e.message);try{moriSetProp_('CUSTOMER_REPAIR_REQUIRED','1');}catch(_){}}
   try{if(typeof moriFlushInvalidations_==='function')moriFlushInvalidations_();}
   catch(e){console.error('Catalog cache invalidation: '+e.message);}
   MORI_WRITE_DIRTY_=false;MORI_LOCK_ACTIVE_=false;lock.releaseLock();
  }
 }
}
function moriDate_(d){return Utilities.formatDate(d||new Date(),MORI_TZ,'yyyy-MM-dd');}
function moriNext_(type){var prop=PropertiesService.getScriptProperties(),key='MORI_SEQ_'+type;var n=Number(prop.getProperty(key)||0)+1;prop.setProperty(key,String(n));return n;}
function moriNorm_(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/đ/g,'d').trim();}
/** Privileged maintenance functions must run as the actual editor/owner, not merely execute-as-owner Web App. */
function moriEditorOnly_(){var active=String(Session.getActiveUser().getEmail()||'').toLowerCase(),effective=String(Session.getEffectiveUser().getEmail()||'').toLowerCase(),owner=String(moriProp_('OWNER_EMAIL')||'').toLowerCase();
 moriEnsure_(active&&effective&&active===effective&&(!owner||owner===active),'Chỉ chủ hệ thống được chạy hàm bảo trì từ Apps Script editor');}
