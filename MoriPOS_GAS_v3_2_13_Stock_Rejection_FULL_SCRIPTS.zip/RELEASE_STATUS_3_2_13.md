# MoriPOS 3.2.13

Thêm từ chối phiếu nhập chờ duyệt với lý do, người xử lý, thời gian và nhật ký; server kiểm tra quyền/chi nhánh/phiên bản. Giữ tồn kho và giá vốn khi từ chối. UI cập nhật từ một kết quả ghi đã xác nhận, dùng loading trên nút.

Runtime thay đổi so với 3.2.12: Index.html, Code.gs (build/checksum), Inventory.gs, Operations.gs, AuditFormat.gs, Archive.gs. Giữ nguyên thay đổi danh mục/dropdown và tính giá combo của các bản trước.

Kiểm tra: 24 suites / 202 nhóm mô phỏng đạt. Không phải benchmark live và chưa triển khai Web App. Không thêm cơ chế lưu nền/cache mới. Hướng dẫn: README_UPGRADE_3_2_13.md.
