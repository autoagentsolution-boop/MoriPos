/** Staff authentication for execute-as-owner web apps: email OTP to an allowlisted account. */
function moriAuthStart(email){moriEnsure_(moriProp_('READY')==='1','Mori setup incomplete');email=String(email||'').toLowerCase().trim();
 moriEnsure_(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email),'Email không hợp lệ');
 // This is the staff portal. Verify allowlist BEFORE creating the OTP or sending email.
 var entry=moriFind_('AccessControl',email);
 moriEnsure_(!!entry,'Email này chưa được cấp quyền truy cập hệ thống quản lý. Vui lòng liên hệ Admin.');
 moriEnsure_(entry.isActive!==false,'Tài khoản này đang tạm khóa. Vui lòng liên hệ Admin.');
 moriUser_(entry); // Verify valid role and branch scope server-side.
 var key=Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,email)).slice(0,30),cache=CacheService.getScriptCache();
 moriEnsure_(!cache.get('mori:otp:cool:'+key),'Vui lòng chờ trước khi gửi mã mới');
 var src=Utilities.getUuid()+':'+Utilities.getUuid(),hash=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,src),digits=hash.slice(0,4).reduce(function(v,b){return v*256+(b<0?b+256:b);},0)%1000000,code=('000000'+digits).slice(-6);
 var digest=Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,code+':'+src));
 // Reserve per-email resend cooldown before sending. Do not create usable session yet.
 cache.put('mori:otp:cool:'+key,'1',60);
 cache.put('mori:otp:'+key,JSON.stringify({salt:src,hash:digest,tries:0}),300);
 MailApp.sendEmail({to:email,subject:'Mori POS — Mã đăng nhập',body:'Mã đăng nhập Mori POS: '+code+'\nHết hạn sau 5 phút. Nếu bạn không yêu cầu, hãy bỏ qua email này.'});
 return {ok:true,message:'Mã xác thực đã gửi đến email.',expiresInSeconds:300};
}

function moriAuthVerify(email,code,withBootstrap){var started=Date.now();email=String(email||'').toLowerCase().trim();var key=Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,email)).slice(0,30),cache=CacheService.getScriptCache(),raw=cache.get('mori:otp:'+key);moriEnsure_(raw,'Mã hết hạn hoặc không tồn tại');var o=JSON.parse(raw);
 moriEnsure_(o.tries<3,'Quá số lần nhập sai');var input=Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(code)+':'+o.salt));
 if(input!==o.hash){o.tries++;cache.put('mori:otp:'+key,JSON.stringify(o),300);throw new Error('Mã không đúng');}
 cache.remove('mori:otp:'+key);var acl=moriFind_('AccessControl',email);moriEnsure_(acl&&acl.isActive!==false,'Không có quyền truy cập');
 var token=Utilities.getUuid()+'-'+Utilities.getUuid(),tokenKey=moriTokenKey_(token);cache.put(tokenKey,JSON.stringify({email:email,at:moriNow_()}),21600);
 var user=moriUser_(acl),result={ok:true,token:token,user:user},authMs=Date.now()-started;
 if(withBootstrap===true){try{result.data=moriBootstrapFor_(user,true);}catch(e){result.bootstrapError=String(e.message||e);}}
 result.timing={serverMs:Date.now()-started,authMs:authMs};return result;
}
function moriTokenKey_(token){var v=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(token||''));return 'mori:session:'+Utilities.base64EncodeWebSafe(v).slice(0,36);}
function moriUser_(acl){
 var role=String(acl.role||'');moriEnsure_(['ADMIN','MANAGER','EMPLOYEE'].indexOf(role)>=0,'Quyền truy cập không hợp lệ');
 var branches=(acl.branchIds||[]).map(Number).filter(function(x){return Number.isInteger(x)&&x>0;});
 moriEnsure_(role==='ADMIN'||branches.length>0,'Tài khoản chưa được cấp chi nhánh');
 return {email:String(acl.email||'').toLowerCase(),role:role,branchIds:branches,name:acl.name||acl.email};
}
function moriActor_(token){moriEnsure_(typeof token==='string'&&token.length>40,'Chưa đăng nhập');var raw=CacheService.getScriptCache().get(moriTokenKey_(token));moriEnsure_(!!raw,'Phiên đăng nhập đã hết hạn');
 var email=JSON.parse(raw).email,acl=moriFind_('AccessControl',email);moriEnsure_(acl&&acl.isActive!==false,'Quyền truy cập đã bị thu hồi');return moriUser_(acl);
}
function moriAuthWho(token){try{return {authenticated:true,user:moriActor_(token)};}catch(_){return {authenticated:false};}}
function moriAuthLogout(token){if(token)CacheService.getScriptCache().remove(moriTokenKey_(token));return {ok:true};}
function moriRequire_(actor,allowed,branchId){moriEnsure_(allowed.indexOf(actor.role)>=0,'Không đủ quyền thao tác');if(branchId!==undefined&&branchId!==null&&branchId!=='ALL'&&actor.role!=='ADMIN'){
  moriEnsure_(actor.branchIds.map(Number).indexOf(Number(branchId))>=0,'Không thuộc chi nhánh được phân quyền');
 }}
function moriScope_(actor,branchId){return actor.role==='ADMIN'?(branchId===undefined?'ALL':branchId):(actor.branchIds[0]||null);}
/** Attendance email challenge (different from the login OTP). */
function moriAttendanceOtpStart(token){var actor=moriActor_(token),cache=CacheService.getScriptCache(),key='mori:clock:'+actor.email;
 moriEnsure_(!cache.get(key+':cool'),'Xin chờ một phút trước khi lấy mã mới');
 var salt=Utilities.getUuid()+Utilities.getUuid(),digits=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,salt).slice(0,4).reduce(function(v,b){return v*256+(b<0?b+256:b);},0)%1000000,code=('000000'+digits).slice(-6),digest=Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,code+salt));
 cache.put(key,JSON.stringify({salt:salt,hash:digest,tries:0}),300);cache.put(key+':cool','1',60);
 MailApp.sendEmail({to:actor.email,subject:'Mori POS — Mã chấm công',body:'Mã chấm công: '+code+'\nHiệu lực 5 phút. Không chia sẻ mã này.'});return {ok:true};
}
function moriClockOtpVerify_(actor,code){var cache=CacheService.getScriptCache(),key='mori:clock:'+actor.email,raw=cache.get(key);moriEnsure_(raw,'Chưa yêu cầu mã chấm công hoặc mã đã hết hạn');var d=JSON.parse(raw);moriEnsure_(d.tries<3,'Quá số lần thử');var digest=Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(code||'')+d.salt));
 if(digest!==d.hash){d.tries++;cache.put(key,JSON.stringify(d),300);throw new Error('Mã chấm công không đúng');}cache.remove(key);return true;
}
