# MoriPOS v3.2.0 — Identity & CustomerDaily data architecture

## Internal authentication

`AccessControl` (POS_Master) owns `{email,role,branchIds,isActive}`. `Employees` contains staff profile/salary metadata. Staff OTP token cached with a separate namespace from customer OTP; every protected RPC re-reads AccessControl for revocation. Only Owner/Admin can add/suspend other staff; public customers cannot access internal RPCs.

## Customer identity

- `Customers` (POS_Customers) — Official Member profile: numeric Customer ID, name, phone, optional verified email, branchId, memberSince, status, marketing consent.
- `GuestIdentities` (POS_Customers) — verified email identity with stable SHA-256 email key; not equivalent to a Member.
- `CustomerIdentityLinks` (POS_Customers) — maps verified Guest identity to Official Member only after OTP proof; never merge solely on name/phone.
- `CustomerOrderLinks` (POS_Customers) — per-bill sanitized projection and ownership (guest identity or Member); no raw payment tokens, credential fields or card data.
- `CustomerDayIndex` (POS_Customers) — day/branch/bill index used by worker without rescanning raw Bills on dashboard requests.
- `CustomerDaily` (POS_Dashboard) — aggregated daily facts with dimensions `branchId`, `day`, `type=GUEST|MEMBER`, measures `orders`, `revenue`, `uniqueCustomers`, `newCustomers`, `returningCustomers`.

## Write and synchronization path

`Bills` write → `moriChanged_` → sharded ScriptProperties queue → `moriCustomerAnalyticsWorker_` (5 min) → CustomerOrderLinks + CustomerDayIndex → dirty day queue → CustomerDaily. Member upgrade invalidates affected identity days and worker reclassifies prior verified Guest orders; avoids double count. Daily query only reads CustomerDaily and validates staff role/branch.

## Semantics / restrictions

Email on unverified checkout is **unverified contact detail**, not evidence of account ownership. Claim legacy order requires both the email OTP session and the private order tracking token. Staff can create a Member without verified email but cannot claim verified identity in that case. Customer login token cannot be used as a staff token.

`CustomerDaily` excludes anonymous/unclaimed orders and should not be used as total revenue ledger. The all-sales `AnalyticsDaily` remains the financial denominator. `newCustomers` and `returningCustomers` are daily counts; adding across days does not yield unique customers across a period.

Maintenance/editor functions include `moriCustomerInstall()`, `moriCustomerSyncNow()`, `moriCustomerStatus()`, and `moriCustomerRepairStart()`.
