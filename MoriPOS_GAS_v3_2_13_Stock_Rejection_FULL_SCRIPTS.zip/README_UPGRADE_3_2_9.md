# MoriPOS 3.2.9 — Dropdown, lưu mặt hàng và giữ định lượng

## Cập nhật từ v3.2.8

Chỉ thay **Index.html** và **Code.gs** bằng hai file trong gói này.

1. Lưu bản sao hai file hiện tại của project Apps Script.
2. Thay toàn bộ nội dung `Index.html` và `Code.gs`, rồi lưu project.
3. Chạy `moriFrontendCheck()`; kết quả cần có build `3.2.9` và `exactFileMatch: true`.
4. Vào **Deploy → Manage deployments → Edit → New version → Deploy**.
5. Tải lại Web App để nhận bản mới.

Không chạy lại Setup hoặc Installer. Không đổi cấu trúc Google Sheets.
Các file `.gs` còn lại là bản đầy đủ đi kèm để đối chiếu; không cần thay khi nâng từ v3.2.8.

## Nội dung sửa

- Tất cả dòng định lượng, kể cả dòng vừa thêm, dùng dropdown Mori chung. Nguyên liệu luôn có ô tìm kiếm; danh sách đơn vị giữ cách chọn ngắn gọn.
- Mỗi dropdown có mã riêng, không trùng sau nhiều lần thêm/xóa hoặc cập nhật giao diện. Nhãn đơn vị cập nhật đúng khi đổi nguyên liệu.
- Căn đều chiều cao và vị trí các ô; phần nguyên liệu xuống một hàng riêng trên màn hình hẹp.
- Chỉ hiển thị loading tại nút đang thực hiện. Bỏ loading nổi ở góc dưới và thông báo chờ lưu trùng. Giữ khóa chống nhấn lặp, thông báo thành công và thông báo lỗi.
- Lưu mặt hàng và đổi trạng thái áp dụng ngay bản ghi server vừa xác nhận, bao gồm phiên bản và toàn bộ định lượng. Bỏ lượt gọi bổ sung để tải lại toàn bộ Items/Audit; nhật ký vẫn được server ghi và được đọc khi mở trang Nhật ký.
- Giữ nguyên form đang nhập khi một cập nhật nền vẽ lại trang. Form định lượng bị thiếu không bị hiểu thành yêu cầu xóa hết công thức.
- Kiểm tra vòng tạo/lưu/mở lại cho cả **Sản phẩm** và **Dịch vụ** có định lượng, không yêu cầu đổi loại sang Combo.

Phần tính giá combo, quy đổi đơn vị, hao hụt, công thức Forecast và các quy tắc nghiệp vụ server giữ nguyên. Bản này không thêm cột lời/lỗ hoặc drilldown Forecast.

## Kiểm tra nhanh trên Web App

1. Tạo Sản phẩm, thêm ít nhất ba thành phần, đổi g/kg hoặc ml/l và nhập hao hụt. Mở tìm kiếm ở dòng đầu, dòng thứ hai và dòng thêm mới.
2. Xóa một dòng giữa rồi thêm dòng khác; chọn nguyên liệu và đơn vị để kiểm tra đúng dòng.
3. Lưu: chỉ nút Lưu có loading. Mở lại và tải lại trang: các thành phần, lượng, đơn vị và hao hụt còn đầy đủ.
4. Lặp lại với loại Dịch vụ. Thử một lỗi xác thực khi lưu để kiểm tra form không bị xóa.

Định lượng đã bị ghi rỗng trong dữ liệu trước bản sửa cần được nhập lại hoặc phục hồi từ bản sao. Bản sửa không suy đoán công thức cũ.

## Xác minh

Xem `TEST_REPORT_3_2_9.md`. Kiểm tra tự động chạy bằng Node và mô phỏng DOM/Apps Script/Sheets; chưa triển khai hoặc đo thời gian trên Google Apps Script thật.
