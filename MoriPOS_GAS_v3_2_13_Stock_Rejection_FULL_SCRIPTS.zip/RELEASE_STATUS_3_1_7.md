# Release 3.1.7 — Forecast UI Cleanup
- Base: 3.1.6 POS_Dashboard release.
- Production code files changed: Index.html, Code.gs only.
- All business logic (Forecast.gs, ForecastCore.gs, Analytics.gs, etc.) unchanged.
- No database or data migration required.
- Targeted checks: forecast-ui-cleanup.test.js.
- Complete verification results: see TEST_REPORT_3_1_7.md.
- Source integrity: Index.html SHA256 equals Code.gs MORI_FRONTEND_SHA256.
