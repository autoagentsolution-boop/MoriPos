/** MoriPOS v3.2.4 — safe source/installation check, no writes. */
function moriPreflight324(){
 var checks={
  moriHolidayConfig:typeof moriHolidayConfig_==='function',
  moriHolidayApplies:typeof moriHolidayApplies_==='function',
  moriItemPrice:typeof moriItemPrice_==='function',
  moriHolidaySettingsSave:typeof moriHolidaySettingsSave_==='function',
  moriCatalogStatus:typeof moriCatalogStatus_==='function',
  moriPublicBootstrap:typeof moriPublicBootstrap==='function',
  moriCreateOfflineBill:typeof moriCreateOfflineBill_==='function'
 };
 var missing=Object.keys(checks).filter(function(k){return !checks[k];}),frontend=moriFrontendCheck();
 return {ok:missing.length===0&&frontend.ok===true&&frontend.exactFileMatch===true,
   version:'3.2.4',checks:checks,missing:missing,frontend:frontend};
}
