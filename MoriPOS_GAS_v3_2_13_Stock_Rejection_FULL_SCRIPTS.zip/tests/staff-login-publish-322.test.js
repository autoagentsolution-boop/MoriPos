'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const html=read('Index.html'),code=read('Code.gs'),security=read('Security.gs');
assert.match(html,/staff-access-modal/);
assert.match(html,/function moriStaffModalHTML\(/);
assert.match(html,/if\(!m\)return moriStaffModalHTML\(\)/);
assert.match(html,/data-combo-toggle="staffBranches"/);
assert.match(html,/data-staff-cancel/);
assert.match(html,/staff-branch-trigger/);
assert.match(html,/<select id=\"staff-role\"/);
assert.match(html,/staff-status-toggle/);
assert.match(html,/staff-status-pill/);
assert.match(html,/function moriPublishLinkPanel/);
assert.match(html,/data-publish-link-action=\"copy\"/);
assert.match(html,/data-publish-link-action=\"open\"/);
assert.match(html,/data-publish-link-action=\"qr\"/);
assert.match(html,/moriPublishLinkPanel\('order'\)/);
assert.match(html,/moriPublishLinkPanel\('booking'\)/);
assert.match(html,/moriAuthStart/);
assert.match(html,/Mã xác thực đã gửi đến email/);
console.log('PASS: staff editor is a modal with compact branch/status controls, no inline fixed form');
console.log('PASS: public URL block offers copy/open/QR actions for order and booking');
const byEmail={'owner@company.test':{id:'owner@company.test',email:'owner@company.test',isActive:true,role:'ADMIN',branchIds:[1]},'disabled@company.test':{id:'disabled@company.test',email:'disabled@company.test',isActive:false,role:'EMPLOYEE',branchIds:[1]}};
const messages=[],cache=new Map();const digest=x=>[...crypto.createHash('sha256').update(x).digest()].map(v=>v>127?v-256:v);
const c={console,JSON,Date,Math,Set,Map,
 Utilities:{DigestAlgorithm:{SHA_256:'sha256'},Charset:{UTF_8:'utf8'},computeDigest:(alg,v)=>digest(v),getUuid:()=>crypto.randomUUID(),base64EncodeWebSafe:x=>Buffer.from(x.map(b=>(b+256)%256)).toString('base64url')},
 CacheService:{getScriptCache:()=>({get:k=>cache.get(k)||null,put:(k,v)=>cache.set(k,v),remove:k=>cache.delete(k)})},
 MailApp:{sendEmail:x=>messages.push(x)},
 ScriptApp:{getService:()=>({getUrl:()=> 'https://script.google.com/macros/s/AKfy_test123/exec'})},
 moriProp_:()=> '1',moriFind_:(table,id)=>table==='AccessControl'?byEmail[id]:table==='PublishSite'?{published:true}:table==='Settings'?{modules:{publishSite:true}}:null,
 moriEnsure_:(yes,msg)=>{if(!yes)throw Error(msg);},moriRequire_:(actor,roles)=>{if(!roles.includes(actor.role))throw Error('Không đủ quyền thao tác');},moriActor_:(token)=>token==='owner-token'?{role:'ADMIN',email:'owner@company.test'}:{role:'EMPLOYEE',email:'disabled@company.test'}};
vm.createContext(c);vm.runInContext(security,c);vm.runInContext(code,c);c.moriActor_=(token)=>token==='owner-token'?{role:'ADMIN',email:'owner@company.test'}:{role:'EMPLOYEE',email:'disabled@company.test'};
assert.throws(()=>c.moriAuthStart('unknown@company.test'),/chưa được cấp quyền/);
assert.throws(()=>c.moriAuthStart('disabled@company.test'),/tạm khóa/);
assert.equal(messages.length,0);
const r=c.moriAuthStart('owner@company.test');assert(r.ok);assert.equal(messages.length,1);
assert.equal(messages[0].to,'owner@company.test');
assert.throws(()=>c.moriAuthStart('owner@company.test'),/chờ trước khi gửi mã/);
console.log('PASS: unauthorized/disabled staff never receives OTP; allowed staff receives one');
const links=c.moriPublishLinks('owner-token');
assert.equal(links.publicUrl,'https://script.google.com/macros/s/AKfy_test123/exec?view=shop');
assert.equal(links.bookingUrl,'https://script.google.com/macros/s/AKfy_test123/exec?view=shop&tab=booking');
assert(links.published);assert.throws(()=>c.moriPublishLinks('staff-token'),/Không đủ quyền/);
console.log('PASS: admin-only API returns genuine /exec public and booking URLs, without staff token');
c.ScriptApp={getService:()=>({getUrl:()=> 'https://script.google.com/macros/s/AKfy_test123/dev'})};
assert.equal(c.moriPublishLinks('owner-token').publicUrl,'');
console.log('PASS: /dev preview is never misrepresented as customer share link');
const sha=crypto.createHash('sha256').update(html).digest('hex');
assert(code.includes(sha));assert(html.includes('MORI_FRONTEND_BUILD:3.2.13'));
console.log('PASS: version markers and SHA-256 match updated Index');
