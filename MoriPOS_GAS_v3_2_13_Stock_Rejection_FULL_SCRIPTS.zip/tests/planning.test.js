'use strict';
// Test real server functions with in-memory Sheets. No live data or real latency claim.
const assert=require('assert');const {fixture,cp}=require('./storage.fixture');
const done=s=>console.log('PASS:',s),near=(x,y)=>assert(Math.abs(x-y)<1e-6,`${x} != ${y}`);
const options={bills:0,items:0,clock:'2026-11-05T05:00:00.000Z'};
function shop(){
 const f=fixture(undefined,options);
 f.add('Items',{id:1,name:'Thịt bò',type:'MATERIAL',price:0,baseUnit:'g',cost:100,stockByBranch:{1:0},track:true});
 f.add('Items',{id:2,name:'Rau',type:'MATERIAL',price:0,baseUnit:'kg',cost:20000,stockByBranch:{1:1},track:true});
 f.add('Items',{id:3,name:'Combo A',type:'COMBO',baseUnit:'phần',price:50000,processingCost:1000,components:[{itemId:1,qty:200,unit:'g'},{itemId:2,qty:100,unit:'g'}]});
 f.add('Items',{id:4,name:'Combo B',type:'COMBO',baseUnit:'phần',price:40000,components:[{itemId:1,qty:100,unit:'g'},{itemId:2,qty:.2,unit:'kg'}]});
 f.add('AccessControl',{id:'manager@example.test',email:'manager@example.test',role:'MANAGER',branchIds:[1],isActive:true});
 return f;
}
let f=shop(),token=f.session(),ctx=f.context();
const receipt=f.request('moriApi',token,'stock.create',{branchId:1,shipping:'Nhập bò',lines:[{id:1,qty:1,unit:'kg',factor:1,cost:100000}]});
assert.equal(receipt.lines[0].baseQty,1000);assert.equal(receipt.lines[0].unitCostBase,100);
f.request('moriApi',token,'stock.confirm',{id:receipt.id});f.request('moriApi',token,'stock.confirm',{id:receipt.id});
assert.equal(f.get('Items',1).stockByBranch[1],1000);assert.equal(f.get('Items',1).costByBranch[1],100);
assert.throws(()=>f.request('moriApi',token,'stock.create',{branchId:1,shipping:'Invalid',lines:[{id:1,qty:1,unit:'l',factor:1000,cost:1}]}),/Không thể đổi/);
done('1 kg receipt becomes 1,000 g; server derives factor, weighted cost and once-only confirmation');
ctx=f.context();const index=ctx.moriItemIndex_();
near(ctx.moriRecipe_(3,index,1,1).cost,23000);near(ctx.moriRecipe_(3,index,1,1).needs[2],.1);
assert.equal(ctx.moriUnitFactor_(index[1],'gam'),1);near(ctx.moriUnitFactor_(index[2],'mg'),.000001);
index[5]={id:5,name:'Dịch vụ dùng vật tư',type:'SERVICE',components:[{itemId:3,qty:2,unit:'phần',wastePercent:10}],processingCost:2000};
const nested=ctx.moriRecipe_(5,index,1,1);near(nested.cost,52600);near(nested.needs[1],440);near(nested.needs[2],.22);
index[3].components.push({itemId:5,qty:1});assert.throws(()=>ctx.moriRecipe_(5,index,1,1),/lặp/);
done('recipes support g/kg/mg, nested combo/service, multiple ingredients and waste without changing stock units');
const payload={branchId:1,clientRequestId:'recipe-payment-01',items:[{id:3,qty:2,unitPrice:50000},{id:4,qty:1,unitPrice:40000}],method:'CASH',resource:'Bàn 2'};
const paid=f.request('moriCheckout',token,payload).bill;
assert.equal(paid.items[0].cost,23000);assert.equal(paid.items[1].cost,14000);assert.equal(paid.resource,'Bàn 2');
near(f.get('Items',1).stockByBranch[1],500);near(f.get('Items',2).stockByBranch[1],.6);
f.request('moriCheckout',token,payload);near(f.get('Items',1).stockByBranch[1],500);
assert.throws(()=>f.request('moriCheckout',token,{...payload,clientRequestId:'oversell-recipe-01',items:[{id:3,qty:3,unitPrice:50000}]}),/Không đủ tồn/);
f.edit('Items',1,d=>{d.costByBranch={1:200};});assert.equal(f.get('Bills',paid.id).items[0].cost,23000);
done('checkout deducts shared ingredients exactly once, snapshots BOM cost and blocks overselling');
const unitFixture=shop(),unitToken=unitFixture.session(),unitBefore=unitFixture.get('Items',1);
const corrected=unitFixture.request('moriApi',unitToken,'catalog.save',{...unitBefore,baseUnit:'kg'});
assert.equal(corrected.baseUnit,'kg');assert.deepEqual(corrected.stockByBranch,unitBefore.stockByBranch);assert.equal(corrected.cost,unitBefore.cost);
assert.throws(()=>f.request('moriApi',token,'catalog.save',{name:'Combo trống',type:'COMBO',price:10000,cost:0,components:[]}),/ít nhất/);
assert.throws(()=>f.request('moriApi',token,'catalog.save',{...f.get('Items',3),components:[{itemId:3,qty:1,unit:'phần'}]}),/Thành phần/);
const updated=f.request('moriApi',token,'catalog.save',{...f.get('Items',3),components:[{itemId:1,qty:.2,unit:'kg',wastePercent:5}]});
near(f.context().moriRecipe_(3,f.context().moriItemIndex_(),1,1).cost,43000);assert.equal(updated.components[0].unit,'kg');
done('catalog validates recipes/cycles; metadata unit correction keeps numeric stock and prices unchanged');

function plan({mode='FIXED',value=1000000,quantity=100,price=50000,fixedCosts=100000,extraCost=1000}={}){
 return {name:'Kế hoạch kiểm thử',branchId:1,startDate:'2026-11-05',endDate:'2026-11-11',clientRequestId:'planning-request-01',fixedCosts,lookbackDays:28,goal:{mode,value,baselineMode:'PREVIOUS',baselineProfit:0},items:[{itemId:3,extraCost}],scenarios:[1,2,3].map((n)=>({name:['Thận trọng','Cơ sở','Tăng trưởng'][n-1],lines:[{itemId:3,quantity,price}]}))};
}
f=shop();ctx=f.context();const snap={periodDays:7,elapsedDays:0,remainingDays:7,lookbackDays:28,items:[1,2,3,4].map(id=>f.get('Items',id)),byItem:{},available:{1:1000000,2:10000}};
let p=plan(),r=ctx.moriForecastCalculate_(p,snap),s=r.scenarios[0];
assert.equal(s.revenue,5000000);assert.equal(s.cost,2500000);assert.equal(s.profit,2500000);assert.equal(s.met,true);assert(r.warnings.some(x=>x.includes('Chưa có doanh số')));
p=plan({quantity:10,price:30000,fixedCosts:0,extraCost:0,value:100000});s=ctx.moriForecastCalculate_(p,snap).scenarios[0];
assert.equal(s.profit,70000);assert.equal(s.extraChoice.quantity,5);assert.equal(s.lines[0].suggestedPrice,33000);
p=plan({mode:'MARKUP',value:20,quantity:1,price:24000,fixedCosts:0,extraCost:0});s=ctx.moriForecastCalculate_(p,snap).scenarios[0];
assert.equal(s.targetProfit,4600);assert.equal(s.additionalRevenue,3600);assert.equal(s.lines[0].suggestedPrice,27600);
p.goal.mode='MARGIN';s=ctx.moriForecastCalculate_(p,snap).scenarios[0];assert.equal(s.targetProfit,4800);assert.equal(s.additionalRevenue,4750);assert.equal(s.lines[0].suggestedPrice,28800);
done('three scenarios calculate fixed profit, markup vs margin, minimum price and additional units');
p=plan({mode:'GROWTH',value:20});r=ctx.moriForecastCalculate_(p,snap);assert.equal(r.recommendedId,null);assert.equal(r.scenarios[0].goalValid,false);
p.goal.baselineMode='MANUAL';p.goal.baselineProfit=1000000;r=ctx.moriForecastCalculate_(p,snap);assert.equal(r.scenarios[0].targetProfit,1200000);
p.goal.baselineMode='PREVIOUS';const historical=cp(snap);historical.byItem[3]={previousRevenue:3000000,previousCost:1500000,previousQty:100};r=ctx.moriForecastCalculate_(p,historical);assert.equal(r.previous.profit,1300000);assert.equal(r.scenarios[0].targetProfit,1560000);
assert.throws(()=>ctx.moriForecastCalculate_({...p,scenarios:p.scenarios.slice(0,2)},snap),/3 kịch bản/);
assert.throws(()=>ctx.moriForecastCalculate_({...p,goal:{mode:'MARGIN',value:100}},snap),/không hợp lệ/);
done('growth uses a positive explicit or previous baseline; rejects invalid goals and scenario sets');
p=plan({quantity:1,price:999000,fixedCosts:70000});const actualSnap={...snap,elapsedDays:3.5,remainingDays:3.5,byItem:{3:{currentQty:2,currentRevenue:90000,currentCost:40000,referenceQty:28}}};
r=ctx.moriForecastCalculate_(p,actualSnap);assert.equal(r.actual.profit,13000);s=r.scenarios[0];assert.equal(s.quantity,2);assert.equal(s.revenue,90000);assert.equal(s.cost,112000);assert(s.lines[0].overPlan);
p.scenarios.forEach(x=>x.lines[0].quantity=100);r=ctx.moriForecastCalculate_(p,{...actualSnap,elapsedDays:7,remainingDays:0});s=r.scenarios[0];assert.equal(s.quantity,2);assert.equal(s.remainingQuantity,0);assert.equal(s.profit,-22000);assert.equal(s.extraChoice,null);assert.equal(r.recommendedId,null);
done('actual prices/costs stay intact; over-plan sales and ended periods never invent remaining sales');
p=plan({quantity:3,price:50000,fixedCosts:0});p.items.push({itemId:4,extraCost:0});p.scenarios.forEach(x=>x.lines.push({itemId:4,quantity:3,price:40000}));
r=ctx.moriForecastCalculate_(p,{...snap,available:{1:700,2:.5},byItem:{3:{referenceQty:2},4:{referenceQty:1}}});s=r.scenarios[0];assert.equal(s.materials.find(x=>x.itemId===1).needed,900);assert.equal(s.materials.find(x=>x.itemId===1).shortage,200);near(s.materials.find(x=>x.itemId===2).shortage,.4);near(s.purchaseCost,28000);assert(!s.canProduce);assert.equal(r.recommendedId,null);
done('shared ingredient requirements are combined across products; demand and stock constrain suggestions');

// Deterministic UTC+7 boundaries, discounts, tips, old cost snapshots and scope.
f=shop();token=f.session();f.edit('Items',1,d=>d.stockByBranch[1]=1000);
function sold(id,date,lines,rest={}){f.add('Bills',{id,branchId:1,channel:'OFFLINE',status:'PAID',paidAt:date,items:lines,...rest});}
sold(1,'2026-11-04T18:00:00Z',[{id:3,qty:2,unitPrice:50000,cost:20000}],{discountTotal:10000,tipAmount:5000,finalTotal:95000});
sold(2,'2026-11-04T16:59:00Z',[{id:3,qty:1,unitPrice:50000,cost:19000}],{discountTotal:0,finalTotal:50000});
sold(3,'2026-11-05T03:00:00Z',[{id:4,qty:1,unitPrice:40000}],{finalTotal:0});
sold(4,'2026-11-05T03:00:00Z',[{id:3,qty:50,unitPrice:50000,cost:20000}],{branchId:2});
sold(5,'2026-11-05T03:00:00Z',[{id:3,qty:50,unitPrice:50000,cost:20000}],{status:'OPEN'});
f.add('Bills',{id:10,branchId:1,channel:'ONLINE',status:'OPEN',orderStatus:'CONFIRMED',inventoryNeeds:{1:100,2:.1}});
const q={branchId:1,startDate:'2026-11-05',endDate:'2026-11-11',lookbackDays:28};
f.request('moriAnalyticsInstall');f.request('moriAnalyticsSyncNow');
let data=f.request('moriForecastLoad',token,q);
assert.equal(data.byItem[3].currentQty,2);assert.equal(data.byItem[3].currentRevenue,90000);assert.equal(data.byItem[3].currentCost,40000);assert.equal(data.byItem[3].referenceQty,1);assert.equal(data.byItem[3].previousRevenue,50000);assert.equal(data.byItem[4].currentRevenue,0);assert.equal(data.byItem[4].estimatedCostLines,1);assert.equal(data.available[1],900);assert.equal(data.elapsedDays,.5);assert.equal(data.remainingDays,6.5);assert(!data.items.some(x=>x.appliedOps||x.stockByBranch));
assert.equal(data.coverage.archivesIncluded,true);
done('sales snapshot uses Vietnam dates, allocated discounts, no tips, historical costs and reserved stock');

// Breakdown: precise partial-month accrual, separate confirmed stock purchase cash spending, no double-COGS.
f.edit('Stores',1,x=>{x.monthlyRent=3000000;x.monthlyOtherCost=600000;});
f.edit('Branches',1,x=>{x.monthlyRent=1500000;x.monthlyOtherCost=300000;});
f.add('StockIn',{id:121,branchId:1,status:'CONFIRMED',confirmedAt:'2026-11-06T04:00:00Z',totalCost:100000});
f.add('StockIn',{id:122,branchId:1,status:'SUBMITTED',date:'2026-11-06T04:00:00Z',totalCost:400000});
f.request('moriAnalyticsRebuildHistory');f.request('moriAnalyticsSyncNow');
data=f.request('moriForecastLoad',token,{...q,forceRefresh:true});
assert.equal(data.costSummary.storeRent,350000); // 7/30 of store rent allocated across two branches
assert.equal(data.costSummary.storeOther,70000);
assert.equal(data.costSummary.branchRent,350000);
assert.equal(data.costSummary.branchOther,70000);
assert.equal(data.costSummary.salaries,28806); // employee salary 123456 * 7/30 rounded
assert.equal(data.costSummary.stockPurchases,100000);
assert.equal(data.costSummary.operatingFixedTotal,868806);
assert.equal(data.costSummary.totalCashOut,968806);
const auto={...plan({quantity:1,price:50000,extraCost:0}),fixedCostMode:'AUTO',extraFixedCosts:10000,fixedCosts:0,clientRequestId:'auto-cost-planning-001'};
const savedAuto=f.request('moriForecastSave',token,auto);
assert.equal(savedAuto.fixedCosts,878806); // no purchase cost added to profit expenses
assert.equal(savedAuto.extraFixedCosts,10000);
assert.equal(savedAuto.fixedCostMode,'AUTO');
const pureCost=f.context().moriForecastCalculate_(savedAuto,{periodDays:7,elapsedDays:0,remainingDays:7,lookbackDays:28,items:[1,2,3,4].map(id=>f.get('Items',id)),byItem:{},available:{1:1e5,2:1e5}}).scenarios[0];
assert.equal(pureCost.cost,23000+878806);
done('auto costs prorate across 7 November days, allocate store overhead, include salaries, and display stock purchase cash separately without double COGS');

// Install does not modify existing entities, and is repeatable.
delete f.db.ForecastPlans;const beforeItems=cp(f.db.Items);data=f.request('moriForecastLoad',token,{...q,forceRefresh:true});assert(!data.installed);
const installed=f.request('moriForecastInstall',token);assert(installed.installed);assert.deepEqual(f.db.Items,beforeItems);assert.equal(f.db.ForecastPlans.length,1);const auditCount=f.db.Audit.length;f.request('moriForecastInstall',token);assert.equal(f.db.ForecastPlans.length,1);assert.equal(f.db.Audit.length,auditCount);
p=plan();const saved=f.request('moriForecastSave',token,p);assert.equal(f.request('moriForecastSave',token,p).id,saved.id);assert.equal(f.db.ForecastPlans.length,2);
const loaded=f.request('moriForecastGet',token,saved.id);assert.equal(loaded.scenarios.length,3);assert.equal(loaded.name,p.name);const saved2=f.request('moriForecastSave',token,{...loaded,name:'Updated'});assert.equal(saved2.version,2);
assert.throws(()=>f.request('moriForecastSave',token,loaded),/VERSION_CONFLICT/);
assert.throws(()=>f.request('moriForecastSave',token,{...saved2,branchId:2}),/Không chuyển/);
const defaults=f.request('moriForecastSaveDefaults',token,{...p,version:installed.defaults.version});assert.equal(defaults.defaults.version,2);assert.throws(()=>f.request('moriForecastSaveDefaults',token,{...p,version:1}),/VERSION_CONFLICT/);
done('idempotent install/save, persistent plans and optimistic versions preserve existing data');
const manager=f.session('manager@example.test'),staff=f.session('staff@example.test');
assert(f.request('moriForecastLoad',manager,q).ok);assert.throws(()=>f.request('moriForecastLoad',manager,{...q,branchId:2}),/chi nhánh/);
assert.throws(()=>f.request('moriForecastLoad',staff,q),/quyền/);assert.throws(()=>f.request('moriForecastGet',staff,saved.id),/quyền/);assert.throws(()=>f.request('moriForecastInstall',manager),/quyền/);assert.throws(()=>f.request('moriForecastSaveDefaults',manager,{...p,version:2}),/quyền/);
f.edit('Settings','global',x=>x.modules.forecast=false);assert.throws(()=>f.request('moriForecastLoad',token,q),/đang tắt/);
done('forecast is restricted to Admin/Manager and authorized branches; module off is enforced server-side');
f.resetCounts();f.request('moriSessionBootstrap',token);assert(!f.events.some(e=>e.type==='read'&&['ForecastPlans','Bills','Audit'].includes(e.table)));
done('new forecast tables and history are never loaded by core login');
console.log('ALL PLANNING TESTS PASSED (simulated Sheets, no production deployment).');
