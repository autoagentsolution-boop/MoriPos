'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {fixture,cp}=require('./storage.fixture');
const {harness,served,read}=require('./startup.test');
const done=s=>console.log('PASS:',s);
const root=path.resolve(__dirname,'..');
const counters={};
const request={branchId:1,shipping:'Nhận đủ hàng',lines:[{id:1,qty:2,unit:'cái',factor:1,cost:5000}],photoIds:[]};
let f=fixture(root,{items:20,bills:4000}),token=f.session();
const submitted=f.request('moriApi',token,'stock.create',request);f.resetCounts();const compact=f.request('moriApi',token,'stock.confirm',{id:submitted.id},true);counters.stockCompact=cp(f.counter);
assert(compact.ok);assert.equal(compact.result.status,'CONFIRMED');assert.equal(compact.changes.Items.length,1);assert.equal(compact.changes.StockIn.length,1);assert(compact.changes.AuditUpdates.length);assert.equal(f.counter.rpc,1);assert(compact.timing.serverMs>=0);assert.equal(f.events.at(-1).type,'unlock');assert.equal(f.get('Items',1).stockByBranch['1'],10002);
assert(!f.events.some(e=>e.type==='read'&&e.table==='StockIn'&&e.rows>1));
done('compact save returns confirmed stock receipt, changed inventory and audit in one RPC, after flush/unlock');
const retryReceipt=f.request('moriApi',token,'stock.confirm',{id:submitted.id},true);assert.equal(retryReceipt.changes.StockIn[0].status,'CONFIRMED');assert.equal(retryReceipt.changes.Items[0].stockByBranch['1'],10002);assert.equal(f.get('Items',1).stockByBranch['1'],10002);
const partial=f.request('moriApi',token,'stock.create',{...request,lines:[1,3,5].map(id=>({id,qty:2,unit:'cái',factor:1,cost:5000}))});f.setWriteFailure(e=>e.table==='Items'&&e.row===4);assert.throws(()=>f.request('moriApi',token,'stock.confirm',{id:partial.id},true),/injected write failure/);
const resumed=f.request('moriApi',token,'stock.confirm',{id:partial.id},true);assert.equal(resumed.changes.Items.length,3);assert.equal(f.get('Items',1).stockByBranch['1'],10004);assert.equal(f.get('Items',3).stockByBranch['1'],10002);assert.equal(f.get('Items',5).stockByBranch['1'],10002);
done('idempotent and partially completed receipt retries return all affected stock without applying it twice');

const raw=f.request('moriApi',token,'catalog.status',{id:1,version:f.get('Items',1).version,isActive:false});assert.equal(raw.isActive,false);assert.equal(raw.result,undefined);
assert.throws(()=>f.request('moriApi',token,'catalog.status',{id:1,version:0,isActive:true},true),/VERSION_CONFLICT/);
done('legacy API contract and optimistic version conflict checks remain intact');
const staff=f.session('staff@example.test');const sub=f.request('moriApi',staff,'stock.create',{...request,photoIds:['test-proof']},true);
assert.equal(sub.result.status,'SUBMITTED');assert.equal(sub.result.lines[0].cost,undefined);assert.equal(sub.changes.StockIn[0].lines[0].cost,undefined);assert.equal(sub.changes.AuditUpdates,undefined);assert.equal(sub.changes.AccessControl,undefined);
assert.throws(()=>f.request('moriApi',staff,'catalog.status',{id:1,version:3,isActive:true},true),/Không đủ quyền/);
done('compact results preserve employee projections and do not expose ACL, costs or Admin audit');
f=fixture(root,{items:5,bills:0});token=f.session();f.request('moriSessionBootstrap',token);
const oldRevision=f.cache.get('mori:revision:3211:Items'),oldKey='mori:data:3211:Items:'+oldRevision,oldJson=f.cache.get(oldKey);
assert(oldJson);f.request('moriApi',token,'catalog.status',{id:1,version:1,isActive:false},true);
const newRevision=f.cache.get('mori:revision:3211:Items');assert.notEqual(oldRevision,newRevision);
// Simulate a reader that began before the write completing its cache.put late.
f.cache.set(oldKey,oldJson);assert.equal(f.request('moriSessionBootstrap',token).data.items.find(x=>x.id===1).isActive,false);
f.cache.delete('mori:revision:3211:Items');f.request('moriSessionBootstrap',token);assert.notEqual(f.cache.get('mori:revision:3211:Items'),oldRevision);
const c=f.context(),first=c.moriAll_('Items',true);first[0].name='Mutated clone';assert.notEqual(c.moriAll_('Items',true)[0].name,'Mutated clone');
f.edit('Items',1,x=>x.price=12000);assert.equal(c.moriAll_('Items',false)[0].price,12000);
assert.equal(f.request('moriDelta',token,['Items'],{fresh:true}).Items[0].price,12000);
done('late cache refill/eviction cannot restore an old generation; cached reads are isolated and fresh reads bypass it');
const locked=f.context();assert.equal(locked.moriLock_(()=>locked.moriAll_('Items',true)[0].price),12000);
done('writes ignore shared cache even when an internal caller requests cached data');
f=fixture(root,{items:2,bills:4000});const track='a'.repeat(70);f.edit('Bills',1,x=>x.trackingToken=track);f.resetCounts();assert.equal(f.request('moriPublicTrack',track,'ORDER').id,1);assert.equal(f.counter.rowsRead,1);
assert(!f.request('moriPublicTrack','b'.repeat(70),'ORDER').found);
done('tracking lookup finds records beyond the old 3,000-row window and decodes only the matching row');
token=f.session();f.resetCounts();const booking=f.request('moriApi',token,'booking.create',{branchId:1,name:'Guest',startAt:new Date(Date.now()+86400000).toISOString(),guestCount:1},true);assert(booking.ok);assert(!f.events.some(e=>e.type==='read'&&e.table==='Booking'));counters.bookingNoResource=cp(f.counter);
done('booking without a table/chair skips the unnecessary complete Booking read');
if(process.env.MORI_3210_BASELINE_DIR){const b=fixture(process.env.MORI_3210_BASELINE_DIR,{items:20,bills:4000}),t=b.session();const initial=b.request('moriApi',t,'stock.create',request);b.resetCounts();b.request('moriApi',t,'stock.confirm',{id:initial.id});b.request('moriDelta',t,['StockIn','Items','Audit']);counters.stockBefore=cp(b.counter);assert(counters.stockCompact.rpc<counters.stockBefore.rpc);assert(counters.stockCompact.rowsRead<counters.stockBefore.rowsRead);}

// Batched receipt writes preserve weighted cost and duplicate-item line semantics.
const batch=fixture(root,{items:20,bills:0}),batchToken=batch.session(),batchRequest={...request,lines:Array.from({length:20},(_,i)=>({id:i+1,qty:2,unit:'cái',factor:1,cost:5000}))};
const batchReceipt=batch.request('moriApi',batchToken,'stock.create',batchRequest);batch.resetCounts();batch.request('moriApi',batchToken,'stock.confirm',{id:batchReceipt.id},true);counters.batch20After=cp(batch.counter);assert.equal(batch.events.filter(e=>e.type==='write'&&e.table==='Items').length,1);
const duplicate=batch.request('moriApi',batchToken,'stock.create',{...request,lines:[{id:1,qty:2,unit:'cái',factor:1,cost:5000},{id:1,qty:3,unit:'cái',factor:1,cost:8000}]});const oldItem=batch.get('Items',1);batch.request('moriApi',batchToken,'stock.confirm',{id:duplicate.id},true);const newItem=batch.get('Items',1);assert.equal(newItem.stockByBranch['1'],oldItem.stockByBranch['1']+5);assert(Math.abs(newItem.costByBranch['1']-(oldItem.stockByBranch['1']*oldItem.costByBranch['1']+2*5000+3*8000)/(oldItem.stockByBranch['1']+5))<1e-8);
if(process.env.MORI_3210_BASELINE_DIR){const b=fixture(process.env.MORI_3210_BASELINE_DIR,{items:20,bills:0}),t=b.session(),receipt=b.request('moriApi',t,'stock.create',batchRequest);b.resetCounts();b.request('moriApi',t,'stock.confirm',{id:receipt.id});counters.batch20Before=cp(b.counter);for(let id=1;id<=20;id++)if(id!==1){assert.deepEqual(batch.get('Items',id).stockByBranch,b.get('Items',id).stockByBranch);assert.deepEqual(batch.get('Items',id).costByBranch,b.get('Items',id).costByBranch);}assert.equal(counters.batch20Before.setValues,23);assert.equal(counters.batch20After.setValues,4);}
done('20 adjacent item updates use one batch; repeated item lines keep weighted cost, per-line retry markers and once-only stock');

// Archive destinations and delete failures are modeled independently from source storage.
function archiveHarness(count=600){
 const f=fixture(root,{items:2,bills:0});f.db.Booking=f.db.Booking.slice(0,1);
 for(let i=1;i<=count;i++)f.add('Booking',{id:i,status:'COMPLETED',branchId:1,createdAt:'2020-01-01T00:00:00.000Z',updatedAt:'2020-01-01T00:00:00.000Z'});
 const books={},stats={deleted:[],read:[]};let failDelete=0,corrupt=false;
 function destination(id){const data=books[id]||(books[id]=[]);return {getLastRow:()=>data.length,getRange(r,c,n,w){return {setValues(values){values.forEach((v,j)=>{data[r+j-1]??=Array(8).fill('');v.forEach((x,k)=>data[r+j-1][c+k-1]=x);});},getValues(){stats.read.push({id,r,n,w});const out=Array.from({length:n},(_,j)=>Array.from({length:w},(_,k)=>data[r+j-1]?.[c+k-1]??''));if(corrupt&&w===8&&r>1){corrupt=false;out[0][7]='{"wrong":"copy"}';}return out;}};}};}
 function context(){const c=f.context(),original=c.SpreadsheetApp.openById;c.SpreadsheetApp.openById=id=>{
  if(id.startsWith('archive-'))return {getId:()=>id,getSheets:()=>[destination(id)]};
  const book=original(id),get=book.getSheetByName;book.getSheetByName=name=>{const s=get(name);if(!s)return s;const del=s.deleteRows;s.deleteRows=(r,n)=>{stats.deleted.push({r,n});if(failDelete&&stats.deleted.length===failDelete)throw Error('injected delete failure');del(r,n);};return s;};return book;
 };c.SpreadsheetApp.create=name=>{const id='archive-'+name;return {getId:()=>id,getSheets:()=>[destination(id)]};};return c;}
 return {f,books,stats,context,failDelete(n){failDelete=n;},corruptNextVerify(){corrupt=true;}};
}
let a=archiveHarness(3000);for(let i=1;i<=2500;i++)a.f.edit('Booking',i,x=>x.status='PENDING');
a.f.resetCounts();let r=a.context().moriArchiveTable_('Booking',90,500);assert.equal(r.moved,0);assert.equal(r.scanned,2000);assert.equal(a.f.counter.rowsRead,2000);assert.equal(a.f.props.MORI_ARCHIVE_CURSOR_3211_Booking,'2002');
r=a.context().moriArchiveTable_('Booking',90,500);assert.equal(r.moved,500);assert.equal(r.scanned,1000);assert.equal(a.stats.deleted.length,1);assert.equal(a.f.db.Booking.length,2501);assert.equal(a.f.props.MORI_ARCHIVE_CURSOR_3211_Booking,'2');
done('archive scans at most 2,000 source rows, resumes beyond open records and deletes adjacent verified records in one batch');
a=archiveHarness(4);a.corruptNextVerify();assert.throws(()=>a.context().moriArchiveTable_('Booking',90,500),/verification failed/);assert.equal(a.stats.deleted.length,0);assert.equal(a.f.db.Booking.length,5);
assert.equal(a.context().moriArchiveTable_('Booking',90,500).moved,4);assert.equal(Object.values(a.books)[0].length,5);
done('archive refuses deletion when full copied content mismatches; retry reuses copies without duplicates');
a=archiveHarness(6);a.f.edit('Booking',3,x=>x.status='PENDING');a.failDelete(2);const ctx=a.context();assert.throws(()=>ctx.moriArchiveTable_('Booking',90,500),/delete failure/);assert.equal(a.f.props.MORI_ARCHIVE_CURSOR_3211_Booking,'2');assert.equal(ctx.MORI_DATA_STATE_.Booking,undefined);assert(!a.f.isLocked());
a.failDelete(0);assert.equal(a.context().moriArchiveTable_('Booking',90,500).moved,2);assert.equal(a.f.db.Booking.length,2);assert.equal(a.f.get('Booking',3).status,'PENDING');assert.equal(Object.values(a.books)[0].length,6);
done('partial delete failure resets row offsets and cursor; retry preserves open records and removes only verified copies');

const marker='\n})();\n/* MORI_FRONTEND_END:';
const testHTML=served(read('Index.html').replace(marker,'\nwindow.__io={state,render,refresh:moriRefreshLive,write:moriWrite,apply:moriApplyDelta,load:moriLoadHistory,login:moriShowLogin,get flights(){return moriRefreshFlights.size},get loaded(){return [...moriHistoryLoaded]}};'+marker)).html;
(async()=>{
 const db=fixture(root,{items:3,bills:0}),token=db.session(),core=db.request('moriSessionBootstrap',token).data;
 const pending=[];let reject=false;
 const h=harness(testHTML,{token:'signed',handlers:{moriSessionBootstrap:()=>({authenticated:true,data:core}),moriDelta:(_t,groups)=>new Promise(resolve=>pending.push({groups,resolve})),moriApi:(_t,action,payload,withChanges)=>reject?new Error('injected save error'):db.request('moriApi',token,action,payload,withChanges)}});await h.flush();const ui=h.ctx.__io;ui.state.page='items';
 const p1=ui.refresh(true,['Items','Booking']),p2=ui.refresh(true,['Booking','Items','Items']);assert.equal(p1,p2);assert.equal(pending.length,1);pending.shift().resolve({Items:[],Booking:[]});await p1;assert.equal(ui.flights,0);
 done('same in-flight refresh is shared even when requested groups arrive in a different order');
 const slow=ui.refresh(true,['Items']),fast=ui.refresh(true,['Items'],{fresh:true});const slower=pending.shift(),faster=pending.shift();faster.resolve({Items:[core.items[0]],Complete:['Items']});await fast;slower.resolve({Items:cp(core.items),Complete:['Items']});await slow;assert.equal(ui.state.items.length,1);
 done('newer complete snapshots win over overlapping out-of-order refresh responses');
 let list=cp(core.items);const oldRead=ui.refresh(true,['Items']);await h.flush();const saved=await ui.write('catalog.status',{id:1,version:1,isActive:false},null,true);assert.equal(saved.isActive,false);assert.equal(ui.state.items.find(x=>x.id===1).isActive,false);
 pending.shift().resolve({Items:list,Complete:['Items']});await oldRead;assert.equal(ui.state.items.find(x=>x.id===1).isActive,false);
 const recent=ui.refresh(true,['Items']);pending.shift().resolve({Items:[db.get('Items',1)],Complete:['Items']});await recent;assert.equal(ui.state.items.length,1);
 done('reads begun before saving cannot undo changes; a fresh full snapshot removes absent catalog records');
 const receipt=db.request('moriApi',token,'stock.create',request);const callStart=h.calls.length,stock=await ui.write('stock.confirm',{id:receipt.id},null,true);assert.equal(stock.status,'CONFIRMED');assert(ui.state.stockins.some(x=>x.id===stock.id));assert.equal(ui.state.items[0].stockByBranch['1'],10002);
 assert.equal(h.calls.slice(callStart).filter(x=>x.name==='moriApi').length,1);assert.equal(h.calls.slice(callStart).filter(x=>x.name==='moriDelta'||x.name==='moriBootstrap').length,0);
 done('stock confirmation applies the receipt and inventory from one mutation reply, with no post-save reload');
 const before=cp(ui.state.items);reject=true;assert.equal(await ui.write('catalog.status',{id:1,version:3,isActive:true}),null);assert.deepEqual(cp(ui.state.items),before);reject=false;
 const failed=ui.refresh(true,['Items']);pending.shift().resolve(new Error('read timeout'));await assert.rejects(failed,/read timeout/);assert.equal(ui.flights,0);const retry=ui.refresh(true,['Items']);pending.shift().resolve({Items:[db.get('Items',1)],Complete:['Items']});await retry;
 done('save/read failures retain confirmed data, clear in-flight state and allow a manual retry');
 for(const [id,value] of Object.entries({'payment-branch':'1','payment-bank':'Bank','payment-bank-code':'BANK','payment-account':'12345678','payment-holder':'QC STORE'})){const el=h.ctx.document.createElement('input');el.id=id;el.value=value;}
 ui.state.branchEditorId=1;const beforePayment=h.calls.length,button=h.ctx.document.createElement('button');button.dataset.action='save-payment';button.closest=sel=>sel==='[data-action]'?button:null;
 await h.emitDocument('click',button);await h.flush();const paymentCalls=h.calls.slice(beforePayment).filter(x=>x.name==='moriApi');assert.equal(paymentCalls.length,1);assert.equal(paymentCalls[0].args[1],'branch.save');assert.equal(ui.state.branches.find(x=>x.id===1).bankAccount,'12345678');assert.equal(db.get('Branches',1).bankAccount,'12345678');
 reject=true;h.elements.get('payment-account').value='87654321';await h.emitDocument('click',button);assert.equal(ui.state.branches.find(x=>x.id===1).bankAccount,'12345678');reject=false;
 done('payment settings issue one branch write and retain confirmed bank data if saving fails');
 const stale=ui.refresh(true,['Items']);ui.login();ui.state.items=[];pending.shift().resolve({Items:list,Complete:['Items']});await stale;assert.equal(ui.state.items.length,0);
 done('late refresh after logout cannot repopulate the previous user catalog');
 assert.equal(h.errors.length,0);console.log('MEASURED MOCK SERVICE COUNTS (not live elapsed time): '+JSON.stringify(counters));
 console.log('COMPLETE: I/O performance and failure regression checks passed.');
})().catch(e=>{console.error(e);process.exitCode=1;});
