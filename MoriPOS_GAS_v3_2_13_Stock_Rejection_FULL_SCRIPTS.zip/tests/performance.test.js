'use strict';
const assert=require('assert'),path=require('path');const {fixture,cp}=require('./storage.fixture');
const root=path.resolve(__dirname,'..');
const pay=(key='checkout-fixture-01',ids=[1,2,3,4,5],qty=1)=>({clientRequestId:key,branchId:1,items:ids.map(id=>({id,qty,unitPrice:10000})),method:'CASH'});
const done=name=>console.log('PASS:',name);
let f=fixture(),token=f.session();f.resetCounts();
const core=f.request('moriAuthVerify',...f.otp(),true);
assert(core.token&&core.data.historyDeferred);assert.equal(core.data.items.length,80);assert.equal(core.data.bills.length,0);assert.equal(f.counter.rpc,1);assert.equal(f.counter.openById,2);
assert(!f.events.some(e=>e.type==='read'&&['Bills','StockIn','Booking','Attendance','Audit'].includes(e.table)));
done('one OTP request loads checkout data from two spreadsheets, with no history reads');
const loginCold=cp(f.counter);f.resetCounts();const warm=f.request('moriSessionBootstrap',core.token);assert(warm.authenticated);assert.equal(f.counter.openById,1);assert.equal(f.counter.getValues,1);assert(f.events.filter(e=>e.type==='read').every(e=>e.table==='AccessControl'));const loginWarm=cp(f.counter);
done('warm login reads current ACL; cached catalogs never cache authorization');
f.edit('AccessControl','owner@example.test',d=>d.isActive=false);assert.equal(f.request('moriSessionBootstrap',core.token).authenticated,false);assert.throws(()=>f.request('moriCheckout',core.token,pay()),/thu hồi/);
f.edit('AccessControl','owner@example.test',d=>d.isActive=true);
assert.throws(()=>f.request('moriAuthVerify','owner@example.test','000000',true),/hết hạn/);
f.otp();assert.throws(()=>f.request('moriAuthVerify','owner@example.test','000000',true),/không đúng/);done('revocation takes effect immediately; incorrect/expired OTP cannot bootstrap');
f=fixture();token=f.session();f.resetCounts();const first=f.request('moriCheckout',token,pay());
assert.equal(first.bill.status,'PAID');assert.equal(first.bill.finalTotal,50000);assert.equal(first.changes.ItemUpdates.length,5);assert.equal(first.changes.AuditUpdates.length,1);
assert.equal(f.counter.rpc,1);assert.equal(f.counter.openById,4);assert.equal(f.events.filter(e=>e.type==='read'&&e.table==='Items').length,1);
assert.equal(f.events.filter(e=>e.type==='write'&&e.table==='Items').length,1);assert(f.counter.rowsRead<100);
assert.equal(f.events.at(-1).type,'unlock');assert.equal(f.events.at(-2).type,'flush');const checkout=cp(f.counter);
const n=f.db.Bills.length;const again=f.request('moriCheckout',token,pay());assert.equal(again.bill.id,first.bill.id);assert.equal(f.db.Bills.length,n);assert.equal(f.get('Items',1).stockByBranch['1'],9999);done('one payment RPC commits bill + inventory + audit, flushes before unlock, and retry is idempotent');
// Find a request outside the old 1,500-row window, including regex metacharacters.
f.edit('Bills',1,d=>d.clientRequestId='old-request-[x].+"\\-1');const old=f.request('moriCheckout',token,pay('old-request-[x].+"\\-1'));assert.equal(old.bill.id,1);assert.equal(f.db.Bills.length,n);done('idempotency works beyond 1,500 rows and treats regex/JSON characters literally');
// New UI ID must never accidentally select an unrelated saved draft.
f.add('Bills',{id:9000,branchId:1,channel:'OFFLINE',status:'OPEN',clientRequestId:'unrelated-draft-9000',items:[{id:1,qty:1,unitPrice:10000}]});
const temp=f.request('moriCheckout',token,{...pay('temporary-id-collision'),id:9000,version:7});assert.notEqual(temp.bill.id,9000);assert.equal(f.get('Bills',9000).status,'OPEN');done('temporary browser ID cannot overwrite an unrelated server draft');
// Existing OPEN draft uses server version, and stale versions are refused.
const draft=f.request('moriApi',token,'bill.draft',pay('server-draft-fixture'));
assert.throws(()=>f.request('moriCheckout',token,{...pay('server-draft-fixture'),id:draft.id,persisted:true,version:draft.version-1}),/VERSION_CONFLICT/);
const draftPaid=f.request('moriCheckout',token,{...pay('server-draft-fixture'),id:draft.id,persisted:true,version:draft.version});assert.equal(draftPaid.bill.id,draft.id);done('saved draft updates keep optimistic version checks');
// Sparse writes may partially fail. Retrying skips rows already deducted.
f=fixture();token=f.session();f.setWriteFailure(e=>e.table==='Items'&&e.row===4);
assert.throws(()=>f.request('moriCheckout',token,pay('partial-failure-fixture',[1,3,5])),/injected write/);
assert.equal(f.get('Items',1).stockByBranch['1'],9999);assert.equal(f.get('Items',3).stockByBranch['1'],10000);
assert.equal(f.get('Bills',3001).status,'COMMITTING');assert(!f.isLocked());
const resumed=f.request('moriCheckout',token,pay('partial-failure-fixture',[1,3,5]));assert.equal(resumed.bill.status,'PAID');for(const id of [1,3,5])assert.equal(f.get('Items',id).stockByBranch['1'],9999);for(const id of [2,4])assert.equal(f.get('Items',id).stockByBranch['1'],10000);done('retry after a partial multi-row write deducts exactly once and leaves unrelated rows intact');
// The branch check must happen BEFORE resuming a COMMITTING bill.
f=fixture();token=f.session('staff@example.test');f.add('Bills',{id:6000,channel:'OFFLINE',branchId:2,status:'COMMITTING',clientRequestId:'foreign-commit-fixture',inventoryNeeds:{1:2},items:[]});assert.throws(()=>f.request('moriCheckout',token,pay('foreign-commit-fixture')),/chi nhánh/);assert.equal(f.get('Items',1).stockByBranch['2'],50);done('a retry cannot resume another branch payment');
const own=f.request('moriCheckout',token,pay('employee-payment-fixture'));assert.equal(own.bill.items[0].cost,undefined);assert.equal(own.bill.inventoryNeeds,undefined);assert.equal(own.changes.ItemUpdates[0].cost,undefined);assert.equal(own.changes.ItemUpdates[0].appliedOps,undefined);assert.equal(own.changes.AuditUpdates.length,0);done('checkout response applies employee data projections');
// Reservation validation stays authoritative even if history has not loaded in UI.
f=fixture();token=f.session();f.edit('Items',1,d=>d.stockByBranch['1']=5);f.add('Bills',{id:6000,branchId:1,channel:'ONLINE',status:'OPEN',orderStatus:'CONFIRMED',inventoryNeeds:{1:4},items:[{id:1,qty:4}]});
assert.throws(()=>f.request('moriCheckout',token,pay('no-oversell-fixture',[1],2)),/Không đủ tồn/);assert.equal(f.get('Items',1).stockByBranch['1'],5);const one=f.request('moriCheckout',token,pay('one-left-fixture',[1],1));assert.equal(one.bill.status,'PAID');assert.throws(()=>f.request('moriCheckout',token,pay('two-cashiers-fixture',[1],1)),/Không đủ tồn/);done('online reservations and a second cashier cannot oversell stock');
f.edit('Bills',6000,d=>d.orderStatus='ALLOCATING');assert.throws(()=>f.request('moriCheckout',token,pay('allocating-order-fixture',[1],1)),/Không đủ tồn/);done('partially allocating online orders still reserve inventory');
f=fixture();token=f.session();f.setFlushFailure();assert.throws(()=>f.request('moriCheckout',token,pay()),/flush failure/);assert(!f.isLocked());assert.equal(f.request('moriCheckout',token,pay()).bill.status,'PAID');assert.equal(f.get('Items',1).stockByBranch['1'],9999);done('a flush failure cannot return success and lock is always released');
f=fixture();token=f.session();f.setBeforeLock(()=>f.edit('AccessControl','owner@example.test',d=>d.isActive=false));assert.throws(()=>f.request('moriCheckout',token,pay()),/thu hồi/);assert.equal(f.db.Bills.length,3001);done('permission is rechecked after lock acquisition');
f=fixture();token=f.session();f.request('moriSessionBootstrap',token);f.cache.clear();f.cache.set(f.context().moriTokenKey_(token),JSON.stringify({email:'owner@example.test'}));assert(f.request('moriSessionBootstrap',token).authenticated);done('cache eviction falls back to Sheets');
// Cost/stock reads during commit must ignore the shared catalog cache.
f=fixture();token=f.session();f.request('moriSessionBootstrap',token);f.edit('Items',1,d=>d.stockByBranch['1']=0);assert.throws(()=>f.request('moriCheckout',token,pay('fresh-stock-fixture',[1])),/Không đủ tồn/);done('stale UI catalog cache never authorizes stock consumption');
// Existing online and stock-entry flows also use the optimized storage layer.
f=fixture();token=f.session();
const order=f.request('moriApi',token,'online.create',{branchId:1,items:[{id:1,qty:3}],shipping:{name:'Guest A',phone:'0901234567',address:'12 Sample Street'},method:'COD'});
f.request('moriApi',token,'online.transition',{id:order.id,stage:'PREPARING'});f.request('moriApi',token,'online.transition',{id:order.id,stage:'SHIPPED'});
assert.equal(f.get('Items',1).stockByBranch['1'],9997);
f.request('moriApi',token,'online.transition',{id:order.id,stage:'DELIVERED'});const settled=f.request('moriApi',token,'online.payment',{id:order.id});assert.equal(settled.status,'PAID');
const receipt=f.request('moriApi',token,'stock.create',{branchId:1,shipping:'Test delivery',lines:[{id:1,qty:2,factor:10,cost:50000}],photoIds:[]});
f.request('moriApi',token,'stock.confirm',{id:receipt.id});f.request('moriApi',token,'stock.confirm',{id:receipt.id});assert.equal(f.get('Items',1).stockByBranch['1'],10017);
done('real storage helpers preserve online shipping/payment and once-only stock receipt confirmation');
const scoped=f.request('moriHistory',f.session('staff@example.test'));assert(scoped.bills.every(b=>b.branchId===1));assert(scoped.bills.every(b=>b.items.every(l=>l.cost===undefined)));assert.equal(scoped.audits.length,0);done('deferred history applies the same role and branch projection');
const baselineDir=process.env.MORI_BASELINE_DIR;
if(baselineDir){
 const b=fixture(path.resolve(baselineDir));b.resetCounts();const auth=b.request('moriAuthVerify',...b.otp());b.request('moriAuthWho',auth.token);b.request('moriBootstrap',auth.token);const beforeLogin=cp(b.counter);
 b.resetCounts();b.request('moriApi',auth.token,'bill.pay',pay());b.request('moriDelta',auth.token,['Bills','Items','Audit']);const beforeCheckout=cp(b.counter);
 console.log('MEASURED MOCK SERVICE COUNTS (not wall-clock timings):');console.log(JSON.stringify({beforeLogin,afterLoginCold:loginCold,afterLoginWarm:loginWarm,beforeCheckout,afterCheckout:checkout},null,2));
 assert(loginCold.getValues<beforeLogin.getValues);assert(checkout.getValues<beforeCheckout.getValues);assert(checkout.rowsRead<beforeCheckout.rowsRead);assert(checkout.setValues<beforeCheckout.setValues);
}
console.log('ALL STORAGE/PERFORMANCE TESTS PASSED. Google deployment latency remains unmeasured.');
