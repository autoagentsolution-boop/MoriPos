'use strict';
const assert=require('assert');const {harness,served,read}=require('./startup.test');const {fixture,cp}=require('./storage.fixture');
const done=s=>console.log('PASS:',s);
function html(){const marker='\n})();\n/* MORI_FRONTEND_END:';return served(read('Index.html').replace(marker,'\nwindow.__planning={state,render,allowed,renderPage,recipeEditor:invRecipeEditor,recipe:moriRecipe_,forecast:moriForecastUI,refresh:moriForecastRefresh,action:moriForecastAction,results:moriForecastResultsHTML,calculate:moriForecastCalculate_,showLogin:moriShowLogin,applyAdmin:moriApplyAdmin,auditSnapshot:moriAuditBillSnapshot,auditDiff:moriAuditBillDiff,queue:moriAuditQueueEdits,flush:moriAuditFlush,batches:moriAuditBatchesFor,restore:moriAuditRestore,auditHTML,get auditQueue(){return moriAuditQueue},get auditError(){return moriAuditError},confirmPayment:(...a)=>confirmPayment(...a)};'+marker)).html;}
(async()=>{
 const f=fixture(undefined,{bills:0,items:1,clock:'2026-11-05T05:00:00Z'}),token=f.session();
 f.request('moriAnalyticsInstall');f.request('moriAnalyticsSyncNow');
 const core=f.request('moriSessionBootstrap',token).data,all=[];
 const handlers={moriSessionBootstrap:()=>({authenticated:true,data:core}),moriHistory:()=>({bills:[],stockins:[],bookings:[],audits:[],attendance:[]})};
 for(const name of ['moriForecastLoad','moriForecastGet','moriForecastSave','moriForecastSaveDefaults','moriForecastInstall','moriBillAudit','moriCheckout'])handlers[name]=(_token,...args)=>f.request(name,token,...args);
 const h=harness(html(),{token:'valid',handlers});all.push(h);await h.flush();await h.timeout(0);const ui=h.ctx.__planning;
 assert(ui.allowed('ADMIN').includes('forecast'));assert(ui.allowed('MANAGER').includes('forecast'));assert(!ui.allowed('EMPLOYEE').includes('forecast'));
 assert(!h.calls.some(x=>x.name.startsWith('moriForecast')));ui.state.page='forecast';ui.render();await h.flush();
 assert.equal(h.calls.filter(x=>x.name==='moriForecastLoad').length,1);assert(ui.forecast.snapshot);assert.equal(ui.forecast.plan.scenarios.length,3);assert.match(h.elements.get('app').innerHTML,/Forecast & Lập kế hoạch/);
 h.elements.get('fc-add-item').value='1';await ui.action('add');assert.equal(ui.forecast.plan.items.length,1);assert.equal(ui.forecast.plan.scenarios[1].lines.length,1);assert.match(ui.results(),/fc-scenarios/);
 const beforeRPC=h.calls.length,input=h.ctx.document.createElement('input');input.dataset.fcLine='1:0:quantity';input.value='15';await h.emitDocument('input',input);assert.equal(ui.forecast.plan.scenarios[1].lines[0].quantity,15);assert.equal(h.calls.length,beforeRPC);
 await ui.action('save');assert(ui.forecast.plan.id);assert.equal(f.db.ForecastPlans.length,2);await ui.action('defaults');assert.equal(f.get('Settings','global').forecast.goal.mode,'FIXED');
 done('forecast loads only on opening, renders three editable scenarios, calculates locally and saves server plans/defaults');
 const date=h.ctx.document.createElement('input');date.dataset.fcConfig='endDate';date.value='2026-11-12';await h.emitDocument('input',date);assert(ui.forecast.dirtyData);assert.match(ui.results(),/Cập nhật từ doanh số/);
 await ui.action('refresh');assert(!ui.forecast.dirtyData);assert.equal(ui.forecast.snapshot.endDate,'2026-11-12');assert.equal(ui.forecast.plan.scenarios[1].lines[0].quantity,15);
 done('period edits require the correct data window; refreshing preserves scenario assumptions');
 const planCopy=cp(ui.forecast.plan);assert.deepEqual(cp(ui.calculate(planCopy,ui.forecast.snapshot)),cp(f.context().moriForecastCalculate_(planCopy,ui.forecast.snapshot)));
 const editor=ui.recipeEditor({id:3,components:[{itemId:1,qty:200,unit:'g',wastePercent:5}],processingCost:1000});assert.match(editor,/data-recipe-unit/);assert.match(editor,/data-recipe-waste/);assert.match(editor,/data-recipe-add/);
 done('browser/server use identical forecast arithmetic; recipe editor includes unit, waste and expandable ingredients');
 // Drive the real legacy change handler; the new capture listener must see its committed price edit.
 ui.state.page='sales';ui.state.bill.items=[{id:1,name:'Combo A',qty:1,unitPrice:10000,catalogPriceAtAdd:10000}];ui.state.bill.method='BANK_TRANSFER';
 const price=h.ctx.document.createElement('input');price.id='inline-price-0';price.value='12000';price.dataset.money='1';await h.emitDocument('change',price);assert.equal(ui.state.bill.items[0].unitPrice,12000);assert.equal(ui.auditQueue.length,1);assert.equal(ui.auditQueue[0].events[0].field,'item.price');assert.equal(ui.auditQueue[0].events[0].before,10000);assert.equal(ui.auditQueue[0].events[0].after,12000);
 assert.match(ui.auditHTML(),/10\.000 ₫/);assert.match(ui.auditHTML(),/12\.000 ₫/);assert.match(ui.auditHTML(),/Chờ ghi/);
 const second=h.ctx.document.createElement('input');second.id='inline-price-0';second.value='13000';second.dataset.money='1';await h.emitDocument('keydown',second,{key:'Enter'});assert.equal(ui.state.bill.items[0].unitPrice,13000);assert.equal(ui.auditQueue[0].events.length,2);
 assert.equal(h.calls.filter(x=>x.name==='moriBillAudit').length,0);await h.timeout(1800);assert.equal(h.calls.filter(x=>x.name==='moriBillAudit').length,1);assert.equal(ui.auditQueue.length,0);assert.match(ui.auditHTML(),/13\.000 ₫/);
 done('real price handlers, including Enter, produce readable audit batches with no per-keystroke RPC');
 // A new confirmed edit accompanies payment and is acknowledged only after server success.
 const third=h.ctx.document.createElement('input');third.id='inline-price-0';third.value='14000';await h.emitDocument('change',third);assert.equal(ui.auditQueue.length,1);
 await ui.confirmPayment();await h.flush();const payment=h.calls.find(x=>x.name==='moriCheckout');assert.equal(payment.args[1].auditBatches.length,1);assert.equal(ui.auditQueue.length,0);assert.equal(ui.state.bill.items.length,0);assert.equal(h.calls.filter(x=>x.name==='moriDelta').length,0);assert(ui.forecast.stale);
 done('pending bill edits ride checkout, acknowledge after commit, and mark forecast for refresh without a reload');
 // Failed writes keep the exact immutable group and allow retry after reloading the queue.
 let fail=true;const failed=harness(html(),{token:'valid',handlers:{...handlers,moriBillAudit:(_t,p)=>fail?new Error('offline'):f.request('moriBillAudit',token,p)}});all.push(failed);await failed.flush();const fu=failed.ctx.__planning;fu.state.bill.items=[{id:1,name:'Item 1',qty:1,unitPrice:10000}];const shot=fu.auditSnapshot(fu.state.bill);fu.queue(shot,[{field:'item.price',before:10000,after:11000,itemName:'Item 1'}]);const groupId=fu.auditQueue[0].id;await fu.flush();assert.equal(fu.auditQueue.length,1);assert.equal(fu.auditError,'offline');assert(fu.auditQueue[0].sealed);
 fu.restore(core.user);assert(fu.auditQueue[0].sealed);fu.queue(shot,[{field:'item.price',before:11000,after:12000,itemName:'Item 1'}]);assert.equal(fu.auditQueue.length,2);assert.equal(fu.auditQueue[0].id,groupId);fail=false;await fu.flush();assert.equal(fu.auditQueue.length,0);
 done('failed background audit persists sealed groups; later edits cannot be appended to an already-sent group');
 // Old-session asynchronous forecast responses must not restore data after logout.
 let resolveLoad;const stale=harness(html(),{token:'valid',handlers:{...handlers,moriForecastLoad:()=>new Promise(r=>resolveLoad=r)}});all.push(stale);await stale.flush();const su=stale.ctx.__planning;su.state.page='forecast';su.render();await stale.flush();assert(resolveLoad);su.showLogin();resolveLoad(f.request('moriForecastLoad',token,{branchId:1}));await stale.flush();assert.equal(su.forecast.snapshot,null);assert(stale.elements.has('mori-auth'));
 done('late forecast data from a signed-out session is ignored');
 for(const x of all)assert.equal(x.errors.length,0);
 console.log('ALL PLANNING UI TESTS PASSED (Node VM + DOM/RPC harness, not a real browser).');
})().catch(e=>{console.error(e);process.exitCode=1;});
