'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const html=fs.readFileSync(path.join(__dirname,'../Index.html'),'utf8');
const code=fs.readFileSync(path.join(__dirname,'../Code.gs'),'utf8');
const st=html.indexOf('/* MORI_ACTION_FEEDBACK_START:'),en=html.indexOf('/* MORI_ACTION_FEEDBACK_END */',st);
assert(st>=0&&en>st);
const extracted=html.slice(st,en)+'\n;globalThis.ACTIONS=moriActionUI;';
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function makeHarness(){let live=true,busy=false,onClick;const buttons=[],registry={};
 class Button{
  constructor(dataset){this.dataset={...dataset};this.id='';this.innerHTML='<b>Lưu</b>';this.isConnected=true;this.disabled=false;this.attrs={};const classes=new Set();this.classList={add:x=>classes.add(x),remove:x=>classes.delete(x)};}
  matches(){return true;}closest(){return this;}setAttribute(k,v){this.attrs[k]=v;}removeAttribute(k){delete this.attrs[k];}
 }
 class Box{
  constructor(){this.id='mori-action-progress';this.hidden=true;this.lastElementChild={textContent:''};}
  setAttribute(){}set innerHTML(html){this._html=html;this.lastElementChild={textContent:''};}get innerHTML(){return this._html;}
 }
 const document={body:{appendChild:x=>{registry[x.id]=x;}},getElementById:id=>registry[id]||null,createElement:()=>new Box(),querySelectorAll:sel=>sel==='[data-mori-pending-key]'?buttons.filter(x=>x.dataset.moriPendingKey):buttons};
 const window={addEventListener:(name,fn)=>{if(name==='click')onClick=fn;}};
 const context=vm.createContext({document,window,setTimeout,clearTimeout,queueMicrotask,moriIsLive:()=>live,get moriLiveBusy(){return busy}});
 vm.runInContext(extracted,context);
 return {buttons,Button,ui:context.ACTIONS,document,click:b=>{let stopped=false;onClick({target:b,preventDefault:()=>{stopped=true},stopImmediatePropagation:()=>{stopped=true}});return stopped;},setLive:x=>live=x};
}
(async()=>{
 const x=makeHarness(),b=new x.Button({action:'confirm-payment'});x.buttons.push(b);
 assert.equal(x.click(b),false);assert.equal(x.click(b),true);assert.equal(x.ui.pendingCount(),1);
 b.disabled=true;b.innerHTML='Đang lưu thanh toán…';await pause(0);assert.equal(b.disabled,true);
 const done=x.ui.attachRPC();done();await pause(230);assert.equal(b.disabled,false);assert.equal(b.innerHTML,'<b>Lưu</b>');assert.equal(x.ui.pendingCount(),0);
 console.log('PASS: checkout double-click blocked and original state restored after success/error');
 for(const attr of [{confirmStock:'7'},{action:'confirm-stock-reject'},{action:'confirm-attendance'},{action:'submit-stock'},{publicAction:'submit-order'},{fcAction:'save'},{holidaySave:''}]){
  const y=new x.Button(attr);x.buttons.push(y);x.click(y);await pause(0);assert.equal(y.disabled,true,JSON.stringify(attr));const finish=x.ui.attachRPC();finish();await pause(215);assert.equal(y.disabled,false,JSON.stringify(attr));
 }
 console.log('PASS: stock approval, attendance, public order, forecast and holiday saving show pending feedback');
 const k=new x.Button({staffSave:''});x.buttons.push(k);x.click(k);await pause(0);x.ui.cancelUnstarted();assert.equal(k.disabled,false);assert.equal(x.ui.pendingCount(),0);
 console.log('PASS: invalid input or early failure unlocks the action');
 const z=new x.Button({holidayQuickSave:''});x.buttons.push(z);x.click(z);await pause(0);const endRpc=x.ui.attachRPC();const replacement=new x.Button({holidayQuickSave:''});x.buttons.push(replacement);x.ui.sync();assert.equal(replacement.disabled,true);endRpc();await pause(230);assert.equal(replacement.disabled,false);
 console.log('PASS: rerendered button remains locked until request completes');
 x.setLive(false);const offline=new x.Button({action:'save-settings'});x.buttons.push(offline);x.click(offline);assert.equal(x.ui.pendingCount(),0);
 console.log('PASS: local/offline preview unaffected');
 const digest=crypto.createHash('sha256').update(html).digest('hex');assert(code.includes(digest));assert(html.includes('MORI_FRONTEND_BUILD:3.2.13'));
 assert(html.includes("request.requestId=moriPublicRetryId('order',request)"));assert(html.includes("req.requestId=moriPublicRetryId('booking',req)"));
 console.log('PASS: frontend checksum and retry-safe public request IDs');
})().catch(err=>{console.error(err);process.exitCode=1});
