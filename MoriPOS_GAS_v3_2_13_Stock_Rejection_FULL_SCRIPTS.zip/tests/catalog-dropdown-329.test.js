'use strict';
const assert=require('node:assert/strict'),vm=require('node:vm');
const {fixture,cp}=require('./storage.fixture');
const {harness,served,read}=require('./startup.test');
const html=read('Index.html'),done=s=>console.log('PASS:',s);

// Exercise the production enhancement function against mutable DOM nodes.
// This small DOM fixture models identity/selection/events, not CSS/layout.
function dropdownHarness(){
 const selects=[],events=[],registry=new Map();
 class Trigger{
  constructor(){this.dataset={};this.attrs={};this.span={textContent:''};this.disabled=false;}
  querySelector(sel){return sel==='span'?this.span:null;}
  setAttribute(k,v){this.attrs[k]=v;}
 }
 class Select{
  constructor(values,id=''){this.id=id;this.dataset={};this.style={};this.attrs={};this.disabled=false;this.options=values.map(([value,textContent])=>({value,textContent}));this.value=values[0][0];selects.push(this);}
  get selectedOptions(){return this.options.filter(o=>o.value===this.value);}
  setAttribute(k,v){this.attrs[k]=v;}
  getAttribute(k){return this.attrs[k]||null;}
  closest(){return null;}
  insertAdjacentElement(_,node){this.nextElementSibling=node;}
  dispatchEvent(event){events.push({target:this,type:event.type});}
 }
 const document={querySelectorAll:()=>selects,getElementById:id=>selects.find(x=>x.id===id)||registry.get(id)||null,createElement:()=>new Trigger()};
 const context=vm.createContext({document});
 const start=html.indexOf('let moriSelectSequence='),end=html.indexOf('function renderComboOptions()',start);
 vm.runInContext(html.slice(start,end)+';globalThis.enhance=enhanceSelects;',context);
 return {selects,Select,events,document,enhance:context.enhance};
}
const d=dropdownHarness(),a=new d.Select([['1','Chả cá'],['2','Khổ qua']]),au=new d.Select([['kg','kg'],['g','g']]);d.enhance();
const originalTrigger=a.nextElementSibling;a.value='2';au.value='g';d.enhance();assert.equal(a.nextElementSibling,originalTrigger);assert.equal(a.nextElementSibling.span.textContent,'Khổ qua');assert.equal(au.nextElementSibling.span.textContent,'g');
const b=new d.Select([['','Chọn thành phần'],['3','Nước dùng']]),bu=new d.Select([['l','l'],['ml','ml']]);d.enhance();
assert.equal(new Set(d.selects.map(s=>s.id)).size,4);
for(const s of d.selects){assert.equal(s.style.display,'none');assert.equal(s.nextElementSibling.className,'combo-trigger select-combo');assert.equal(s.nextElementSibling.dataset.nativeTarget,s.id);}
d.selects.splice(d.selects.indexOf(a),1);d.selects.splice(d.selects.indexOf(au),1);const c=new d.Select([['4','Đậu hủ']]);d.enhance();assert.notEqual(c.id,b.id);assert.notEqual(c.id,bu.id);
bu.options=[{value:'kg',textContent:'kg'},{value:'g',textContent:'g'}];bu.value='kg';d.enhance();assert.equal(bu.nextElementSibling.span.textContent,'kg');
done('incremental dropdown IDs remain unique; repeated enhancement reuses triggers and refreshes values/units');
assert(!html.includes('function indicator()'));assert(!html.includes('#mori-action-progress'));
assert(html.includes("simple=choices.length<=8&&!recipeField"));
done('ingredient search is unconditional; no floating action-progress element is created');

function testHTML(){const marker='\n})();\n/* MORI_FRONTEND_END:';return served(html.replace(marker,'\nwindow.__catalog={state,render,write:moriWrite,applyDelta:moriApplyDelta,openModal,recipeEditor:invRecipeEditor,readRecipe:invReadRecipe,enhanceSelects,showLogin:moriShowLogin};'+marker)).html;}
(async()=>{
 const f=fixture(undefined,{items:3,bills:0}),token=f.session();f.props.MORI_SEQ_ITEM='3';
 f.edit('Items',1,x=>Object.assign(x,{name:'Chả cá',baseUnit:'kg',cost:250000,type:'MATERIAL'}));
 f.edit('Items',2,x=>Object.assign(x,{name:'Nước dùng',baseUnit:'l',cost:10000,type:'MATERIAL'}));
 const core=f.request('moriSessionBootstrap',token).data;
 let rejectNext=false,resolveSave;
 const h=harness(testHTML(),{token:'valid',handlers:{moriSessionBootstrap:()=>({authenticated:true,data:core}),moriApi:(_t,action,payload)=>new Promise(resolve=>{resolveSave=()=>resolve(rejectNext?new Error('Lỗi lưu giả lập'):f.request('moriApi',token,action,payload));})}});
 await h.flush();const ui=h.ctx.__catalog;ui.state.page='items';
 const components=[{itemId:1,qty:60,unit:'g',wastePercent:10},{itemId:2,qty:250,unit:'ml',wastePercent:0}];
 for(const type of ['PRODUCT','SERVICE']){
  const payload={name:type==='PRODUCT'?'Món có định lượng':'Dịch vụ có định lượng',cat:'Thử nghiệm',type,price:30000,cost:18000,baseUnit:'phần',processingCost:500,components,track:false};
  ui.openModal('add-product');const callStart=h.calls.length;let closed=false;
  const pending=ui.write('catalog.save',cp(payload),()=>{closed=true;ui.state.modal=null;},true);
  assert.equal(closed,false);assert(!ui.state.items.some(x=>x.name===payload.name));
  resolveSave();const saved=await pending;await h.flush();assert(saved);assert.equal(closed,true);
  const local=ui.state.items.find(x=>x.id===saved.id);assert.equal(local.type,type);assert.deepEqual(cp(local.components),components);assert.equal(local.version,saved.version);
  assert.deepEqual(f.get('Items',saved.id).components,components);
  const calls=h.calls.slice(callStart);assert.equal(calls.filter(x=>x.name==='moriApi').length,1);assert.equal(calls.filter(x=>['moriDelta','moriBootstrap'].includes(x.name)).length,0);
  const reopened=ui.recipeEditor(local);assert(reopened.includes('value="60"'));assert(reopened.includes('value="250"'));assert(reopened.includes('value="g" selected'));assert(reopened.includes('value="ml" selected'));
  const fresh=f.request('moriSessionBootstrap',token).data.items.find(x=>x.id===saved.id);assert.deepEqual(fresh.components,components);assert.equal(fresh.processingCost,500);
  // Old polling data must not replace a more recently committed recipe.
  ui.applyDelta({Items:[{...saved,version:0,components:[]}]},false);assert.deepEqual(cp(ui.state.items.find(x=>x.id===saved.id).components),components);
 }
 done('PRODUCT and SERVICE recipes retain every ingredient/unit/waste through save, reopening and fresh bootstrap; save requires one RPC');
 const saved=ui.state.items.find(x=>x.type==='PRODUCT'&&x.name==='Món có định lượng');ui.openModal('edit-item',{id:saved.id});
 // Preserve the editor node while a background render updates the page.
 const modal=h.elements.get('modal-root'),sentinel={};modal.querySelector=selector=>selector==='#mori-recipe-rows'?sentinel:null;modal._html='UNSAVED_DRAFT';
 ui.render();assert.equal(modal.innerHTML,'UNSAVED_DRAFT');
 done('background render retains the same item editor and its unsaved fields');
 let onDone=false;rejectNext=true;
 const failed=ui.write('catalog.save',{...saved,components:[{...components[0],qty:65},components[1]]},()=>{onDone=true;ui.state.modal=null;},true);resolveSave();assert.equal(await failed,null);assert.equal(onDone,false);assert(ui.state.modal);assert.deepEqual(f.get('Items',saved.id).components,components);
 rejectNext=false;const retry=ui.write('catalog.save',{...saved,components:[{...components[0],qty:65},components[1]]},()=>{ui.state.modal=null;},true);resolveSave();const updated=await retry;assert.equal(updated.components[0].qty,65);assert.equal(ui.state.items.find(x=>x.id===saved.id).components[0].qty,65);
 done('failed save keeps the editor and saved recipe; manual retry commits the edited quantity');
 // Drive the actual live create-click handler, including invReadRecipe and the
 // form-to-API payload, rather than only calling the write adapter directly.
 const oldQuery=h.ctx.document.querySelector,oldAll=h.ctx.document.querySelectorAll;
 for(const type of ['PRODUCT','SERVICE']){
  ui.openModal('add-product');
  const fields={'new-item-name':'Form '+type,'new-item-cat':'Thử nghiệm','new-item-type':type,'new-item-price':'30000','new-item-cost':'18000','new-item-holiday':'','new-item-active':'true','new-item-unit':'phần','mori-processing-cost':'500'};
  for(const [id,value] of Object.entries(fields))h.elements.get(id).value=value;
  const ingredients=components.map((c,i)=>({dataset:{recipeItem:String(i)},value:String(c.itemId)}));
  const cells={};components.forEach((c,i)=>{cells[`[data-recipe-qty="${i}"]`]={value:String(c.qty)};cells[`[data-recipe-unit="${i}"]`]={value:c.unit};cells[`[data-recipe-waste="${i}"]`]={value:String(c.wastePercent)};});
  h.ctx.document.querySelectorAll=sel=>sel==='[data-recipe-item]'?ingredients:oldAll(sel);
  h.ctx.document.querySelector=sel=>cells[sel]||oldQuery(sel);
  const button=h.ctx.document.createElement('button');button.dataset.action='save-new-product';button.closest=sel=>sel==='[data-action]'?button:null;
  await h.emitDocument('click',button);resolveSave();await h.flush();
  const created=ui.state.items.find(x=>x.name==='Form '+type);assert(created);assert.equal(created.type,type);assert.deepEqual(cp(created.components),components);assert.deepEqual(f.get('Items',created.id).components,components);
 }
 h.ctx.document.querySelector=oldQuery;h.ctx.document.querySelectorAll=oldAll;
 done('actual create-record click collects and saves PRODUCT/SERVICE ingredients, units and waste from every row');
 // A late response after logout must not repopulate the catalog.
 const delayed=ui.write('catalog.save',{...updated,name:'Late response'},null,true);ui.showLogin();ui.state.items=[];resolveSave();await delayed;assert.equal(ui.state.items.length,0);
 done('late catalog response is ignored after session change');
 assert.equal(h.errors.length,0);
 console.log('COMPLETE: catalog/dropdown regression checks passed (Node DOM/RPC simulation).');
})().catch(e=>{console.error(e);process.exitCode=1;});
