const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');const db={};let seq=0;const scriptProperties={};
const me={email:'owner@example.com',role:'ADMIN',branchIds:[1,2]},staff={email:'staff@example.com',role:'EMPLOYEE',branchIds:[1]};
const ctx={console,Date,JSON,Math,
 PropertiesService:{getScriptProperties:()=>({getProperty:k=>scriptProperties[k]??null,setProperty:(k,v)=>scriptProperties[k]=v})},
 LockService:{getScriptLock:()=>({tryLock:()=>true,releaseLock:()=>{}})},
 Utilities:{getUuid:()=>String(Date.now())+String(++seq).padStart(14,'0'),formatDate:(d,tz,fmt)=>new Date(d).toISOString().slice(0,10)},
};vm.createContext(ctx);
for(const x of ['Config.gs','Units.gs','ForecastCore.gs','AuditFormat.gs','Audit.gs','Inventory.gs','Billing.gs','Operations.gs','ApiRead.gs'])vm.runInContext(fs.readFileSync(path.join(root,x),'utf8'),ctx,{filename:x});
function cp(x){return JSON.parse(JSON.stringify(x));}
Object.assign(ctx,{
 moriFind_:(t,id)=>cp((db[t]||[]).find(x=>String(x.id)===String(id))||null),
 moriAll_:(t)=>cp(db[t]||[]),
 moriRecent_:(t)=>cp([...(db[t]||[])].reverse()),
 moriOpenBills_:()=>cp((db.Bills||[]).filter(x=>x.status==='OPEN')),
 moriFindJsonString_:(t,f,v)=>cp((db[t]||[]).find(x=>x[f]===v)||null),
 moriPutMany_:(t,updates)=>updates.map(u=>ctx.moriPut_(t,u.doc,u.expectedVersion)),
 moriInsert_:(t,x)=>{db[t]??=[];assert(!db[t].some(y=>String(y.id)===String(x.id)));x=cp(x);x.version=x.version||1;db[t].push(x);return cp(x)},
 moriPut_:(t,x,version)=>{const idx=(db[t]||[]).findIndex(y=>String(y.id)===String(x.id));assert(idx>=0);if(version!==undefined)assert.equal(db[t][idx].version,version,'version conflict');x=cp(x);x.version=db[t][idx].version+1;db[t][idx]=x;return cp(x)},
 moriAudit_:()=>{},moriActor_:()=>me,moriRequire_:(actor,roles,branchId)=>{if(!roles.includes(actor.role))throw Error('No permission');if(actor.role!=='ADMIN'&&branchId!=null&&!actor.branchIds.includes(Number(branchId)))throw Error('Not in branch')},
});
const seed=(t,x)=>{db[t]??=[];db[t].push({...cp(x),version:1});};
seed('Employees',{id:'staff@example.com',email:'staff@example.com',name:'Nhân viên',isActive:true});
seed('Settings',{id:'global',modules:{stockIn:true,onlineOrder:true,publishSite:true},lowStockPolicy:'WARN',lowStockThreshold:3,paidBillEditRoles:{ADMIN:true,EMPLOYEE:false}});
seed('PublishSite',{id:'site',published:true,mode:'ORDER_ONLINE',categoryVisibility:{},itemRules:{101:{visible:true,type:'NONE',value:0}},orderBranches:'ALL'});
seed('Branches',{id:1,code:'CN01',name:'CN01',isActive:true});
seed('Items',{id:101,name:'Nước suối',type:'PRODUCT',cat:'Đồ uống',price:12000,cost:6000,stockByBranch:{'1':40},costByBranch:{'1':6000},track:true,baseUnit:'cái'});
const shipping={name:'Khách A',phone:'0901234567',address:'12 Nguyen Trai, HCMC'};
function create(q){return ctx.moriOnlineCreate_(me,{branchId:1,items:[{id:101,qty:q,unitPrice:1}],shipping},false)}
const first=create(30);assert.equal(first.finalTotal,360000,'Price computed on server');assert.equal(first.orderStatus,'CONFIRMED');
assert.throws(()=>create(15),/Không đủ tồn/,'Second order must not oversell');
let x=ctx.moriOnlineMove_(me,first.id,'PREPARING');assert.equal(x.orderStatus,'PREPARING');
x=ctx.moriOnlineMove_(me,first.id,'SHIPPED');assert.equal(x.orderStatus,'SHIPPED');assert.equal(ctx.moriFind_('Items',101).stockByBranch['1'],10,'Must decrement once on shipping');
x=ctx.moriOnlineMove_(me,first.id,'DELIVERED');assert.equal(x.status,'FULFILLED','Delivered not necessarily paid');assert.equal(x.paymentStatus,'PENDING');
x=ctx.moriOnlinePayment_(me,first.id);assert.equal(x.status,'PAID');assert.equal(x.paidAmountAtCheckout,360000);
x=ctx.moriPaidBillEdit_(me,first.id,x.version,{tipAmount:20000,tipEmployeeIds:['staff@example.com'],billEmployeeId:'staff@example.com',itemEmployees:['staff@example.com']});assert.equal(x.finalTotal,380000);assert.equal(x.paidAmountAtCheckout,360000,'Tip edit cannot alter original paid amount');
assert.throws(()=>ctx.moriPaidBillEdit_(me,first.id,x.version-1,{tipAmount:100,tipEmployeeIds:[],billEmployeeId:'',itemEmployees:['']}),/VERSION_CONFLICT/);
const stock=ctx.moriStockCreate_(me,{branchId:1,supplier:'B',shipping:'Giao thùng nguyên',lines:[{id:101,qty:2,unit:'thùng',factor:24,cost:240000}],photoIds:[]});
ctx.moriStockConfirm_(me,stock.id);ctx.moriStockConfirm_(me,stock.id);assert.equal(ctx.moriFind_('Items',101).stockByBranch['1'],58,'Stock receipt must apply exactly once');
assert.throws(()=>ctx.moriStockCreate_(staff,{branchId:1,supplier:'B',shipping:'Giao thùng',lines:[{id:101,qty:1,factor:24,cost:100000}],photoIds:[]}),/ảnh chứng từ/);
const newPay=ctx.moriCreateOfflineBill_(me,{branchId:1,items:[{id:101,qty:2,unitPrice:10000}],method:'CASH',discount:0,discountFixed:0,tipAmount:0,clientRequestId:'repeat-123'},true);
assert.equal(newPay.finalTotal,20000,'Custom price for offline Bill must remain snapshot');assert.equal(ctx.moriCreateOfflineBill_(me,{branchId:1,items:[{id:101,qty:2,unitPrice:10000}],clientRequestId:'repeat-123'},true).id,newPay.id,'Repeated payment must be idempotent');
assert.equal(ctx.moriFind_('Items',101).price,12000,'Catalog original price unchanged');
// Regression: updating an OPEN draft must not insert a duplicate row.
const draft=ctx.moriCreateOfflineBill_(me,{branchId:1,items:[{id:101,qty:1,unitPrice:11000}],clientRequestId:'draft-regression-001'},false);
const beforeCount=(db.Bills||[]).length;
const updated=ctx.moriCreateOfflineBill_(me,{id:draft.id,version:draft.version,branchId:1,items:[{id:101,qty:2,unitPrice:11000}],clientRequestId:'draft-regression-001'},false);
assert.equal(updated.id,draft.id);assert.equal((db.Bills||[]).length,beforeCount,'Draft update must not insert duplicate');
const paidDraft=ctx.moriCreateOfflineBill_(me,{id:updated.id,version:updated.version,branchId:1,items:[{id:101,qty:2,unitPrice:11000}],clientRequestId:'draft-regression-001'},true);
assert.equal(paidDraft.status,'PAID');assert.equal((db.Bills||[]).length,beforeCount,'Paying existing draft must not insert duplicate');
// Cross-role data projections and Unicode category dedupe.
assert.equal(ctx.moriNorm_('Đồ uống'),ctx.moriNorm_('do uong'),'Vietnamese diacritics and D-stroke must normalize');
const item=ctx.moriFind_('Items',101);assert.equal(ctx.moriForActor_(staff,'Items',item).cost,undefined,'Employee must not receive cost');
assert.equal(ctx.moriForActor_({email:'mgr',role:'MANAGER',branchIds:[1]},'Items',item).cost!==undefined,true,'Manager requires cost for branch reporting');
const foreignBill={id:999,branchId:2,items:[{id:101,cost:100}],status:'PAID'};
assert.equal(ctx.moriReadFilter_(staff,'Bills',[foreignBill]).length,0,'Employee must not receive another branch bill');
assert.equal(ctx.moriForActor_(staff,'Settings',{modules:{stockIn:true},secret:'no',receipt:{paper:'80'}}).secret,undefined,'Employee settings projection');
console.log('PASS: price snapshot, reservation, no oversell, shipping deduction, delivery/payment split, tip edit, CAS version, stock receipt idempotency, photo policy, payment idempotency.');
