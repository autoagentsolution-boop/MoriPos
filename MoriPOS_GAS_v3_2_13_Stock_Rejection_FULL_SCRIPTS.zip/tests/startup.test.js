/** Node VM + small DOM/RPC fixtures. No claim of a real browser or real Google backend. */
'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const originalPath=process.env.MORI_ORIGINAL_DIR;
const read=(name,dir=root)=>fs.readFileSync(path.join(dir,name),'utf8');
function scripts(html){return [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)].map(m=>({source:m[1],line:html.slice(0,m.index).split('\n').length}));}
const runtimeResponses=new Map();
function served(html=read('Index.html'),params={},code=read('Code.gs')){
 const output=body=>({body,getContent(){return body},setTitle(){return this},addMetaTag(){return this}});
 const ctx={console:{log(){},warn(){},error(){}},HtmlService:{createTemplateFromFile(name){assert.equal(name,'Index');if(html===null)throw Error('No HTML file named Index');return {getRawContent(){return html}}},createHtmlOutput:output,createHtmlOutputFromFile(name){assert.equal(name,'Index');if(html===null)throw Error('No HTML file named Index');return output(html);}},Utilities:{DigestAlgorithm:{SHA_256:'sha256'},Charset:{UTF_8:'utf8'},computeDigest:(alg,text)=>[...crypto.createHash(alg).update(text).digest()],base64Encode:text=>Buffer.from(text,'utf8').toString('base64')}};
 vm.createContext(ctx);vm.runInContext(code,ctx);const body=ctx.doGet({parameter:params}).body;
 try{if(ctx.moriFrontendRuntime){const payload=ctx.moriFrontendRuntime();runtimeResponses.set(payload.sha256,payload)}}catch(_){}
 return {html:body,ctx};
}
function harness(html,{bridge=true,token='',blockedStorage=false,local={},handlers={}}={}){
 const elements=new Map(),windowEvents={},documentEvents={},calls=[],timers=new Map(),errors=[];let nextTimer=0;
 class Element {
  constructor(tag='div'){this.tagName=tag.toUpperCase();this.dataset={};this.style={};this.hidden=false;this.value='';this.textContent='';this.children=[];this._html='';this._id='';const set=new Set();this.classList={add:(...xs)=>xs.forEach(x=>set.add(x)),remove:(...xs)=>xs.forEach(x=>set.delete(x)),contains:x=>set.has(x),toggle(x,on){if(on===undefined)on=!set.has(x);on?set.add(x):set.delete(x);return on;}};}
  set id(value){this._id=value;elements.set(value,this)}get id(){return this._id}
  set innerHTML(value){this._html=value;for(const m of value.matchAll(/\bid=["']([^"']+)["']/g)){const node=new Element();node.id=m[1];this.children.push(node)}}
  get innerHTML(){return this._html}
  appendChild(node){this.children.push(node);if(node.id)elements.set(node.id,node);
   if(node.tagName==='SCRIPT'&&node.text){try{vm.runInContext(node.text,ctx,{filename:'MoriRuntime_3.2.0.js'})}catch(e){errors.push(e);emit('error',{error:e,message:e.message,filename:'MoriRuntime_3.2.0.js',lineno:1,colno:1})}}
   return node}
  remove(){elements.delete(this.id)}
  querySelector(){return null}querySelectorAll(){return []}setAttribute(){}addEventListener(){}focus(){}closest(){return null}matches(){return false}hasAttribute(){return false}
 }
 const body=new Element('body'),head=new Element('head');
 const bodyTag=html.match(/<body\b[^>]*>/i)?.[0]||'';
 for(const m of bodyTag.matchAll(/data-mori-(\w+)="([^"]*)"/g))body.dataset['mori'+m[1][0].toUpperCase()+m[1].slice(1)]=m[2];
 const pre=html.slice(0,html.indexOf('<script>\n(()=>'));
 for(const m of pre.matchAll(/\bid="([^"]+)"/g)){const node=new Element();node.id=m[1];}
 // Core nodes exist after the complete static body is parsed.
 for(const id of ['app','modal-root','toast-root']){if(!elements.has(id)){const node=new Element();node.id=id;}}
 const session=new Map(token?[['mori_live_token',token]]:[]),localReads=[];
 const storage={getItem(k){if(blockedStorage)throw Error('SecurityError: storage blocked');return session.get(k)||null},setItem(k,v){if(blockedStorage)throw Error('SecurityError: storage blocked');session.set(k,v)},removeItem(k){if(blockedStorage)throw Error('SecurityError: storage blocked');session.delete(k)}};
 const ctx={console:{...console,info(){}},Intl,Date,JSON,Math,Set,Map,URLSearchParams,Uint8Array,TextDecoder,atob,crypto:{randomUUID:crypto.randomUUID,subtle:{digest:async(alg,bytes)=>Uint8Array.from(crypto.createHash('sha256').update(Buffer.from(bytes)).digest()).buffer}},location:{search:'',reload(){}},
  document:{body,head,visibilityState:'visible',getElementById:id=>elements.get(id)||null,createElement:tag=>new Element(tag),querySelector(){return null},querySelectorAll(){return []},addEventListener(name,fn,capture=false){(documentEvents[name]??=[]).push({fn,capture});}},
  localStorage:{getItem(k){localReads.push(k);if(blockedStorage)throw Error('SecurityError');return local[k]||null},setItem(){}},sessionStorage:storage,
  setTimeout(fn,ms){const id=++nextTimer;timers.set(id,{fn,ms});return id},clearTimeout(id){timers.delete(id)},setInterval(){return 0},queueMicrotask,
  addEventListener(name,fn){(windowEvents[name]??=[]).push(fn)},removeEventListener(name,fn){windowEvents[name]=(windowEvents[name]||[]).filter(x=>x!==fn)},scrollTo(){}};
 ctx.window=ctx;ctx.self=ctx;ctx.top={};
 const emit=(name,event)=>(windowEvents[name]||[]).forEach(fn=>fn(event));
 function runner(ok,fail){return new Proxy({}, {get(_,name){
  if(name==='withSuccessHandler')return fn=>runner(fn,fail);
  if(name==='withFailureHandler')return fn=>runner(ok,fn);
  return (...args)=>{calls.push({name,args});const handler=handlers[name];if(handler===null)return;
   const answer=handler?handler(...args):(name==='moriFrontendRuntime'?(runtimeResponses.get(args[0])||new Error('Unknown runtime source')):name==='getGoogleSession'?{email:''}:{authenticated:false});
   Promise.resolve(answer).then(value=>queueMicrotask(()=>{if(value instanceof Error){if(fail)fail(value)}else if(ok)ok(value)}),error=>{if(fail)fail(error)});
  };
 }});}
 if(bridge)ctx.google={script:{run:runner()}};
 vm.createContext(ctx);
 for(const [i,part] of scripts(html).entries()){
  try{vm.runInContext(part.source,ctx,{filename:'Index.html:script-'+i,lineOffset:part.line-1});}
  catch(e){errors.push(e);emit('error',{error:e,message:e.message});}
 }
 return {ctx,body,elements,calls,errors,localReads,session,async emitDocument(name,target,extra={}){let stopped=false;const event={target,preventDefault(){},stopPropagation(){},stopImmediatePropagation(){stopped=true},...extra};for(const capture of [true,false])for(const listener of documentEvents[name]||[])if(!!listener.capture===capture&&!stopped)listener.fn(event);await this.flush();},async flush(){for(let i=0;i<30;i++)await Promise.resolve()},async timeout(ms){for(const [id,t] of [...timers])if(t.ms===ms){timers.delete(id);t.fn()}await this.flush()},emit};
}
const adminData={user:{role:'ADMIN',email:'owner@example.test',name:'Owner'},store:{name:'QC Store'},branches:[{id:1,name:'QC Branch',code:'QC01'}],settings:{modules:{}},publishSite:{published:false},items:[],bills:[],stockins:[],bookings:[],customers:[],employees:[],attendance:[],audits:[]};
const publicData={published:true,store:{name:'QC Shop'},branches:[{id:1,name:'QC Branch',code:'QC01'}],items:[],settings:{modules:{publishSite:true,booking:true,onlineOrder:true},site:{published:true,mode:'ORDER_ONLINE',categoryVisibility:{},itemRules:{}}}};
const done=(name)=>console.log('PASS:',name);
if(require.main===module)(async()=>{
 for(const f of fs.readdirSync(root).filter(f=>f.endsWith('.gs')))new vm.Script(read(f),{filename:f});
 for(const [i,s] of scripts(read('Index.html')).entries())new vm.Script(s.source,{filename:'Index.html script '+i});
 JSON.parse(read('appsscript.json'));done('all server files, HTML scripts, manifest parse');
 if(originalPath){
  const html=served(read('Index.html',originalPath),{},read('Code.gs',originalPath)).html;
  let original=harness(html,{handlers:{moriAuthWho:null}});await original.flush();
  assert.equal(original.errors.length,0);assert(original.body.classList.contains('mori-live'));assert(!original.body.classList.contains('mori-ready'));
  assert(!original.elements.has('mori-auth'));assert(original.calls.some(c=>c.name==='moriAuthWho'));
  done('reproduced original: pending first auth call leaves #app hidden and no login/loading panel');
  original=harness(html,{local:{mori_pos_mockup_config_v1_2:JSON.stringify({branches:[null]})}});
  assert(original.errors.some(e=>/null/.test(e.message)));done('reproduced original: stale malformed demo configuration stops startup');
 }
 const full=served();let h=harness(full.html);await h.flush();
 assert.equal(h.errors.length,0);assert(h.elements.get('mori-auth'));assert(h.elements.get('mori-boot').hidden);assert.equal(h.calls.filter(c=>c.name!=='moriFrontendRuntime').length,0);assert.equal(h.elements.get('app').innerHTML,'');
 done('first admin visit uses one static-code RPC, no auth RPC, and no demo render');
 h=harness(full.html,{bridge:false});await h.flush();assert(!h.elements.get('mori-boot').hidden);assert.match(h.elements.get('mori-boot-error').textContent,/Google Apps Script/);assert.equal(h.elements.get('app').innerHTML,'');done('missing Google bridge shows a visible error, never demo sales');
 h=harness(full.html,{token:'old',handlers:{moriSessionBootstrap:()=>({authenticated:false})}});await h.flush();assert(h.elements.get('mori-auth'));assert(!h.session.has('mori_live_token'));done('expired session returns to login and clears stale token');
 h=harness(full.html,{token:'valid',handlers:{moriSessionBootstrap:()=>({authenticated:true,data:adminData})}});await h.flush();assert.equal(h.errors.length,0);assert(h.body.classList.contains('mori-ready'));assert(h.elements.get('mori-boot').hidden);assert.match(h.elements.get('app').innerHTML,/QC Store/);done('authenticated admin renders server-provided store');
 h=harness(full.html,{handlers:{moriAuthStart:()=>new Error('Email này chưa được cấp quyền truy cập hệ thống quản lý.')}});await h.flush();
 h.elements.get('mori-auth-email').value='outsider@example.test';await h.elements.get('mori-auth-send').onclick();await h.flush();
 assert.equal(h.elements.get('mori-auth-send').hidden,false);assert.match(h.elements.get('mori-auth-error').textContent,/chưa được cấp quyền/);done('staff email not on allowlist stays at step one without OTP input');
 h=harness(full.html,{handlers:{moriAuthStart:()=>({ok:true})}});await h.flush();
 h.elements.get('mori-auth-email').value='staff@example.test';await h.elements.get('mori-auth-send').onclick();await h.flush();
 assert.equal(h.elements.get('mori-auth-verify').hidden,false);assert.equal(h.elements.get('mori-auth-email').readOnly,true);done('allowlisted staff unlocks OTP step only after accepted backend result');
 h=harness(full.html,{token:'valid',handlers:{moriSessionBootstrap:null}});await h.flush();await h.timeout(20000);assert(h.elements.get('mori-auth'));assert.match(h.elements.get('mori-auth-error').textContent,/20 giây/);done('hanging session check times out visibly');
 h=harness(full.html,{token:'valid',handlers:{moriSessionBootstrap:null}});await h.flush();await h.timeout(20000);assert.match(h.elements.get('mori-auth-error').textContent,/moriSessionBootstrap/);done('hanging admin bootstrap times out visibly');
 h=harness(full.html,{token:'valid',handlers:{moriSessionBootstrap:()=>new Error('Setup incomplete')}});await h.flush();assert.match(h.elements.get('mori-auth-error').textContent,/Setup incomplete/);done('backend failure is shown on login');
 for(const tab of ['home','catalog','booking','tracking']){
  h=harness(served(undefined,{view:'shop',tab}).html,{handlers:{moriPublicBootstrap:()=>publicData}});await h.flush();assert.equal(h.errors.length,0);assert(h.elements.get('mori-boot').hidden);assert(h.body.classList.contains('mori-ready'));assert.match(h.elements.get('app').innerHTML,/QC Shop/);done('public '+tab+' loads server data');
 }
 h=harness(served(undefined,{view:'shop'}).html,{handlers:{moriPublicBootstrap:()=>({published:false})}});await h.flush();assert.match(h.elements.get('app').innerHTML,/chưa mở website/);assert(h.elements.get('mori-boot').hidden);done('unpublished shop shows explicit closed state');
 h=harness(served(undefined,{view:'shop'}).html,{handlers:{moriPublicBootstrap:null}});await h.flush();await h.timeout(20000);assert.match(h.elements.get('mori-boot-error').textContent,/moriPublicBootstrap/);assert(!h.elements.get('mori-boot').hidden);done('hanging public bootstrap shows a timeout');
 h=harness(served(undefined,{view:'shop'}).html,{handlers:{moriPublicBootstrap:()=>new Error('Test backend error')}});await h.flush();assert.match(h.elements.get('mori-boot-error').textContent,/Test backend error/);done('public server exception is visible');
 h=harness(full.html,{blockedStorage:true,handlers:{moriAuthVerify:()=>({token:'test-token',data:adminData}),moriSessionBootstrap:()=>({authenticated:true,data:adminData})}});await h.flush();h.elements.get('mori-auth-email').value='owner@example.test';h.elements.get('mori-auth-code').value='123456';await h.elements.get('mori-auth-login').onclick();await h.flush();assert.match(h.elements.get('app').innerHTML,/QC Store/);assert(!h.elements.has('mori-auth'));done('OTP login succeeds even when sessionStorage is blocked');
 h=harness(full.html,{local:{mori_pos_mockup_config_v1_2:JSON.stringify({branches:[null]}),mori_pos_demo_online_orders_v1:'[null]'}});await h.flush();assert.equal(h.errors.length,0);assert.equal(h.localReads.length,0);assert(h.elements.get('mori-auth'));done('live startup ignores stale demo localStorage');
 h=harness(read('Index.html'),{bridge:false});await h.flush();assert.equal(h.errors.length,0);assert(h.elements.get('mori-boot').hidden);assert.match(h.elements.get('app').innerHTML,/Bill hiện tại/);done('offline preview still renders');
 const broken=served(read('Index.html').replace("(()=>{'use strict';","(()=>{'use strict'; const = ;")).html;h=harness(broken);await h.flush();assert.equal(h.errors.length,1);assert(!h.elements.get('mori-boot').hidden);assert.match(h.elements.get('mori-boot-error').textContent,/Unexpected/);done('boot guard displays simulated main-script syntax failure');
 h=harness(full.html.replace(/<script id="mori-runtime-loader">[\s\S]*?<\/script>/,'') );await h.timeout(30000);assert.match(h.elements.get('mori-boot-error').textContent,/Quá thời gian/);done('missing main script triggers watchdog');
 assert.match(served(null).html,/Không thể mở Mori/);assert.match(served(read('Index.html').replace('<body>','')).html,/thiếu thẻ head hoặc body/);done('missing Index or required injection target gets server diagnostic page');
 const withoutMarkers=read('Index.html').replace('<!-- MORI_FRONTEND_BUILD:3.2.13 -->','').replace('/* MORI_FRONTEND_END:3.2.13 */','');
 const unmarked=served(withoutMarkers);h=harness(unmarked.html);await h.flush();assert.equal(h.errors.length,0);assert(h.elements.get('mori-auth'));assert.equal(h.calls.filter(c=>c.name!=='moriFrontendRuntime').length,0);done('missing BOTH version comments does not block login');
 const unmarkedReport=unmarked.ctx.moriFrontendCheck();assert(unmarkedReport.ok);assert(!unmarkedReport.startMarker);assert(!unmarkedReport.endMarker);assert(!unmarkedReport.exactFileMatch);assert.equal(unmarkedReport.warnings.length,2);done('marker and hash differences are diagnostic warnings only');
 const previousVersion=served(read('Index.html').replaceAll('MORI_FRONTEND_BUILD:3.2.13','MORI_FRONTEND_BUILD:3.0.3').replaceAll('MORI_FRONTEND_END:3.2.13','MORI_FRONTEND_END:3.0.3'));h=harness(previousVersion.html);await h.flush();assert(h.elements.get('mori-auth'));done('older marker labels do not block otherwise identical frontend');
 // Simulate a processed HtmlOutput that differs from the source. No claim that
 // actual Google processing did this in the screenshot; test the access route.
 const rawReader=served();rawReader.ctx.HtmlService.createHtmlOutputFromFile=()=>{throw Error('Processed file read must not be used')};assert(rawReader.ctx.moriFrontendCheck().exactFileMatch);assert.match(rawReader.ctx.doGet({parameter:{}}).body,/window.MORI_BUILD="3.2.13"/);done('doGet and diagnostic read raw template source, not processed HtmlOutput');
 const hostile=served(undefined,{view:'shop"><script>alert(1)</script>',tab:'<script>',source:'<img>'}).html;
 assert.match(hostile,/data-mori-view="admin" data-mori-tab="home" data-mori-source=""/);assert(!hostile.includes('alert(1)'));done('route parameters stay allowlisted');
 assert(full.ctx.moriFrontendCheck().ok);assert(!served(read('Index.html')+'\n').ctx.moriFrontendCheck().exactFileMatch);done('frontend SHA-256 check detects pasted-content differences');
 const payload=full.ctx.moriFrontendRuntime();
 assert.equal(Buffer.from(payload.base64,'base64').toString('utf8'),scripts(read('Index.html')).at(-1).source);
 assert.equal(crypto.createHash('sha256').update(Buffer.from(payload.base64,'base64')).digest('hex'),payload.sha256);
 assert(full.html.length<145000);assert(!full.html.includes('doc.write('));assert(!full.html.includes('function moriStart('));
 assert(scripts(full.html).every(s=>s.source.length<10000));
 done('initial HTML contains only small scripts; RPC source is byte-identical to the original app closure');
 assert.throws(()=>full.ctx.moriFrontendRuntime('bad-digest'),/thay đổi/);done('server detects a changed runtime between HTML and RPC');
 h=harness(full.html,{handlers:{moriFrontendRuntime:null}});await h.timeout(20000);assert.match(h.elements.get('mori-boot-error').textContent,/moriFrontendRuntime/);assert(!h.elements.has('mori-loaded-runtime'));done('static runtime RPC timeout is visible, never executed');
 h=harness(full.html,{handlers:{moriFrontendRuntime:()=>new Error('Runtime read failed')}});await h.flush();assert.match(h.elements.get('mori-boot-error').textContent,/Runtime read failed/);done('runtime read exception is visible');
 h=harness(full.html,{handlers:{moriFrontendRuntime:()=>({...payload,base64:Buffer.from('window.__tampered=true;').toString('base64')})}});await h.flush();assert.match(h.elements.get('mori-boot-error').textContent,/SHA-256/);assert.equal(h.ctx.__tampered,undefined);assert(!h.elements.has('mori-loaded-runtime'));done('damaged runtime bytes are rejected before execution');
 h=harness(full.html,{handlers:{moriFrontendRuntime:()=>({...payload,sha256:'bad-digest'})}});await h.flush();assert.match(h.elements.get('mori-boot-error').textContent,/không khớp/);assert(!h.elements.has('mori-loaded-runtime'));done('mismatched runtime metadata is rejected before execution');
 h=harness(full.html,{handlers:{moriFrontendRuntime:()=>({...payload,base64:'not valid base64 %%'})}});await h.flush();assert(!h.elements.get('mori-boot').hidden);assert(!h.elements.has('mori-loaded-runtime'));done('invalid base64 yields a visible error');
 console.log('ALL STARTUP TESTS PASSED (Node VM, simulated DOM and RPC; no live deployment).');
})().catch(e=>{console.error(e);process.exitCode=1});

module.exports={harness,served,adminData,publicData,read,scripts};
