'use strict';
const {spawnSync}=require('child_process'),path=require('path');
const files=['startup.test.js','business.test.js','performance.test.js','frontend.test.js','planning.test.js','audit.test.js','planning-ui.test.js','forecast-fixes.test.js','forecast-money.test.js','forecast-fast.test.js','analytics.test.js','dashboard-migration.test.js','forecast-ui-cleanup.test.js','staff-customer.test.js','staff-login-publish-322.test.js','staff-publish-ui-322.test.js','performance-323.test.js','holiday-pricing-324.test.js','action-feedback-326.test.js','rounded-dropdown-327.test.js','catalog-dropdown-329.test.js','catalog-edit-3210.test.js','io-performance-3211.test.js','stock-rejection-3213.test.js'];
let groups=0;
for(const file of files){
 const result=spawnSync(process.execPath,[path.join(__dirname,file)],{encoding:'utf8',env:process.env});
 process.stdout.write(result.stdout||'');process.stderr.write(result.stderr||'');
 if(result.status!==0)process.exit(result.status||1);
 groups+=(result.stdout.match(/^PASS:/gm)||[]).length;
}
console.log(`COMPLETE: ${files.length} suites, ${groups} reported groups passed. All tests are local simulations.`);
