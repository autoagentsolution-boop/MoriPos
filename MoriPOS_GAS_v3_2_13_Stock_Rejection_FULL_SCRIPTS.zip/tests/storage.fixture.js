'use strict';
// In-memory implementations of the Sheets/Cache/Lock interfaces; not a latency model.
const fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto');
const cp=x=>JSON.parse(JSON.stringify(x));
const refs={Stores:['MASTER','Stores'],Branches:['MASTER','Branches'],Employees:['MASTER','Employees'],AccessControl:['MASTER','AccessControl'],Resources:['MASTER','Resources'],Promotions:['MASTER','Promotions'],Customers:['MASTER','Customers'],Settings:['MASTER','Settings'],PublishSite:['MASTER','PublishSite'],Items:['ITEMS','Items'],StockIn:['STOCKIN','StockIn'],Bills:['BILLS','SalesBills'],Booking:['BOOKING','Booking'],Attendance:['ATTENDANCE','Attendance'],Audit:['AUDIT','Audit'],ForecastPlans:['MASTER','ForecastPlans'],AnalyticsLedger:['DASHBOARD','AnalyticsLedger'],AnalyticsDaily:['DASHBOARD','AnalyticsDaily']};
const stamp='2026-11-05T00:00:00.000Z';
const rowFor=x=>[String(x.id),String(x.branchId||''),String(x.email||'').toLowerCase(),String(x.status||x.orderStatus||''),x.createdAt||stamp,x.updatedAt||stamp,x.version||1,JSON.stringify({...x,createdAt:x.createdAt||stamp,updatedAt:x.updatedAt||stamp,version:x.version||1})];
function fixture(root=path.resolve(__dirname,'..'),{bills=3000,items=80,clock=null}={}){
 const db={},props={MORI_READY:'1',MORI_OWNER_EMAIL:'owner@example.test',MORI_SEQ_BILL:String(bills),MORI_SEQ_AUDIT:'0',MORI_SEQ_STOCKIN:'40',MORI_SEQ_BOOKING:'40',MORI_SEQ_ATTENDANCE:'40'},cache=new Map(),events=[],counter={rpc:0,openById:0,getLastRow:0,find:0,getValues:0,rowsRead:0,setValues:0,rowsWritten:0,flush:0,propertyRead:0,propertyWrite:0};
 let locked=false,writeFailure=null,flushFailure=false,beforeLock=null;
 Object.keys(refs).forEach(t=>{db[t]=[(['AnalyticsDaily','AnalyticsLedger'].includes(t)?['id','branch_id','event_day','status','created_at','updated_at','version','data_json']:['id','branch_id','email','status','created_at','updated_at','version','data_json'])];props['MORI_FILE_'+refs[t][0]]=refs[t][0];});props.MORI_ANALYTICS_DASHBOARD_READY='1';
 const add=(t,x)=>{db[t].push(rowFor(x));return x;};
 const get=(t,id)=>{const r=db[t].find((r,i)=>i&&r[0]===String(id));return r?JSON.parse(r[7]):null;};
 const edit=(t,id,fn)=>{const j=db[t].findIndex((r,i)=>i&&r[0]===String(id));if(j<1)throw Error('missing seed');const x=JSON.parse(db[t][j][7]);fn(x);db[t][j]=rowFor(x);};
 add('AccessControl',{id:'owner@example.test',email:'owner@example.test',role:'ADMIN',branchIds:[1,2],isActive:true});
 add('AccessControl',{id:'staff@example.test',email:'staff@example.test',role:'EMPLOYEE',branchIds:[1],isActive:true});
 add('Stores',{id:1,name:'QC Store',address:'Test'});
 add('Branches',{id:1,name:'Branch 1',code:'CN01',isActive:true});add('Branches',{id:2,name:'Branch 2',code:'CN02',isActive:true});
 add('Employees',{id:'owner@example.test',email:'owner@example.test',role:'ADMIN',name:'Owner',branchId:1});
 add('Employees',{id:'staff@example.test',email:'staff@example.test',role:'EMPLOYEE',name:'Staff',branchId:1,salaryBase:123456});
 add('Customers',{id:1,name:'Guest',phone:'0900000000'});
 add('Settings',{id:'global',modules:{stockIn:true,onlineOrder:true,booking:true,attendance:true},lowStockPolicy:'WARN',receipt:{},paidBillEditRoles:{ADMIN:true}});
 add('PublishSite',{id:'site',published:false});
 for(let i=1;i<=items;i++)add('Items',{id:i,name:'Item '+i,cat:'Products',type:'PRODUCT',track:true,price:10000,cost:3000,stockByBranch:{'1':10000,'2':50},isActive:true});
 for(let i=1;i<=bills;i++)add('Bills',{id:i,no:'OLD-'+i,branchId:1,channel:'OFFLINE',status:'PAID',items:[{id:1,qty:1,unitPrice:10000}],inventoryConsumed:true,clientRequestId:'old-request-'+i,finalTotal:10000});
 for(const [table,count] of [['StockIn',40],['Booking',40],['Attendance',40]])for(let i=1;i<=count;i++)add(table,{id:i,branchId:1,email:'owner@example.test',status:'COMPLETED'});
 const cacheApi={get:k=>cache.get(k)||null,put:(k,v)=>cache.set(k,v),remove:k=>cache.delete(k)};
 function range(table,r,c,n,w){
  if(r<1||c<1||n<1||w<1)throw Error('invalid range');
  return {getRow:()=>r,
   setNumberFormat(){return this},getValues(){counter.getValues++;counter.rowsRead+=n;events.push({type:'read',table,row:r,rows:n,columns:w});return Array.from({length:n},(_,j)=>Array.from({length:w},(_,k)=>db[table][r+j-1]?.[c+k-1]??''));},
   setValues(values){
    if(values.length!==n||values.some(a=>a.length!==w))throw Error('shape mismatch');
    const event={type:'write',table,row:r,rows:n};
    if(writeFailure&&writeFailure(event)){writeFailure=null;events.push({...event,failed:true});throw Error('injected write failure');}
    values.forEach((a,j)=>{db[table][r+j-1]??=Array(8).fill('');a.forEach((v,k)=>db[table][r+j-1][c+k-1]=v);});
    counter.setValues++;counter.rowsWritten+=n;events.push(event);return this;
   },
   createTextFinder(pattern){let regex=false,entire=false,matchCase=false;
    function matching(){counter.find++;const matches=[];events.push({type:'find',table,column:c,pattern});
     for(let j=0;j<n;j++)for(let k=0;k<w;k++){const v=String(db[table][r+j-1]?.[c+k-1]??'');const p=regex?new RegExp(entire?'^(?:'+pattern+')$':pattern,matchCase?'':'i'):null;
      if(p?p.test(v):(entire?(matchCase?v===pattern:v.toLowerCase()===pattern.toLowerCase()):(matchCase?v.includes(pattern):v.toLowerCase().includes(pattern.toLowerCase()))))matches.push({getRow:()=>r+j});}
     return matches;
    }
    return {matchEntireCell(v){entire=v;return this},matchCase(v){matchCase=v;return this},useRegularExpression(v){regex=v;return this},findNext(){return matching()[0]||null},findAll:matching};
   }};
 }
 function sheet(table){return {getLastRow(){counter.getLastRow++;return db[table].length;},setFrozenRows(){return this},getRange:(r,c,n,w)=>typeof r==='string'?{setNumberFormat(){return this}}:range(table,r,c,n,w),deleteRows(r,n){db[table].splice(r-1,n);}};}
 function context(){
  const Clock=clock?class extends Date {constructor(...args){super(...(args.length?args:[clock]));}static now(){return new Date(clock).getTime();}}:Date;
  const ctx={console:{log(){},info(){},error(){},warn(){}},Date:Clock,JSON,Math,Set,Map,
   SpreadsheetApp:{openById(id){counter.openById++;return {getId:()=>id,getUrl:()=>`https://docs.google.com/spreadsheets/d/${id}/edit`,getSheets:()=>Object.keys(refs).filter(k=>refs[k][0]===id).map(k=>sheet(k)),deleteSheet(sh){},getSheetByName(name){const t=Object.keys(refs).find(k=>refs[k][0]===id&&refs[k][1]===name);return t&&db[t]?sheet(t):null;},insertSheet(name){const t=Object.keys(refs).find(k=>refs[k][0]===id&&refs[k][1]===name);if(!t)throw Error('Unexpected sheet');db[t]=[];return sheet(t);}};},flush(){counter.flush++;events.push({type:'flush'});if(flushFailure){flushFailure=false;throw Error('injected flush failure');}}},
   DriveApp:{getFileById:()=>({moveTo(){}}),getFolderById:()=>({})},
   PropertiesService:{getScriptProperties:()=>({getProperty:k=>{counter.propertyRead++;return props[k]??null;},setProperty:(k,v)=>{counter.propertyWrite++;props[k]=String(v);},getProperties:()=>({...props})})},
   CacheService:{getScriptCache:()=>cacheApi},MailApp:{sendEmail(){}},
   LockService:{getScriptLock:()=>({tryLock(){if(beforeLock){const fn=beforeLock;beforeLock=null;fn();}if(locked)return false;locked=true;events.push({type:'lock'});return true;},releaseLock(){locked=false;events.push({type:'unlock'});}})},
   Utilities:{DigestAlgorithm:{SHA_256:'sha256'},Charset:{UTF_8:'utf8'},getUuid:crypto.randomUUID,formatDate:(d,tz)=>new Intl.DateTimeFormat('en-CA',{timeZone:tz,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(d)),computeDigest:(alg,s)=>[...crypto.createHash(alg).update(s).digest()],base64EncodeWebSafe:b=>Buffer.from(b).toString('base64').replace(/\+/g,'-').replace(/\//g,'_')},
   ScriptApp:{getProjectTriggers:()=>[],newTrigger:()=>({timeBased(){return this},everyMinutes(){return this},create(){}}),deleteTrigger(){}},
   Session:{getActiveUser:()=>({getEmail:()=> 'owner@example.test'}),getEffectiveUser:()=>({getEmail:()=> 'owner@example.test'})}};
  vm.createContext(ctx);for(const name of ['Config.gs','Data.gs','Security.gs','Units.gs','ForecastCore.gs','AuditFormat.gs','Audit.gs','Analytics.gs','Forecast.gs','Inventory.gs','Billing.gs','Operations.gs','ApiRead.gs','Code.gs','Archive.gs'])if(fs.existsSync(path.join(root,name)))vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),ctx,{filename:name});
  return ctx;
 }
 const request=(name,...args)=>{counter.rpc++;const ctx=context();return cp(ctx[name](...cp(args)));};
 const session=(email='owner@example.test')=>{const token=crypto.randomUUID()+'-'+crypto.randomUUID(),ctx=context();cache.set(ctx.moriTokenKey_(token),JSON.stringify({email,at:stamp}));return token;};
 const otp=(email='owner@example.test',code='123456')=>{const ctx=context(),salt='fixture-salt',key=ctx.Utilities.base64EncodeWebSafe(ctx.Utilities.computeDigest('sha256',email)).slice(0,30);cache.set('mori:otp:'+key,JSON.stringify({salt,hash:ctx.Utilities.base64EncodeWebSafe(ctx.Utilities.computeDigest('sha256',code+':'+salt)),tries:0}));return [email,code];};
 const resetCounts=()=>{Object.keys(counter).forEach(k=>counter[k]=0);events.length=0;};
 return {db,props,cache,events,counter,add,get,edit,context,request,session,otp,resetCounts,setWriteFailure:fn=>writeFailure=fn,setFlushFailure:()=>flushFailure=true,setBeforeLock:fn=>beforeLock=fn,isLocked:()=>locked};
}
module.exports={fixture,cp};
