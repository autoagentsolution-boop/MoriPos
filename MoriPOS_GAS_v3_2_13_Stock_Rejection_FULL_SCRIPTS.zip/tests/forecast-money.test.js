/** Forecast currency and suggestion regression guards. */
'use strict';
const assert=require('assert'),fs=require('fs'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../Index.html'),'utf8');
const {harness,served}=require('./startup.test');
const log=x=>console.log('PASS:',x);
assert.match(html,/function moriReadVnd_\(/);assert.match(html,/function moriFormatVndInput_\(/);
assert.match(html,/function moriFormatVndField_\(/);
assert.match(html,/input\.dispatchEvent\(new Event\('input',\{bubbles:true\}\)\)/);
assert.match(html,/data-fc-config="extraFixedCosts" value="\$\{moriFormatVndInput_\(/);
assert.match(html,/data-fc-config="fixedCosts" value="\$\{moriFormatVndInput_\(/);
assert.match(html,/data-fc-line="\$\{i\}:\$\{j\}:price" value="\$\{moriFormatVndInput_\(/);
assert.match(html,/data-fc-extra="\$\{j\}" value="\$\{moriFormatVndInput_\(/);
log('money and suggested amounts are processed in Forecast by the same input/change path');
(async()=>{
 // Expose currency helpers in the offline browser simulation without altering actual file.
 const anchor='\n})();\n/* MORI_FRONTEND_END:';
 const injected=html.replace(anchor, '\nwindow.__moneyTest={read:moriReadVnd_,format:moriFormatVndInput_,formatField:moriFormatVndField_};'+anchor);
 const h=harness(served(injected).html);await h.flush();
 const money=h.ctx.__moneyTest;
 assert.equal(money.read('3.000.000'),3000000);
 assert.equal(money.read('1.000'),1000);
 assert.equal(money.read('-12.500'),-12500);
 assert.equal(money.format(3000000),'3.000.000');
 const input=h.ctx.document.createElement('input');input.dataset.fcMoney='1';input.value='3000000';
 assert.equal(money.formatField(input),3000000);assert.equal(input.value,'3.000.000');
 input.value='25000';assert.equal(money.formatField(input),25000);assert.equal(input.value,'25.000');
 log('currency parsing and rendering preserve 3,000,000 as integer VND');
 assert.equal(h.errors.length,0);
})().catch(e=>{console.error(e);process.exitCode=1});
