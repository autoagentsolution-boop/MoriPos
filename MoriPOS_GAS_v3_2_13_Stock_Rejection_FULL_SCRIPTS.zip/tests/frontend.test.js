'use strict';
const assert=require('assert');const {harness,served,adminData,read}=require('./startup.test');
function exposed(){
 const html=read('Index.html').replace('/* MORI_FRONTEND_END:3.1.3 */','/* MORI_FRONTEND_END:3.1.3 */');
 const marker='\n})();\n/* MORI_FRONTEND_END:';
 assert(html.includes(marker));
 // Add a test-only hook inside the real app closure, never to production Index.
 return served(html.replace(marker,'\nwindow.__moriTest={state,get busy(){return moriLiveBusy},get historyState(){return moriHistoryState},confirmPayment:(...a)=>confirmPayment(...a),applyDelta:moriApplyDelta,loadHistory:moriLoadHistory,render,renderPage,moriOfflinePayload,moriServerBill,moriWrite,moriMergeById,showLogin:moriShowLogin};'+marker)).html;
}
const item={id:1,name:'QC item',cat:'Goods',type:'PRODUCT',price:10000,stockByBranch:{1:20},version:1};
const core={...adminData,historyDeferred:true,items:[item]};
const paid={id:10,no:'CN01-PAID',branchId:1,channel:'OFFLINE',status:'PAID',paymentStatus:'CONFIRMED',items:[{id:1,qty:1,unitPrice:10000}],version:2,finalTotal:10000};
const response={ok:true,bill:paid,changes:{Bills:[paid],ItemUpdates:[{...item,stockByBranch:{1:19},version:2}],AuditUpdates:[]}};
const done=x=>console.log('PASS:',x);
(async()=>{
 let resolveHistory,resolvePay;
 const h=harness(exposed(),{handlers:{moriAuthVerify:()=>({token:'verified-token',data:core}),moriHistoryModule:()=>new Promise(r=>resolveHistory=r),moriCheckout:()=>new Promise(r=>resolvePay=r)}});await h.flush();
 h.elements.get('mori-auth-email').value='owner@example.test';h.elements.get('mori-auth-code').value='123456';await h.elements.get('mori-auth-login').onclick();await h.flush();
 assert.equal(h.calls.filter(x=>x.name==='moriAuthVerify').length,1);assert.equal(h.calls.filter(x=>['moriAuthWho','moriBootstrap','moriSessionBootstrap'].includes(x.name)).length,0);assert.match(h.elements.get('app').innerHTML,/QC item/);assert(!h.elements.has('mori-auth'));
 const ui=h.ctx.__moriTest;assert.equal(ui.historyState,'idle');assert.equal(h.calls.filter(x=>x.name==='moriHistoryModule').length,0);ui.state.page='overview';assert.match(ui.renderPage(),/Đang tải đơn hàng/);assert(!ui.renderPage().includes('Doanh thu đơn đã thanh toán'));
 await h.timeout(0);assert(resolveHistory);done('one OTP call opens POS before history; reports show a loading state instead of false zero totals');
 ui.state.page='sales';ui.state.tab='catalog';ui.state.bill.items=[{id:1,qty:1,unitPrice:10000}];ui.state.bill.version=17;ui.state.bill.method='BANK_TRANSFER';
 const first=ui.confirmPayment();await h.flush();assert(ui.busy);assert(resolvePay);assert.equal(ui.state.bill.status,'OPEN');assert.equal(ui.state.bill.items.length,1);assert(!ui.state.bills.some(b=>b.id===10));
 await ui.confirmPayment();assert.equal(h.calls.filter(x=>x.name==='moriCheckout').length,1);
 const sent=h.calls.find(x=>x.name==='moriCheckout').args[1];assert.equal(sent.id,undefined);assert.equal(sent.version,undefined);assert(sent.clientRequestId.length>=12);
 resolvePay(response);await first;await h.flush();assert(!ui.busy);assert.equal(ui.state.bill.items.length,0);assert(ui.state.bills.some(b=>b.id===10&&b.status==='PAID'));assert.equal(ui.state.items[0].stockByBranch[1],19);assert.equal(h.calls.filter(x=>x.name==='moriDelta').length,0);
 done('payment waits for commit, blocks duplicate clicks, and applies server result without a reload');
 resolveHistory({group:'Bills',bills:[{...paid,status:'OPEN',version:1}]});await h.flush();assert.equal(ui.historyState,'idle');assert.equal(ui.state.bills.find(b=>b.id===10).status,'PAID');assert.equal(ui.state.bill.items.length,0);const freshHistory=ui.loadHistory('Bills');resolveHistory({group:'Bills',bills:[paid]});await freshHistory;assert.equal(ui.historyState,'ready');done('late history is discarded after a newer payment; the next history load gets fresh data without resetting the cart');
 ui.applyDelta({Items:[{...item,stockByBranch:{1:20},version:1}]},false);assert.equal(ui.state.items[0].stockByBranch[1],19);done('stale catalog refresh cannot undo updated stock in the UI');
 const draft=ui.moriServerBill({...paid,status:'OPEN',version:3});draft.version=12;const outgoing=ui.moriOfflinePayload(draft);assert.equal(outgoing.version,3);assert(outgoing.persisted);done('local cart revision is separate from server version for reopened drafts');
 // A failed or lost response leaves the exact request ID available for manual retry.
 let attempt=0;const retry=harness(exposed(),{token:'valid',handlers:{moriSessionBootstrap:()=>({authenticated:true,data:core}),moriCheckout:()=>++attempt===1?new Error('response lost'):response}});await retry.flush();const r=retry.ctx.__moriTest;
 r.state.bill.items=[{id:1,qty:1,unitPrice:10000}];r.state.bill.method='BANK_TRANSFER';await r.confirmPayment();const key=r.state.bill.clientRequestId;assert(key);assert.equal(r.state.bill.items.length,1);await r.confirmPayment();assert.equal(retry.calls.filter(x=>x.name==='moriCheckout')[1].args[1].clientRequestId,key);assert.equal(r.state.bill.items.length,0);
 done('manual retry after response loss reuses request ID and preserves cart until success');
 // A background error leaves checkout active and offers a history retry.
 const failed=harness(exposed(),{token:'valid',handlers:{moriSessionBootstrap:()=>({authenticated:true,data:core}),moriHistoryModule:()=>new Error('history unavailable')}});await failed.flush();const fu=failed.ctx.__moriTest;fu.state.page='overview';fu.renderPage();await failed.timeout(0);await failed.flush();assert.equal(fu.historyState,'error');assert.match(fu.renderPage(),/mori-history-retry/);fu.state.page='sales';assert.match(fu.renderPage(),/QC item/);done('history failure does not block selling and is visible on dependent pages');
 // No response from a prior signed-in session may repopulate data after logout.
 let oldHistory;const stale=harness(exposed(),{token:'valid',handlers:{moriSessionBootstrap:()=>({authenticated:true,data:core}),moriHistoryModule:()=>new Promise(resolve=>oldHistory=resolve)}});await stale.flush();const su=stale.ctx.__moriTest;su.state.page='overview';su.renderPage();await stale.timeout(0);su.showLogin();oldHistory({group:'Bills',bills:[paid]});await stale.flush();assert(!su.state.bills.some(x=>x.id===10));assert(stale.elements.has('mori-auth'));done('history response from an older login is ignored');
 for(const x of [h,retry,failed,stale])assert.equal(x.errors.length,0);
 console.log('ALL FRONTEND TESTS PASSED (Node VM + DOM/RPC fixtures, not a live browser).');
})().catch(e=>{console.error(e);process.exitCode=1});
