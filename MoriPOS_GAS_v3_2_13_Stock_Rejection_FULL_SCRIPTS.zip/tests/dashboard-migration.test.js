'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm');
const root=path.resolve(__dirname,'..');
const headers=['id','branch_id','event_day','status','created_at','updated_at','version','data_json'];
function testEnvironment(mode='legacy'){
 const props={MORI_OWNER_EMAIL:'owner@example.test',MORI_READY:'1',MORI_FILE_MASTER:'MASTER',MORI_ROOT_FOLDER:'root'};
 if(mode==='existing')props.MORI_FILE_DASHBOARD='DASHBOARD';
 let nextId=0,workerBusy=false,failOn=null;
 const books={},copied=[];
 function book(id){
  const b={id,tabs:new Map(),getId(){return id},getUrl(){return 'https://docs.google.com/spreadsheets/d/'+id+'/edit'},
   getSheetByName(name){return this.tabs.get(name)||null},getSheets(){return [...this.tabs.values()]},
   insertSheet(name){if(this.tabs.has(name))throw Error('duplicate sheet '+name);const sh=sheet(this,name,[]);this.tabs.set(name,sh);return sh},
   deleteSheet(sh){assert.equal(this.tabs.get(sh.name),sh);this.tabs.delete(sh.name)}
  };books[id]=b;return b;
 }
 function sheet(parent,name,rows){return {parent,name,rows,
  getName(){return this.name},getLastRow(){return this.rows.length},setFrozenRows(){return this},
  getRange(row,col,count,width){if(typeof row==='string')return {setNumberFormat(){return this}};
   return {getValues:()=>Array.from({length:count},(_,i)=>Array.from({length:width},(_,j)=>this.rows[row+i-1]?.[col+j-1]??'')),setValues:values=>{values.forEach((r,i)=>{this.rows[row+i-1]??=Array(8).fill('');r.forEach((v,j)=>this.rows[row+i-1][col+j-1]=v)});return this}};
  },copyTo(destination){if(failOn===name)throw Error('injected copy failure '+name);
   const newName='Copy of '+name+' '+(++nextId);const copy=sheet(destination,newName,this.rows.map(r=>[...r]));destination.tabs.set(newName,copy);copied.push(name);return copy;
  },setName(next){if(this.parent.tabs.has(next))throw Error('target name exists '+next);this.parent.tabs.delete(this.name);this.name=next;this.parent.tabs.set(next,this);return this;}
 };
 }
 function doc(id){return [id,'1','2026-11-05','ACTIVE','2026-11-05','2026-11-05',1,JSON.stringify({id,qty:2})]}
 const master=book('MASTER');master.tabs.set('Stores',sheet(master,'Stores',[['id','branch_id','email','status','created_at','updated_at','version','data_json']]));
 if(mode!=='fresh')for(const t of ['AnalyticsLedger','AnalyticsDaily'])master.tabs.set(t,sheet(master,t,[headers,doc(t+'-a'),doc(t+'-b')]));
 if(mode==='existing'){
  const dash=book('DASHBOARD');dash.insertSheet('Sheet1');
  dash.insertSheet('AnalyticsLedger');dash.getSheetByName('AnalyticsLedger').rows.push(headers,doc('AnalyticsLedger-a'),doc('AnalyticsLedger-b'));
 }
 let lockHeld=false;
 const ctx={console:{error(){},log(){}},Date,JSON,Math,Set,Map,
   PropertiesService:{getScriptProperties:()=>({getProperty:k=>props[k]??null,setProperty:(k,v)=>{props[k]=String(v)},getProperties:()=>({...props})})},
   SpreadsheetApp:{openById:id=>{if(!books[id])throw Error('unknown workbook '+id);return books[id]},create(name){assert.equal(name,'POS_Dashboard');const id='CREATED_'+(++nextId);const b=book(id);b.insertSheet('Sheet1');return b}},
   DriveApp:{getFileById:()=>({moveTo(folder){assert.equal(folder.id,'root')}}),getFolderById:id=>({id})},
   Session:{getActiveUser:()=>({getEmail:()=> 'owner@example.test'}),getEffectiveUser:()=>({getEmail:()=> 'owner@example.test'})},
   LockService:{getScriptLock:()=>({tryLock(){if(lockHeld)return false;lockHeld=true;return true},releaseLock(){lockHeld=false}})},
   ScriptApp:{getProjectTriggers:()=>[],newTrigger:()=>({timeBased(){return this},everyMinutes(n){assert.equal(n,5);return this},create(){}}),deleteTrigger(){}},
   Utilities:{getUuid:()=>String(++nextId).padStart(8,'0')},
   MORI_BOOK_HANDLES_:{},MORI_SHEET_HANDLES_:{},MORI_DATA_STATE_:{},Logger:{log(){}}
 };
 vm.createContext(ctx);for(const f of ['Config.gs','Data.gs','Analytics.gs'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),ctx,{filename:f});
 return {ctx,props,books,master,copied,fail(name){failOn=name},unfail(){failOn=null},busy(v){workerBusy=v}};
}
{
 const e=testEnvironment();e.props.MORI_ANALYTICS_STATE_V1=JSON.stringify({installed:true,ready:true,backfillComplete:true});
 assert.equal(e.ctx.moriAnalyticsReady_(),false);
 assert.throws(()=>e.ctx.moriAnalyticsRequireReady_(),/POS_Dashboard/);
 const r=e.ctx.moriAnalyticsInstall();
 assert.equal(r.ok,true);assert.equal(r.dashboard.created,true);assert.equal(r.dashboard.sourceRows.AnalyticsLedger,2);
 const dash=e.books[e.props.MORI_FILE_DASHBOARD];assert(dash);assert.notEqual(dash.getId(),e.master.getId());
 for(const t of ['AnalyticsLedger','AnalyticsDaily']){
  assert.deepEqual(dash.getSheetByName(t).rows,e.master.getSheetByName(t).rows);
  assert.equal(e.ctx.MORI_TABLES[t][0],'DASHBOARD');
  assert.equal(e.ctx.moriSheet_(t),dash.getSheetByName(t));
 }
 assert.equal(e.ctx.moriAnalyticsReady_(),true);
 assert.equal(e.ctx.moriAnalyticsStatus().dashboardReady,true);
 assert.match(e.ctx.moriAnalyticsStatus().dashboardUrl,/CREATED_/);
 // Post-cutover writes belong only to POS_Dashboard. Re-running install must not
 // overwrite them using stale legacy copies in POS_Master.
 dash.getSheetByName('AnalyticsDaily').rows.push(['NEW','1','2026-11-06','ACTIVE','','',1,'{}']);
 e.ctx.moriAnalyticsInstall();assert.equal(dash.getSheetByName('AnalyticsDaily').getLastRow(),4);
 assert.equal(e.master.getSheetByName('AnalyticsDaily').getLastRow(),3);
 console.log('PASS: legacy Analytics tabs copy to independent POS_Dashboard, preserving rows and rerun safety');
}
{
 const e=testEnvironment();e.fail('AnalyticsDaily');
 assert.throws(()=>e.ctx.moriAnalyticsInstall(),/injected copy failure/);
 assert.equal(e.props.MORI_ANALYTICS_DASHBOARD_READY,undefined);
 assert.equal(e.ctx.moriAnalyticsReady_(),false);
 assert.equal(e.master.getSheetByName('AnalyticsLedger').getLastRow(),3);
 e.unfail();const r=e.ctx.moriAnalyticsInstall();
 assert.equal(r.ok,true);assert.equal(r.dashboard.targetRows.AnalyticsDaily,2);
 assert.equal(e.ctx.moriAnalyticsDashboardReady_(),true);
 console.log('PASS: partially failed migration stays unpublished and resumes without duplicate ledgers');
}
{
 const e=testEnvironment('fresh');const result=e.ctx.moriAnalyticsInstall();
 const target=e.books[e.props.MORI_FILE_DASHBOARD];assert(result.dashboard.created);
 for(const t of ['AnalyticsLedger','AnalyticsDaily'])assert.deepEqual(target.getSheetByName(t).rows,[headers]);
 assert.equal(target.getSheetByName('Sheet1'),null);
 assert.equal(e.master.getSheetByName('AnalyticsLedger'),null);
 console.log('PASS: new installation creates two analytics tables only inside POS_Dashboard');
}
{
 const e=testEnvironment('existing');
 e.books.DASHBOARD.getSheetByName('AnalyticsLedger').rows[2][7]='{\"tampered\":true}';
 assert.throws(()=>e.ctx.moriAnalyticsInstall(),/không khớp/);
 assert.equal(e.props.MORI_ANALYTICS_DASHBOARD_READY,undefined);
 console.log('PASS: conflicting existing dashboard data is rejected without overwriting source');
}
{
 const e=testEnvironment();e.props.MORI_FILE_DASHBOARD='MASTER';
 assert.throws(()=>e.ctx.moriAnalyticsInstall(),/không được trỏ vào POS_Master/);
 assert.equal(e.ctx.moriAnalyticsDashboardReady_(),false);
 console.log('PASS: dashboard cannot share the POS_Master spreadsheet ID');
}
