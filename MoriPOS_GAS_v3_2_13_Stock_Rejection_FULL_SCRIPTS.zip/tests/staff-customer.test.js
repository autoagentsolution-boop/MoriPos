'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto'),assert=require('assert');
const root=path.resolve(__dirname,'..'),db={},props={MORI_READY:'1',MORI_OWNER_EMAIL:'owner@example.test',MORI_CUSTOMERS_READY:'1',MORI_FILE_CUSTOMERS:'cust',MORI_CUSTOMER_BACKFILL_COMPLETE:'1',MORI_CUSTOMER_INITIAL_READY:'1'},cache=new Map(),emails=[];let seq=0;
const cp=x=>x==null?x:JSON.parse(JSON.stringify(x));
const save=(t,x)=>{db[t]??=[];const i=db[t].findIndex(v=>String(v.id)===String(x.id));if(i>=0){const v=cp(x);v.version=db[t][i].version+1;db[t][i]=v;return cp(v);}const v=cp(x);v.version=1;db[t].push(v);return cp(v);};
const get=(t,id)=>cp((db[t]||[]).find(x=>String(x.id)===String(id))||null);
const actor={email:'owner@example.test',role:'ADMIN',branchIds:[1,2]};
const asBytes=x=>[...crypto.createHash('sha256').update(x).digest()].map(v=>v>127?v-256:v);
const ctx={console,Date,JSON,Math,Set,Map,
 PropertiesService:{getScriptProperties:()=>({getProperty:k=>props[k]??null,setProperty:(k,v)=>props[k]=String(v)})},
 CacheService:{getScriptCache:()=>({get:k=>cache.get(k)||null,put:(k,v)=>cache.set(k,v),remove:k=>cache.delete(k)})},
 Utilities:{DigestAlgorithm:{SHA_256:'sha256'},Charset:{UTF_8:'utf8'},getUuid:()=>crypto.randomUUID(),computeDigest:(alg,value)=>asBytes(value),base64EncodeWebSafe:bytes=>Buffer.from(bytes.map(x=>(x+256)%256)).toString('base64url'),formatDate:d=>new Date(d).toISOString().slice(0,10)},
 MailApp:{sendEmail:x=>emails.push(x)},
};vm.createContext(ctx);
for(const name of ['Config.gs','Security.gs','StaffAccess.gs','CustomerIdentity.gs','CustomerAnalytics.gs'])vm.runInContext(fs.readFileSync(path.join(root,name),'utf8'),ctx,{filename:name});
Object.assign(ctx,{
 moriAll_:t=>cp(db[t]||[]),moriFind_:(t,id)=>get(t,id),
 moriInsert_:(t,x)=>{assert(!get(t,x.id));return save(t,x)},
 moriPut_:(t,x,version)=>{const old=get(t,x.id);assert(old);if(version!==undefined)assert.equal(old.version,version,'CAS');return save(t,x)},
 moriAudit_:()=>{},moriNext_:()=>++seq,moriLock_:fn=>fn(),
 moriSheet_:t=>({getLastRow:()=>1+(db[t]||[]).length,getRange:(row,col,n)=>({getValue:()=>JSON.stringify(db[t]?.[row-2]||null),getValues:()=>Array.from({length:n||1},(_,j)=>[JSON.stringify(db[t]?.[row-2+j]||null)]),createTextFinder:pattern=>({matchCase(){return this},matchEntireCell(){return this},findAll(){return (db[t]||[]).map((x,i)=>({x,i})).filter(z=>z.x.email===pattern).map(z=>({getRow:()=>z.i+2}));}})})}),
 moriForecastDay_:s=>s,moriDate_:d=>new Date(d).toISOString().slice(0,10)
});
for(const doc of [{id:'owner@example.test',email:'owner@example.test',name:'Owner',role:'ADMIN',branchIds:[1],isActive:true},{id:'staff@example.test',email:'staff@example.test',name:'Staff',role:'EMPLOYEE',branchIds:[1],isActive:true}])save('AccessControl',doc);
save('Employees',{id:'owner@example.test',email:'owner@example.test',name:'Owner',branchId:1});
save('Employees',{id:'staff@example.test',email:'staff@example.test',name:'Staff',branchId:1});
save('Branches',{id:1,isActive:true});save('Branches',{id:2,isActive:true});
function tokenFor(email){const t=crypto.randomUUID()+'-'+crypto.randomUUID();cache.set(ctx.moriTokenKey_(t),JSON.stringify({email}));return t;}
const ownerToken=tokenFor('owner@example.test'),staffToken=tokenFor('staff@example.test');
assert.equal(ctx.moriActor_(staffToken).role,'EMPLOYEE');
assert.throws(()=>ctx.moriStaffSave(staffToken,{email:'stranger@example.test',name:'Intruder',role:'MANAGER',branchIds:[1]}),/Không đủ quyền/);
const newly=ctx.moriStaffSave(ownerToken,{email:'new@example.test',name:'New manager',role:'MANAGER',branchIds:[1,2],active:true});
assert.equal(newly.role,'MANAGER');assert.deepEqual([...get('AccessControl','new@example.test').branchIds],[1,2]);
assert.throws(()=>ctx.moriStaffSave(ownerToken,{email:'evil@example.test',name:'Evil admin',role:'ADMIN',branchIds:[1]}),/Không được cấp vai trò Admin/);
assert.throws(()=>ctx.moriStaffSave(ownerToken,{email:'owner@example.test',name:'Owner',role:'EMPLOYEE',branchIds:[1],active:false}),/Không được cấp vai trò Admin|Không được đổi/);
const disabled=ctx.moriStaffSave(ownerToken,{...newly,active:false});assert.equal(disabled.active,false);
const newToken=tokenFor('new@example.test');assert.throws(()=>ctx.moriActor_(newToken),/thu hồi/);
console.log('PASS: A staff allowlist, 2 branches, ADMIN-only changes, no role escalation, live revocation');
// Unknown staff cannot obtain OTP and cannot use a verified customer token for POS.
const beforeMail=emails.length;assert.throws(()=>ctx.moriAuthStart('outsider@example.test'),/chưa được cấp quyền/);assert.equal(emails.length,beforeMail);
assert.throws(()=>ctx.moriAuthStart('new@example.test'),/tạm khóa/);assert.equal(emails.length,beforeMail);
const email='guest@example.test';ctx.moriCustomerAuthStart(email);assert.equal(emails.length,beforeMail+1);const sent=emails.at(-1);const otp=sent.body.match(/\d{6}/)[0];
assert.throws(()=>ctx.moriCustomerAuthVerify(email,'000000'),/Mã xác thực không đúng/);
const result=ctx.moriCustomerAuthVerify(email,otp);assert(result.token);assert.equal(result.profile.member,null);
assert.throws(()=>ctx.moriActor_(result.token),/hết hạn/);
assert.equal(ctx.moriCustomerActor_(result.token).email,email);
console.log('PASS: B customer email OTP and verified-only customer session, no staff-token escalation');
// No unverified order may be borrowed by just claiming its email.
const anonymous={id:21,branchId:1,channel:'ONLINE',shipping:{email},status:'PAID',paymentStatus:'CONFIRMED',createdAt:'2026-11-05T09:00:00Z',paidAt:'2026-11-05T09:01:00Z',finalTotal:45000,items:[{name:'Tea',qty:1}]};
assert.equal(ctx.moriCustomerProcessBill_(anonymous).linked,false);
const verified={...anonymous,id:22,guestIdentityId:ctx.moriCustomerActor_(result.token).id,finalTotal:60000};
ctx.moriCustomerProcessBill_(verified);ctx.moriCustomerRebuildDay_('1|2026-11-05');
let daily=get('CustomerDaily','1|2026-11-05|GUEST');assert.equal(daily.orders,1);assert.equal(daily.revenue,60000);assert.equal(daily.newCustomers,1);
let history=ctx.moriCustomerOrders(result.token,1,20);assert.equal(history.total,1);assert.equal(history.rows[0].billId,22);
const before=ctx.moriCustomerGuestLookup(ownerToken,result.token);assert.equal(before.onlineHistoryCount,1);
const member=ctx.moriCustomerMemberSave(ownerToken,{name:'Guest Member',phone:'0901234567',email,customerProofToken:result.token,branchId:1});
assert(member.linked);assert.equal(ctx.moriCustomerSession(result.token).member.id,member.id);
assert.throws(()=>ctx.moriCustomerMemberSave(ownerToken,{name:'Duplicate',phone:'0901234567',branchId:1}),/đã tồn tại/);
ctx.moriCustomerRebuildDay_('1|2026-11-05');
assert.equal(get('CustomerDaily','1|2026-11-05|MEMBER').orders,1);
assert.equal(get('CustomerDaily','1|2026-11-05|GUEST').orders,0);
props.MORI_CUSTOMER_LAST_SYNC='2026-11-06T00:00:00Z';
const summary=ctx.moriCustomerAnalyticsQuery(ownerToken,{branchId:1,startDate:'2026-11-01',endDate:'2026-11-06'}).summary;
assert.equal(summary.memberRevenue,60000);assert.equal(summary.memberOrders,1);assert.equal(summary.guestRevenue,0);
const staffAnalytics=()=>ctx.moriCustomerAnalyticsQuery(staffToken,{branchId:1,startDate:'2026-11-01',endDate:'2026-11-06'});
assert.throws(staffAnalytics,/Không đủ quyền/);
console.log('PASS: C daily sales materialization, Guest-to-Member reclassification, no double counting, authorized dashboard');
assert.equal(ctx.moriCustomerCanArchive_(),false);
props.MORI_CUSTOMER_INITIAL_READY='0';assert.equal(ctx.moriCustomerCanArchive_(),false); // Pending day work keeps archive blocked.
assert.throws(()=>ctx.moriCustomerAnalyticsQuery(ownerToken,{branchId:1,startDate:'2026-11-01',endDate:'2026-11-06'}),/đang đồng bộ/);
ctx.moriEditorOnly_=()=>{};
const replay=ctx.moriCustomerRepairStart();assert.equal(replay.ok,true);assert.equal(props.MORI_CUSTOMER_BACKFILL_CURSOR,'2');
assert.equal(ctx.moriCustomerCanArchive_(),false);
console.log('PASS: migration/repair state prevents incomplete dashboard publication and blocks unsafe archive during replay');
