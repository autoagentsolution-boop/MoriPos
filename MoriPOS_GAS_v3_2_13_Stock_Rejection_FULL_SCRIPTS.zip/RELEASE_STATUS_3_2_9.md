# MoriPOS 3.2.9

Gói mã đầy đủ, sẵn sàng cập nhật từ v3.2.8. Chưa triển khai lên Web App của người dùng.

Hai file runtime thay đổi: `Index.html`, `Code.gs`.

Phạm vi: dropdown định lượng đồng nhất theo Mori, loading tại nút, tối ưu lượt gọi sau lưu danh mục, giữ định lượng Sản phẩm/Dịch vụ trong form và bản ghi được xác nhận.

Các module tính toán và backend nghiệp vụ khớp byte với nguồn v3.2.8. Không thay đổi schema, phép tính giá combo hoặc Forecast.

Hướng dẫn: `README_UPGRADE_3_2_9.md`.
