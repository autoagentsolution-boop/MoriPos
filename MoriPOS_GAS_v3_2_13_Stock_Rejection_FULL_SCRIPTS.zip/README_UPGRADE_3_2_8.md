# MoriPOS 3.2.8 — Shared Mori Dropdown Fix

**Update only** `Index.html` and `Code.gs` if currently running v3.2.7.

## What changed
- Reuses the **existing MoriPOS** `.combo-trigger` / `.combo-popover` / `.combo-option` for all single-select fields, instead of individual rounded variants.
- Branch multi-select uses the same shared combo menu; each click toggles a branch without closing it.
- Opening a dropdown no longer automatically focuses/highlights the first item.
- Selected option is indicated by a check mark, not confused with mouse hover.
- Mouse hover only highlights while pointing at an option; keyboard focus highlight only appears during keyboard navigation.
- The original hidden `<select>` still receives `change`, preserving the same business logic and Google Sheets storage.

## Deployment
1. Back up your Apps Script project.
2. Replace `Index.html`, `Code.gs` with this bundle.
3. Run `moriFrontendCheck()` to verify `build: 3.2.8` and `exactFileMatch: true`.
4. Deploy > Manage deployments > Edit > New version > Deploy.
5. Test role Manager, multi-branch, item status, holiday pricing, annual holiday recurrence and saving settings.

No database migration or server API changes. Verify on a staging deployment first.
