/** Mori 3.2.0 A - staff access is assigned by an ADMIN, never inferred from Employees alone. */
function moriStaffEmail_(email){email=String(email||'').trim().toLowerCase();moriEnsure_(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)&&email.length<=180,'Email nhân viên không hợp lệ');return email;}
function moriStaffList(token){
 var actor=moriActor_(token);moriRequire_(actor,['ADMIN']);
 var access=moriAll_('AccessControl',true),employees=moriAll_('Employees',true),byEmail={};
 employees.forEach(function(e){byEmail[String(e.email||e.id).toLowerCase()]=e;});
 return access.map(function(a){var x=byEmail[String(a.email).toLowerCase()]||{};return {
  email:a.email,name:a.name||x.name||a.email,role:a.role,branchIds:(a.branchIds||[]).map(Number),active:a.isActive!==false,
  phone:x.phone||'',payType:x.payType||'',rate:Number(x.rate)||0,salaryBase:Number(x.salaryBase)||0,
  version:a.version||1,employeeVersion:x.version||0,owner:a.email===moriProp_('OWNER_EMAIL')
 };}).sort(function(a,b){return (a.owner?-1:0)-(b.owner?-1:0)||a.email.localeCompare(b.email);});
}
function moriStaffSave_(actor,p){
 moriRequire_(actor,['ADMIN']);p=p||{};
 var email=moriStaffEmail_(p.email||p.id),role=String(p.role||'EMPLOYEE').toUpperCase(),name=String(p.name||'').trim(),owner=moriProp_('OWNER_EMAIL');
 moriEnsure_(['MANAGER','EMPLOYEE'].indexOf(role)>=0||email===owner&&role==='ADMIN','Không được cấp vai trò Admin từ giao diện');
 moriEnsure_(name.length>=2&&name.length<=120,'Tên nhân viên phải từ 2 đến 120 ký tự');
 var branches=Array.isArray(p.branchIds)?p.branchIds.map(Number):[Number(p.branchId)];
 branches=Array.from(new Set(branches.filter(function(id){return Number.isInteger(id)&&id>0;})));
 moriEnsure_(branches.length>=1&&branches.length<=20,'Chọn ít nhất một chi nhánh');
 branches.forEach(function(id){var b=moriFind_('Branches',id);moriEnsure_(b&&b.isActive!==false,'Chi nhánh không tồn tại hoặc ngừng hoạt động');});
 var active=p.active!==false,old=moriFind_('AccessControl',email),oldEmp=moriFind_('Employees',email);
 if(email===owner){moriEnsure_(role==='ADMIN'&&active,'Không được đổi hoặc vô hiệu hóa Owner');}
 else moriEnsure_(role!=='ADMIN','Chỉ Owner có quyền Admin');
 if(old&&old.role==='ADMIN'&&email!==owner)throw Error('Tài khoản Admin khác cần kiểm tra thủ công');
 if(old&&p.version!==undefined)moriEnsure_(Number(old.version)===Number(p.version),'VERSION_CONFLICT: Phân quyền đã thay đổi');
 var employee=oldEmp?moriDeep_(oldEmp):{id:email,email:email},acl=old?moriDeep_(old):{id:email,email:email};
 Object.assign(employee,{email:email,name:name,phone:String(p.phone||'').trim().slice(0,25),role:role,branchId:branches[0],branchIds:branches,isActive:active});
 if(p.payType!==undefined)employee.payType=String(p.payType);
 if(p.rate!==undefined)employee.rate=Math.max(0,Number(p.rate)||0);
 if(p.salaryBase!==undefined)employee.salaryBase=Math.max(0,Number(p.salaryBase)||0);
 // Employees first: if second write fails, ACL remains authoritative and does not gain access.
 employee=oldEmp?moriPut_('Employees',employee,p.employeeVersion??oldEmp.version):moriInsert_('Employees',employee);
 Object.assign(acl,{email:email,name:name,role:role,branchIds:branches,isActive:active});
 acl=old?moriPut_('AccessControl',acl,p.version??old.version):moriInsert_('AccessControl',acl);
 moriAudit_(actor.email,old?'UPDATE':'CREATE','STAFF_ACCESS',email,old,acl);
 return {email:email,name:name,role:role,branchIds:branches,active:active,version:acl.version,employeeVersion:employee.version};
}
function moriStaffSave(token,p){return moriLock_(function(){return moriStaffSave_(moriActor_(token),p);});}
