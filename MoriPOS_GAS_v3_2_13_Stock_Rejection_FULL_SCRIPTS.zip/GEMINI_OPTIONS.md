# Khả năng tích hợp Gemini trên Google Apps Script (chưa bật)

**MoriPOS 3.2.3 chưa gửi dữ liệu nào đến Gemini và không yêu cầu Gemini API key.**

## Hai cách triển khai

1. Google AI Studio / Gemini API qua Apps Script `UrlFetchApp.fetch(...)`, dùng API key lưu trong **Script Properties**, tuyệt đối không đưa vào `Index.html`. Hiện Gemini có Interactions API và API generateContent, chọn API phù hợp và model đang được hỗ trợ tại thời điểm triển khai.
2. Apps Script Advanced Service cho Vertex AI/Google Cloud, yêu cầu Google Cloud project có billing và quyền phù hợp.

## Tác vụ nên dùng

- Giải thích KPI từ `POS_Dashboard.AnalyticsDaily` hoặc `CustomerDaily` (đã lọc dữ liệu nhận dạng); ví dụ lý do doanh thu tuần này giảm.
- Đưa gợi ý từ 3 kịch bản Forecast; không thay công thức giá vốn/doanh thu bằng dự đoán mô hình.
- Gợi ý các sản phẩm cần theo dõi tồn kho, combo khuyến mãi, nội dung quảng cáo.

## Cách an toàn

- Backend định dạng **snapshot đã tổng hợp**, ví dụ `{period, revenue, cogs, growthPct, topProducts}`; không gửi số điện thoại/email, OTP, mã ngân hàng hay token.
- Gemini trả nhận xét và khuyến nghị. Admin xác nhận trước khi thay giá, tồn, ngân sách hay gửi chiến dịch.
- Rate limit, circuit breaker, cache kết quả 5–15 phút, log số token/chi phí, và nút bật/tắt module.
- Nếu Gemini API lỗi, POS / thanh toán phải vẫn hoạt động hoàn toàn độc lập.

Nguồn chính thức:
- https://ai.google.dev/gemini-api/docs/get-started
- https://developers.google.com/apps-script/advanced/vertex-ai
- https://developers.google.com/apps-script/reference/url-fetch
- https://ai.google.dev/gemini-api/docs/rate-limits
