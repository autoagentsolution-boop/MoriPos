# MoriPOS 3.2.10

Gói mã đầy đủ cho cập nhật từ v3.2.9. Chưa triển khai lên Web App của người dùng.

Runtime thay đổi: **Index.html**, **Code.gs**, **Operations.gs**.

Chức năng: chỉnh đơn vị khai báo, chỉnh Loại trong form sửa mặt hàng, lọc danh mục kết hợp trạng thái bán. Đổi đơn vị giữ nguyên các số liệu đã nhập; không phải thao tác quy đổi hàng tồn hàng loạt.

Giữ nguyên mã tính giá combo và Forecast. Không đổi schema. Kiểm tra: 22 bộ, 174 nhóm PASS trong mô phỏng Node/DOM/Sheets.

Hướng dẫn: `README_UPGRADE_3_2_10.md`.
