# MoriPOS v3.2.3 — Performance & Lazy Data Loading

## Phạm vi

Phiên bản này nâng cấp từ v3.2.2. Không tạo bảng mới, không di chuyển Google Sheets, không chạy lại Setup. **Không bật Gemini**; hướng dẫn Gemini nằm trong `GEMINI_OPTIONS.md`.

### Các thay đổi thực tế

1. **Core bootstrap:** Không đọc toàn bộ `Customers` trong request OTP + mở cửa hàng. Dữ liệu cửa hàng, quyền nhân viên, chi nhánh và catalog vẫn tải để vào POS.
2. **History theo màn hình:** Thêm API `moriHistoryModule(token, group)`; các nhóm được phép: `Bills`, `StockIn`, `Booking`, `Attendance`, `Audit`, `Customers`. Phần Audit yêu cầu Admin. Mỗi màn hình chỉ đọc nhóm cần thiết khi mở, không tải chung 5 bảng sau login.
3. **POS catalog trước:** Trên trang Bán hàng / Danh mục, không tự gọi History. Khi chọn Lịch sử bill, hệ thống tải Bills. Khi chuyển sang trang Nhập kho, Đặt lịch, Khách hàng, Chấm công, Nhật ký thì tải tương ứng.
4. **Customer lookup:** Thêm `moriCustomerLookup(token, 'email'|'phone', value)` để tìm đúng bản ghi và trả về bản ghi đã chiếu quyền. Dùng Google Sheets TextFinder: **chưa phải index dữ liệu O(1)**. Danh sách đầy đủ vẫn có thể tải khi người dùng chủ động mở trang Khách hàng hoặc bộ chọn khách.
5. **Refresh:** Poll mỗi 3 phút chỉ yêu cầu nhóm phù hợp trang hiện tại; không cố quét Bills+Booking khi chỉ ở Forecast/Settings.
6. **Checkout:** Giữ nguyên `moriLock_`, idempotency, inventory reservation, ghi bill và audit; bổ sung `authMs`/`commitMs` vào `moriCheckout().timing`. Code hiện tại đã batch các dòng cập nhật Items liền kề; không dời bước ghi thanh toán quan trọng sang worker.
7. **Diagnostics:** `moriPerformanceProbe323()` chỉ chạy thủ công trong Editor với tài khoản Owner, trả thời gian đọc một số nhóm; không trả dữ liệu cá nhân.

### Những gì chưa thay đổi

- Chưa có bảng lookup index vật lý. ID đã được tìm bằng TextFinder, nhưng số dòng lớn vẫn ảnh hưởng tốc độ.
- Chưa chuyển trang Báo cáo tài chính sang API hoàn toàn dựa trên `AnalyticsDaily`; vẫn tải Bills lịch sử khi người dùng mở Báo cáo. Đây là bước tối ưu tiếp theo.
- Chưa chia JS bundle lớn thành nhiều file runtime: bản hiện tại vẫn dùng một `Index.html` có loader SHA-256; thay đổi phương thức tải JS có rủi ro white screen nên không thực hiện trong bản này.
- Không bỏ giao dịch đồng bộ/khóa ghi để đổi lấy tốc độ.
- Không thay đổi logic OTP hay phân quyền.

## Deploy (từ 3.2.2)

1. Backup Apps Script và toàn bộ Spreadsheet.
2. Dùng **Quick Patch** để thay: `ApiRead.gs`, `Billing.gs`, `Index.html`, `Code.gs`. Thêm `MoriPreflight323.gs`, `Performance323.gs`.
3. Nếu có file kiểm tra phiên bản cũ, bạn có thể giữ nguyên hoặc xóa `MoriPreflight322.gs`; **chạy `moriPreflight323()`**.
4. Chạy `moriFrontendCheck()` kiểm tra `exactFileMatch: true` và `build: '3.2.3'`.
5. Vào **Deploy → Manage deployments → Edit → New version → Deploy**.
6. Tải lại `/exec`. Test login Admin, Employee, checkout, lịch sử bill, nhập kho, bookings, customer, attendance, audit, Publish Site. Test logout / revocation.
7. Trong Apps Script Editor, chạy `moriPerformanceProbe323()` ở thời điểm không cao điểm để đo thời gian thật; kiểm tra **Executions** / trình duyệt `window.MoriPerformance` cho số liệu thực tế.

> Không chạy `moriSetup()` hoặc migration khi nâng cấp v3.2.3.

## Regression / rollback

- Đã kiểm thử 17 suite, 145 PASS (local mock, **không phải kết quả benchmark production**).
- Gói được đồng bộ SHA-256 giữa Index và Code. Kiểm thử sản xuất do owner thực hiện.
- Rollback: Manage deployments → Edit → chọn previous version 3.2.2; Google Sheets không bị migrate ở lần nâng cấp này.

## Lưu ý tính toàn vẹn và bảo mật

- Mọi API đều xác minh token/ACL trên backend. Xóa quyền hiệu lực ngay từ lần gọi API kế tiếp.
- `moriHistoryModule` cố định tập nhóm được tải, có giới hạn số bản ghi/nhóm; không nhận tên bảng tùy ý.
- Giữ `ClientRequestId` khi retry thanh toán; không tạo retry tự động cho API ghi.
- Không đưa dữ liệu khách/bill vào log hiệu năng; chỉ log tên API và mili-giây.
