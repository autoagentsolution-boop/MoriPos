# Mori POS 3.0.4-r3 — Cập nhật tốc độ đăng nhập và lưu bill

Áp dụng cho project đang chạy bản 3.0.4-r2 bạn đã deploy thành công.

## Cập nhật đúng 8 file

Mở **project Apps Script hiện tại**, thay toàn bộ nội dung các file sau bằng file cùng tên trong ZIP:

| File trong ZIP | Mục đích |
| --- | --- |
| `Code.gs` | Build r3 và mã đối chiếu Index; giữ cách tải giao diện đã sửa lỗi trắng trang |
| `Config.gs` | Hoàn tất ghi Sheets trước khi nhả khóa giao dịch |
| `Data.gs` | Tái sử dụng kết nối, bỏ đọc lặp, ghi theo nhóm |
| `Security.gs` | Xác minh OTP và trả dữ liệu bán hàng trong cùng lượt gọi |
| `ApiRead.gs` | Tải phần bán hàng trước; lịch sử tải sau |
| `Billing.gs` | Lưu thanh toán và trả bill/tồn kho thay đổi ngay |
| `Inventory.gs` | Kiểm tra tồn thực tế, gom ghi các dòng liền nhau |
| `Index.html` | Dùng luồng đăng nhập/thanh toán mới, giữ mã yêu cầu khi thử lại |

Trong Apps Script, file HTML có tên **Index**. Chỉ thay Code.gs như bản sửa trắng trang trước sẽ KHÔNG đủ cho lần cập nhật này.

1. Lưu đủ 8 file. Giữ nguyên các file `.gs` khác, `appsscript.json` và Script Properties.
2. Chọn **Deploy → Manage deployments → Edit (biểu tượng bút) → Version: New version → Deploy**.
3. Tải lại đường dẫn `/exec`. Các tab đang mở trước đó cũng cần tải lại để dùng cùng bản mới.
4. Đăng nhập và thử thanh toán một bill thực tế cần lưu. Kiểm tra bill trong lịch sử và đối chiếu tồn kho.

**Không chạy lại `moriSetup`, `moriSeedQC` hoặc tạo lại file Sheets.** Bản cập nhật dùng nguyên dữ liệu, cấu trúc 8 cột, ID và bộ đếm hiện có; không cần migration hay bật thêm API.

## Hành vi mới

- Nhập OTP đúng: vào phần bán hàng sau một lượt gọi xác minh + tải dữ liệu cần thiết.
- Lịch sử bill, nhập kho, booking, chấm công và audit tải ở nền. Các trang phụ thuộc hiển thị “Đang tải” thay vì số liệu 0 giả.
- Thanh toán: khóa nút trong khi đang lưu; chỉ báo thành công khi máy chủ hoàn tất bill, tồn kho và trả phản hồi. Không chờ một lượt tải lại lịch sử.
- Nếu mất phản hồi, giữ nguyên bill rồi bấm xác nhận lại: mã yêu cầu được giữ để tránh ghi trùng. Không có cơ chế tự động gửi lại thanh toán.

## Đo thời gian nếu vẫn chậm

Mở F12 → Console, chọn khung ứng dụng Mori nếu trình duyệt đang chọn khung ngoài, chạy:

```javascript
console.table(window.MoriPerformance)
```

Đối chiếu `moriAuthVerify` / `moriSessionBootstrap` / `moriCheckout`:

- `clientMs`: thời gian từ lúc gửi đến lúc nhận phản hồi trên trình duyệt.
- `serverMs`: thời gian trong hàm máy chủ; chưa gồm thời gian trước khi hàm bắt đầu.
- `authMs`: phần kiểm tra OTP/phiên và quyền truy cập.
- `lockWaitMs`: thời gian đợi khóa ghi khi thanh toán.

Chỉ lưu tên hàm và số đo; không ghi token, OTP hay nội dung bill trong bảng này. Thời gian chờ email OTP là công đoạn riêng và chưa có số đo thực tế trong bản kiểm thử.

Kết quả kiểm thử và giới hạn xem `PERFORMANCE_REPORT.md`. Các hướng dẫn r2 cũ được giữ riêng trong `docs/history_r2/`; dùng hướng dẫn này để cập nhật r3.
