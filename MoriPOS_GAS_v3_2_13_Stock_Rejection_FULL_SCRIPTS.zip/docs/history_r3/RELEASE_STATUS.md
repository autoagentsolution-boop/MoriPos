# Mori POS 3.0.4-r3

Đã hoàn thành mã nguồn tối ưu đăng nhập và thanh toán, cùng kiểm thử mô phỏng Node. Chưa deploy hoặc đo thời gian trên project Google của người dùng.

Bộ thay đổi: Code.gs, Config.gs, Data.gs, Security.gs, ApiRead.gs, Billing.gs, Inventory.gs, Index.html.

Dùng DEPLOY_QUICK_START.md để cập nhật. Không chạy setup/migration. Cách tải runtime đã khắc phục trang trắng ở r2 được giữ lại.
