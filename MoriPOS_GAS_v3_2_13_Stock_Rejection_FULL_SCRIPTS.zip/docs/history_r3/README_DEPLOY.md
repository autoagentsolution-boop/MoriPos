# Mori POS 3.0.4-r3 — Performance Fix

Bản này tiếp nối ZIP `MoriPOS_GAS_v3_0_4_r2_Runtime_Fix(1).zip`, xử lý thời gian chờ xác thực và lưu bill trên 10 giây được báo lại.

**Bắt đầu với `DEPLOY_QUICK_START.md`: thay 8 file trong project hiện tại rồi deploy New version.** Không khởi tạo lại dữ liệu.

## Thay đổi

| Luồng | Bản r2 | Bản r3 |
| --- | --- | --- |
| Nhập OTP → màn hình bán hàng | Verify → kiểm tra lại phiên → bootstrap toàn bộ | Verify và dữ liệu bán hàng trong 1 RPC; lịch sử tải nền |
| Mở lại tab có token | Kiểm tra phiên rồi gọi bootstrap | 1 RPC kiểm tra phiên + dữ liệu bán hàng |
| Xác nhận thanh toán | Ghi bill rồi gọi delta Bills/Items/Audit; chờ cả hai | 1 RPC ghi và trả bill + những mặt hàng vừa đổi |
| Đọc dữ liệu trong giao dịch | Đọc danh mục/cấu hình nhiều lần; tìm lại dòng trước khi ghi | Snapshot mới trong mỗi execution, xóa snapshot trước khi giữ khóa ghi |
| Ghi tồn kho | Từng mặt hàng riêng | Gom những dòng cần đổi liền nhau; không ghi đè dòng ở giữa |
| Tìm thanh toán đã gửi | Tải tối đa 1.500 bill rồi tìm | Tìm chính xác request ID ở Sheets; không giới hạn cửa sổ 1.500 dòng |

Mô hình dữ liệu vẫn là Apps Script + Google Sheets. Không có dịch vụ ngoài, bảng mới hay thay đổi schema.

## Các điểm giữ tính đúng đắn

- Kiểm tra quyền hiện tại trên AccessControl; quyền không lấy từ cache danh mục.
- Mỗi thanh toán đọc tồn mới sau khi lấy khóa, kiểm tra hàng đã giữ cho đơn online.
- Bill giữ trạng thái COMMITTING khi cần phục hồi; mã thao tác trên mặt hàng ngăn trừ tồn hai lần.
- Chỉ phản hồi thành công sau khi ghi bill và tồn kho, rồi flush Sheets trước khi nhả khóa.
- Client giữ request ID khi thiếu phản hồi, giữ giỏ đến khi có xác nhận và chặn bấm hai lần.
- Dữ liệu nền cũ không ghi đè bản có version mới hơn. Phiên đã đăng xuất không nhận dữ liệu nền của phiên cũ.
- Version của chỉnh sửa tại trình duyệt được tách khỏi version của draft trên máy chủ.
- Giữ cơ chế tải runtime r2 (RPC + Base64 + kiểm tra SHA-256), tránh đưa khối JS lớn trở lại HTML ban đầu.

## Nội dung ZIP

- Toàn bộ `.gs`, `Index.html`, `appsscript.json`: bộ nguồn để deploy.
- `Original_UI_Offline.html`: bản tham khảo giao diện offline cũ, không dùng thay Index.
- `DEPLOY_QUICK_START.md`: các bước cập nhật.
- `PERFORMANCE_REPORT.md`, `QC_CHECKLIST.md`: kết quả mô phỏng và kiểm tra thực tế sau deploy.
- `tests/`: kiểm thử Node, không đưa vào Apps Script.
- `docs/history_r2/`: giữ nguyên tài liệu của gói trước để tham chiếu, không dùng làm hướng dẫn cập nhật r3.

## Chạy kiểm thử cục bộ

Yêu cầu Node.js hỗ trợ cú pháp JS hiện đại (đã chạy bằng Node 24 trong môi trường kiểm thử).

```bash
node tests/startup.test.js
node tests/business.test.js
node tests/performance.test.js
node tests/frontend.test.js
```

Các bài test mô phỏng Sheets, Cache, Lock, DOM và RPC. Chưa đo độ trễ của project Google thật; không cam kết một mức giây cụ thể từ các kết quả này.
