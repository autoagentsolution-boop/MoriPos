# Báo cáo kiểm thử — Mori POS 3.0.4-r3

Ngày: 05/11/2026. Nguồn so sánh: gói r2 do người dùng gửi. Chưa truy cập project Apps Script hoặc dữ liệu Google Sheets thực tế của người dùng.

## Nguyên nhân thấy trong mã nguồn r2

1. Sau OTP, frontend gọi `moriAuthVerify`, `moriAuthWho`, `moriBootstrap` nối tiếp. Quyền bị đọc lại nhiều lần và bootstrap chờ lịch sử ở các spreadsheet khác.
2. `moriSheet_` chỉ giữ handle theo bảng, mở lại cùng file MASTER khi đọc bảng khác.
3. Sau `bill.pay`, frontend đợi thêm `moriDelta(Bills, Items, Audit)` rồi mới báo lưu thành công.
4. Mỗi thanh toán đọc danh mục lặp; đọc cả 1.500 bill để chống gửi lại; đọc toàn bộ bill để tính tồn giữ cho đơn online; trước mỗi lần ghi lại tìm dòng và đọc version.

Đây là các công việc thừa xác định được từ code. Chưa có log sản xuất để quy toàn bộ thời gian trên 10 giây cho từng nguyên nhân.

## Số lượt gọi đo bằng mô phỏng

Fixture: 3.000 bill PAID, 80 mặt hàng, 2 chi nhánh, 40 bản ghi cho mỗi nhóm nhập kho/booking/chấm công. Thanh toán 5 mặt hàng ở 5 dòng liền nhau, chưa có đơn online đang giữ hàng. Đếm các lệnh gọi thực của code vào API giả lập; không quy đổi số lượt thành thời gian.

| Chỉ số | Đăng nhập r2 | Đăng nhập r3, cache trống | R3, cache còn dữ liệu |
| --- | ---: | ---: | ---: |
| RPC đến khi vào bán hàng | 3 | 1 | 1 |
| `openById` | 15 | 2 | 1 |
| `getValues` | 14 | 8 | 1 |
| Dòng đọc qua `getValues` | 1.711 | 89 | 1 |

Không tính RPC tải mã giao diện, gửi email OTP hoặc RPC tải lịch sử nền sau khi vào bán hàng. Cột cache còn dữ liệu đo mở phiên bằng token: vẫn đọc AccessControl hiện tại.

| Chỉ số | Thanh toán r2, gồm tải lại sau lưu | Thanh toán r3 |
| --- | ---: | ---: |
| RPC đến lúc báo lưu xong | 2 | 1 |
| `openById` | 11 | 4 |
| `getValues` | 19 | 4 |
| Dòng đọc qua `getValues` | 5.003 | 83 |
| `setValues` | 8 | 4 |
| Dòng thực sự ghi | 8 | 8 |
| Flush trước nhả khóa | 0 | 1 |

Số dòng ghi như nhau: vẫn giữ các bước commit, tồn kho và audit. Số lần ghi tồn giảm tùy độ liền nhau của các dòng hàng; hàng ở xa nhau cần nhiều nhóm ghi hơn.

TextFinder vẫn tìm trên phạm vi Sheets ở phía máy chủ. R3 giảm lượng lịch sử truyền vào Apps Script; đây không phải một database index có thời gian tìm cố định.

## Kiểm thử đã qua

- `startup.test.js`: cú pháp toàn bộ server/HTML/manifest; loader r2; hash/marker; lỗi runtime; phiên hết hạn; storage bị chặn; trang công khai; lỗi RPC hiển thị rõ.
- `business.test.js`: snapshot giá, giữ hàng online, không bán quá tồn, giao hàng/trả tiền, sửa tip, version conflict, nhập kho chỉ một lần và chống thanh toán trùng.
- `performance.test.js`: chạy Data.gs thật với Sheets/Cache/Lock giả lập; 18 nhóm kiểm tra gồm quyền bị thu hồi, cache bị mất, tồn mới, thanh toán lặp, bill cũ ngoài 1.500 dòng, lỗi ghi một phần, lỗi flush, kiểm tra chi nhánh trước phục hồi, draft và các luồng online/nhập kho.
- `frontend.test.js`: dùng runtime thật trong Node VM với DOM/RPC giả lập; 8 nhóm kiểm tra đăng nhập 1 RPC, bán hàng khi lịch sử đang tải, chặn gửi đôi, áp dụng kết quả thanh toán không reload, phản hồi nền đến muộn, request ID giữ nguyên khi thử lại, lỗi lịch sử và dữ liệu của phiên cũ.

Các test không ghi vào tài khoản Google hoặc tạo giao dịch thật. Kiểm thử Chromium cục bộ không chạy được do môi trường không cho tạo socket của trình duyệt; không có kết quả browser/deployment thật để báo PASS.

## Giới hạn và cách đối chiếu thực tế

- Chưa đo p50/p95 hoặc xác nhận thời gian xuống dưới 10 giây trên Google thật.
- Độ trễ RPC, thời gian khởi động dịch vụ, số người ghi cùng lúc và lượng dữ liệu thực tế không được mô phỏng bằng các số đếm trên.
- Cache danh mục/cấu hình tối đa 45 giây như trước; cache có thể mất sớm. Chốt thanh toán luôn đọc tồn thực tế.
- Các giới hạn lịch sử trong bootstrap giữ như r2: 1.500 bill, 600 phiếu nhập, 800 booking, 100/500 attendance và 200 audit; việc tải nền không mở rộng phạm vi báo cáo.
- Email OTP vẫn dùng MailApp. Việc tối ưu luồng xác minh không chứng minh email sẽ đến nhanh hơn.

Sau deploy, dùng `window.MoriPerformance` theo quick start. `clientMs` bao gồm toàn bộ thời gian chờ RPC phía trình duyệt; `serverMs` bắt đầu khi hàm đã được gọi trên máy chủ; `lockWaitMs` cho thấy có phải chờ giao dịch khác hay không. Có thể đo vài lần đầu và vài lần tiếp theo, ghi lại số mặt hàng/bill và số thiết bị cùng bán để so sánh hợp lý.

Cơ sở triển khai: [Google Apps Script — Best practices](https://developers.google.com/apps-script/guides/support/best-practices), [TextFinder](https://developers.google.com/apps-script/reference/spreadsheet/text-finder), [Lock](https://developers.google.com/apps-script/reference/lock/lock), [Cache](https://developers.google.com/apps-script/reference/cache/cache).
