# Kiểm tra sau cập nhật r3

Các kiểm thử tự động mô phỏng đã qua. Danh sách dưới đây dành cho lần deploy thực tế; chưa đánh dấu đã hoàn thành.

- [ ] Thay đủ 8 file theo quick start; deploy New version trên deployment hiện tại.
- [ ] `/exec` mở bình thường; không tái xuất hiện lỗi trắng trang.
- [ ] Đăng nhập OTP đúng; vào bán hàng trước khi lịch sử tải xong.
- [ ] Mở Tổng quan/Lịch sử lúc đang tải: có thông báo chờ, không trình bày số 0 như kết quả đã tải.
- [ ] Thanh toán bill một mặt hàng; bill xuất hiện trong lịch sử, số tiền và tồn giảm đúng.
- [ ] Thanh toán bill nhiều mặt hàng; kiểm tra từng tồn.
- [ ] Mở lại một draft, thêm/sửa món rồi thanh toán: không tạo bill thứ hai.
- [ ] Khi thao tác lặp để thử chống trùng, đối chiếu đúng một bill và một lần trừ tồn.
- [ ] Thử tài khoản nhân viên của một chi nhánh: dữ liệu và thao tác đúng phạm vi được cấp.
- [ ] Kiểm tra luồng đơn online, nhập kho và chấm công đang dùng.
- [ ] Ghi lại `clientMs`, `serverMs`, `lockWaitMs` từ bảng đo trên trình duyệt; so sánh với mốc chờ trên 10 giây đã gặp.

Thực hiện kiểm thử tình huống lỗi mạng/ghi dở trên bản QC có dữ liệu thử. Không dùng seed QC lên dữ liệu cửa hàng đang bán.
