# Mori POS 3.0.4-r2 — Kiểm tra và sửa luồng khởi động trang trắng

Kiểm tra ngày 05/11/2026, từ đúng file `MoriPOS_GAS_v3_0_1_QC_Deploy(2).zip` được gửi trong cuộc trò chuyện.

**Cập nhật r2:** lỗi `Document.write: Invalid or unexpected token` được xử lý bằng cách tải runtime qua RPC có kiểm tra SHA-256. Xem `README_TRANSPORT_FIX.md` trước khi triển khai. Index giữ nguyên; mỗi lượt mở trang có thêm một RPC đọc mã tĩnh.

## Kết luận có bằng chứng

Ảnh báo lỗi mới cho thấy `doGet()` 3.0.4 dừng ở điều kiện marker do bản vá thêm vào. Điều kiện đó không đủ để kết luận file thiếu/hỏng. Bản r1 bỏ chặn theo marker và đọc nguồn bằng `HtmlTemplate.getRawContent()`. Xem `README_MARKER_FIX.md`.

Không phát hiện lỗi cú pháp trong 12 file `.gs` hoặc JavaScript bên trong `Index.html` của ZIP gốc. Tài liệu HTML có đủ thẻ đóng; trong bản này không có tham chiếu hay phụ thuộc `MoriRuntime.html`. Luồng khởi động với phản hồi giả lập bình thường chạy được. Vì chưa có URL/log của deployment đang lỗi, chưa thể xác định tác nhân cụ thể trên tài khoản Google của bạn.

Tuy nhiên, code gốc có những đường dẫn đã tái hiện được khiến giao diện không hiện:

| Vị trí trong ZIP gốc | Vấn đề | Bằng chứng/phạm vi |
| --- | --- | --- |
| `Code.gs`, dòng 8 | Chèn CSS `body.mori-live:not(.mori-ready) #app{visibility:hidden}`; không có giao diện chờ độc lập | Khi phản hồi khởi động bị treo, app vẫn bị ẩn và không có form đăng nhập |
| `Index.html`, `moriBootAdmin()`, dòng 1688 | Luôn gọi `moriAuthWho`, kể cả chưa có token | Form đăng nhập phụ thuộc một lượt gọi server không cần thiết |
| `Index.html`, `moriCall()`, dòng 1654–1657 | Promise không có timeout nếu callback chưa trở về | Test giả lập callback treo tái hiện trạng thái trắng; đây không phải bằng chứng request thật của bạn đang treo |
| `Index.html`, `restoreConfig()` và các đoạn đọc dữ liệu demo, dòng 689–720 | Khôi phục dữ liệu demo trước khi chuyển sang live adapter | Cấu hình cũ với `branches:[null]` làm khởi tạo dừng vì TypeError trong test; chưa biết trình duyệt của bạn có dữ liệu này hay không |
| `Index.html`, cuối file, dòng 1840–1841 | `render()` chạy ngoài khối bắt lỗi của `moriStart()`; không có bộ hiển thị lỗi khởi động độc lập | Nếu render/init lỗi, người dùng không nhận được thông báo trên trang |
| `Index.html`, các truy cập `sessionStorage` trong adapter | Một số thao tác lưu/đọc token không có dự phòng | Có thể ngăn hoàn tất đăng nhập nếu storage bị chặn; không khẳng định đây là nguyên nhân trang trắng hiện tại |

Không có bằng chứng trong kiểm tra này cho thấy bắt buộc phải tách file HTML, hoặc file dài tự nó là nguyên nhân lỗi. Bản sửa vẫn giữ một file `Index.html`.

## Thay đổi trong 3.0.4

Chỉ hai file chạy ứng dụng thay đổi: `Code.gs` và `Index.html`.

- Sau khi runtime tải xong, hiện form đăng nhập nếu chưa có token mà không gọi thêm API xác thực. r2 có một RPC tải mã tĩnh trước bước này.
- Có màn hình chờ bằng HTML tĩnh và script bắt lỗi nhỏ, độc lập với script chính.
- Timeout 20 giây cho ba lời gọi đọc khi khởi động: `moriAuthWho`, `moriBootstrap`, `moriPublicBootstrap`. Phản hồi đến muộn được bỏ qua ở phía client; không hủy tác vụ server.
- Bộ theo dõi khởi động báo lỗi sau 30 giây nếu script chính không hoàn tất.
- Chỉ render giao diện live sau khi xác thực/tải dữ liệu thành công; không render dữ liệu demo trước đó.
- Không đọc cấu hình, bill, booking và audit demo từ localStorage khi chạy live.
- Có dự phòng token trong bộ nhớ của tab khi sessionStorage bị chặn. Nếu storage bị chặn, tải lại trang có thể cần đăng nhập lại.
- Thiếu `google.script.run` thì hiện lỗi, không tự rơi vào chế độ bán hàng demo.
- Lỗi đọc file Index hoặc thiếu thẻ head/body thực sự sẽ được `doGet()` trả về dưới dạng trang báo lỗi. Thiếu marker đầu/cuối chỉ tạo cảnh báo đối chiếu, không chặn trang.
- Font ngoài tải không chặn hiển thị ban đầu; font dự phòng được dùng trong lúc chờ.
- Thêm `moriFrontendCheck()` để kiểm tra SHA-256, marker và số thẻ script sau khi dán file.
- Không tự động thử lại các thao tác ghi. Các file xử lý dữ liệu, phân quyền, billing, kho và setup giữ nguyên byte so với ZIP gốc.

## Cập nhật project đã cài đặt

1. Nếu đã dùng `Index.html` từ bản Boot Fix 3.0.4 ở lượt trước, chỉ thay **toàn bộ `Code.gs`** bằng bản r2. `Index.html` trong ZIP mới giữ nguyên byte. Nếu cập nhật trực tiếp từ bản gốc 3.0.1 thì thay cả `Code.gs` và file HTML tên **Index**. Không dán nối vào code cũ. Không cần tạo `MoriRuntime`.
2. Lưu, chọn hàm `moriFrontendCheck` rồi Run. Execution log của file nguyên vẹn phải có `build: "3.0.4-r2"`, `ok: true`, `scriptOpen: 2`, `scriptClose: 2`. Với Index 3.0.4 nguyên vẹn, `exactFileMatch: true`. `ok` chỉ kiểm tra cấu trúc cơ bản; `exactFileMatch`/marker khác không ngăn mở trang.
3. Nếu `exactFileMatch: false`, nội dung HTML khác bản cung cấp. Cả thay đổi khoảng trắng/xuống dòng cũng làm hash khác; không đồng nghĩa mọi thay đổi đều là lỗi. Nếu bạn chưa chủ động sửa gì, dán lại file đầy đủ.
4. Chọn **Deploy → Manage deployments → Edit → Version: New version → Deploy**. Chỉ Save code không cập nhật bản `/exec` đang dùng version cũ.
5. Mở lại URL `/exec`. Chưa có phiên đăng nhập thì phải thấy form email OTP ngay. Website khách: `/exec?view=shop&tab=home`.

Không cần chạy lại `moriInstallOnce`/`moriSetup`, tạo lại Sheets hoặc reset dữ liệu để áp dụng bản sửa này. `moriFrontendCheck` chỉ đọc mã HTML, không sửa dữ liệu bán hàng.

Nếu project chưa từng cài đặt, dùng `DEPLOY_QUICK_START.md` cho các bước cài lần đầu.

## Nếu vẫn không mở được

- Nếu thấy màn hình lỗi Mori: gửi nội dung **Chi tiết lỗi** và cho biết URL là admin hay `?view=shop`.
- Nếu không thấy cả chữ “mori.”/“Phiên bản 3.0.4”: đối chiếu deployment đã chọn New version chưa; gửi URL `/exec` và lỗi đầu tiên trong Console (F12). Điều này giúp phân biệt lỗi trước khi HTML được tải với lỗi bên trong ứng dụng.
- Nếu `moriFrontendCheck` báo thiếu Index: tạo file loại **HTML**, tên `Index`, không phải file Script.
- Nếu login hiện nhưng báo lỗi setup/quyền/quota: giao diện đã khởi động; kiểm tra Execution log và `moriHealthCheck()` để xử lý lớp backend tương ứng.

## Đã kiểm tra và giới hạn

Đã chạy Node V8 kiểm tra cú pháp toàn bộ mã, 36 nhóm kiểm tra startup (bao gồm hai ca tái hiện lỗi bản gốc), bộ test nghiệp vụ có sẵn và kiểm tra cấu trúc HTML. Xem `VERIFICATION.md`, `tests/startup.test.js`, `tests/business.test.js`.

Test startup dùng Node VM với DOM và `google.script.run` giả lập, **không phải kiểm thử trình duyệt đầy đủ hay deployment Google thật**. Chưa kiểm chứng quyền triển khai, Google Sheets/Drive/MailApp, OTP email thực, sandbox/CSP trên Google, quota hoặc thiết bị của bạn. Đây là bản sửa và chẩn đoán khởi động, không phải xác nhận toàn bộ POS đã production-ready.

## Tài liệu Google đối chiếu

- Web apps và `doGet`: https://developers.google.com/apps-script/guides/web
- API bất đồng bộ và success/failure handler: https://developers.google.com/apps-script/guides/html/communication
- Deployment giữ một version cụ thể: https://developers.google.com/apps-script/concepts/deployments
- HTML Service chạy trong iframe: https://developers.google.com/apps-script/guides/html/restrictions
