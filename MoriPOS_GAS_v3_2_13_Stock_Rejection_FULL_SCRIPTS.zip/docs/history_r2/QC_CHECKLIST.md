# Mori POS — Checklist QC theo luồng nghiệp vụ

**Môi trường:** deployment `/exec`, một thư mục Drive & 7 Spreadsheet riêng dành cho QC. Trước khi QC, chạy `moriHealthCheck()`.

| # | Test case | Kết quả kỳ vọng | Đánh giá |
|---|---|---|---|
| 01 | Setup lần đầu | 7 file + đủ tab + 6 thư mục ảnh/Archive, không tạo trùng khi chạy lại | ☐ |
| 02 | Admin đăng nhập Gmail | OTP được gửi tới email trong AccessControl, token tồn tại tối đa 6 giờ | ☐ |
| 03 | Email ngoài danh sách | Không vào được dữ liệu quản trị dù biết URL | ☐ |
| 04 | Employee chỉ xem trang được cấp | Không có Salary, Finance, Settings; API phía server từ chối sửa | ☐ |
| 05 | Thêm chi nhánh | Không trùng mã/tên, lọc chi nhánh trong dropdown, refresh vẫn tồn tại | ☐ |
| 06 | Thêm sản phẩm + ảnh | Item xuất hiện trong POS_Items; ảnh ở Drive; không có base64 trong cell | ☐ |
| 07 | Thêm danh mục cùng tên khác dấu/hoa | Bị chặn | ☐ |
| 08 | Nhập 2 thùng ×24 cái | Stock base tăng 48, giá vốn theo đơn vị gốc đúng | ☐ |
| 09 | Nhân viên nhập kho | Bắt buộc shipping info + ít nhất 1 ảnh; manager/admin duyệt | ☐ |
| 10 | Duyệt cùng StockIn hai lần | Số tồn chỉ cộng một lần, có Audit | ☐ |
| 11 | Combo 2 xiên + 1 nước | Kiểm tra tất cả thành phần, thiếu 1 không xác nhận được | ☐ |
| 12 | Bán lẻ 1 item, custom price | Giá trên Bill snapshot, giá catalog không thay đổi | ☐ |
| 13 | Hai thiết bị bán sản phẩm cuối | Một thao tác hoàn thành, thao tác còn lại báo thiếu tồn | ☐ |
| 14 | Bấm thanh toán lặp | Không sinh hai Bill cho cùng request ID | ☐ |
| 15 | Bill đã thanh toán | Không sửa giá/SL/discount; chỉ tip & employee attribution | ☐ |
| 16 | Thêm tip 20k sau thu tiền | PaidAtCheckout giữ nguyên, tổng mới tăng, Audit trước/sau | ☐ |
| 17 | 2 người chỉnh cùng Bill | Phiên cũ báo `VERSION_CONFLICT` | ☐ |
| 18 | Website công khai Order Online | Chỉ hiển thị danh mục được công khai và sản phẩm active | ☐ |
| 19 | Public Order | Tính giá lại server, không tin giá trình duyệt; thông báo owner | ☐ |
| 20 | Online A được xác nhận trước | Giữ tồn trước; Online B vượt tồn không xác nhận được | ☐ |
| 21 | `CONFIRMED→PREPARING→SHIPPED→DELIVERED` | Đồng bộ Tổng quan / Online Sales / Vận chuyển; không tạo đơn trùng | ☐ |
| 22 | Đã giao chưa thu tiền | Không tự động ghi PAID/doanh thu thanh toán | ☐ |
| 23 | Chủ xác nhận nhận tiền | PAID cập nhật, lịch sử Bill + Audit đồng bộ | ☐ |
| 24 | Bật/tắt Online Order | Bán hàng online và Vận chuyển ẩn/hiện cùng nhau | ☐ |
| 25 | Public Booking | Tạo PENDING và owner được thông báo | ☐ |
| 26 | Booking trùng bàn/giờ | Chặn theo resource + duration | ☐ |
| 27 | Attendance IN/OUT | OTP gửi Gmail + ảnh; IN giữ giờ đầu, OUT giữ giờ cuối | ☐ |
| 28 | Chuyển All Branches | Chỉ ADMIN; không làm đổi chi nhánh gốc trên Bill đang lập | ☐ |
| 29 | Mẫu in 58/80/A4 + VietQR | PDF/thermal đúng khổ, tiền đúng, không in cả trang app | ☐ |
| 30 | Reload + thiết bị khác | Data từ Sheets, không phụ thuộc localStorage | ☐ |
| 31 | Retention backup | Copy/verify rồi mới xóa, không đụng Bill còn mở/chưa thu tiền | ☐ |
| 32 | Performance | Đo p50/p95 cho catalog, Bill pay, online confirm trên 100/1.000/5.000 dòng | ☐ |

**Chưa được coi là PASS trước khi kiểm tra trên Google Apps Script thật.** Việc một unit test local đạt không thay thế kiểm thử mạng, browser, email, Drive permissions và quota.

## Mục cần follow-up sau QC (không giả định đã hoàn thành)

- Public account/customer history nhiều thiết bị và định danh an toàn.
- Dashboard tài chính khi Bill đã nằm trong file archive.
- Xử lý crash ở giữa ghi nhiều dòng / khôi phục tự động khi thao tác thất bại.
- Hóa đơn điện tử hợp pháp, tích hợp thanh toán thực tế, API hãng giao hàng.
- Khối lượng lớn (>= 200–400 Bill/ngày) và Apps Script quotas.

## Các bài kiểm tra bổ sung v3.0.1

| # | Test case | Kết quả kỳ vọng | Đánh giá |
|---|---|---|---|
| 33 | Tạo Bill nháp rồi sửa số lượng và thanh toán | Cùng một `id`/dòng Sheet, không trùng Bill | ☐ |
| 34 | Employee gọi API đọc trực tiếp `moriRefresh`/`moriDelta` | Không nhận giá vốn, lương, chi phí quản trị hoặc dữ liệu chi nhánh khác | ☐ |
| 35 | Cấu hình giảm giá online 10% và truy cập Publish Site | Giá hiển thị đúng giá online, giá checkout khớp | ☐ |
| 36 | Chụp ảnh điện thoại lớn hơn 2 MB | Ảnh tự nén, lưu được ID Drive trong bản ghi | ☐ |
| 37 | Nhập kho vào kho Store không có stock riêng của chi nhánh | Giá vốn bình quân cập nhật ở kho Store, không gán sai chi nhánh | ☐ |
| 38 | Gửi lại request ID online/booking sau sự cố mạng | Không sinh thêm record nếu request trước đã ghi | ☐ |


## 3.0.4 — Startup checks on the real deployment (pending)

- [ ] moriFrontendCheck reports build 3.0.4-r2; marker/hash differences are advisory. Exact unmodified Index 3.0.4 should report exactFileMatch:true.
- [ ] New /exec session loads verified runtime, then displays email OTP without an additional auth RPC.
- [ ] Valid saved session loads real store data.
- [ ] Expired session returns to login.
- [ ] Public home/catalog/booking/tracking load or show an explicit error.
- [ ] A slow/failed bootstrap shows a message instead of an empty page.
- [ ] Browser with restricted storage can complete OTP login.
- [ ] Actual Google OTP, Sheets access and existing checkout/stock flows pass QC.


## 3.0.4-r2 — Runtime transport QC on Google (pending)

- [ ] /exec loads the small shell, then moriFrontendRuntime succeeds.
- [ ] SHA-256 is verified in the browser; no CSP/runtime insertion error.
- [ ] Email OTP and public pages work against the real backend.
- [ ] Reload performance is acceptable with one extra static-source RPC.
