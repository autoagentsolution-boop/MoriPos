# Local verification — 3.0.4-r2

Date: 2026-11-05.
Environment: Node.js v24.22.1; simulated DOM and asynchronous Google RPC; Python HTMLParser.

Commands completed successfully:

```sh
MORI_ORIGINAL_DIR=/path/to/original-extraction node tests/startup.test.js
node tests/business.test.js
```

Without the original extraction, `node tests/startup.test.js` runs the fixed-build checks and skips only the two original-build reproduction checks.

| Startup check | Result |
| --- | --- |
| All 12 server files, both HTML script blocks and manifest parse | PASS |
| Original: pending first authentication call leaves app hidden without login/loading UI | REPRODUCED |
| Original: malformed persisted demo branch stops initialization | REPRODUCED |
| First admin visit: one runtime RPC, no auth RPC, no demo rendering | PASS |
| Missing Google bridge: visible error | PASS |
| Expired session: login and stale token removal | PASS |
| Valid admin session: server store rendered | PASS |
| Hanging authentication check: visible timeout | PASS |
| Hanging admin bootstrap: visible timeout | PASS |
| Admin backend exception: error shown on login | PASS |
| Public home with server data | PASS |
| Public catalog with server data | PASS |
| Public booking with server data | PASS |
| Public tracking with server data | PASS |
| Unpublished shop: closed message | PASS |
| Hanging public bootstrap: visible timeout | PASS |
| Public backend exception: visible error | PASS |
| OTP flow with blocked sessionStorage | PASS (mock RPC; no email sent) |
| Live startup ignores malformed demo localStorage | PASS |
| Offline preview still renders | PASS |
| Simulated main-script syntax failure: error panel | PASS |
| Missing main script: watchdog | PASS |
| Missing Index or actual head/body: server error page | PASS |
| Both marker comments removed: login still appears | PASS |
| Marker/hash mismatch: diagnostic warnings, not blocking | PASS |
| Older marker labels in otherwise identical HTML: login appears | PASS |
| Raw template read used instead of processed HtmlOutput | PASS |
| Route parameters remain allowlisted | PASS |
| SHA-256 source check detects content differences | PASS |

Seven additional transport groups completed:

| Check | Result |
| --- | --- |
| Small inline scripts; runtime bytes equal source | PASS |
| Source changed between shell and RPC | Rejected |
| Runtime RPC timeout | Visible error |
| Runtime read exception | Visible error |
| Corrupt runtime bytes despite unchanged metadata | SHA-256 rejection before execution |
| Incorrect metadata | Rejected before execution |
| Invalid Base64 | Visible error |

Additional completed verification:

- Document has one html/head/body pair, two complete script blocks and balanced style elements including the noscript fallback.
- Existing business tests passed: price snapshot, stock reservations and oversell prevention, shipping deductions, delivery/payment split, tip edits, version conflicts, stock idempotency, photo policy, payment idempotency, draft updates, Vietnamese normalization, and role projections.
- All eleven backend .gs files other than Code.gs are byte-identical to the uploaded ZIP.
- appsscript.json and Original_UI_Offline.html are unchanged.
- Index.html is byte-identical to the previously delivered Boot Fix 3.0.4 ZIP. The r2 runtime change is only Code.gs.
- The screenshot verifies the old marker guard was triggered. No claim is made that Google stripped comments or that the user pasted incomplete HTML.

Limitations: a real browser run was unavailable in this environment. No Google deployment, live Sheets, Drive, MailApp, genuine email OTP, permissions, CSP, browser layout or actual quotas were verified. Mock callback stalls and malformed demo data demonstrate possible failure paths, not the observed production trigger on the user's account.
