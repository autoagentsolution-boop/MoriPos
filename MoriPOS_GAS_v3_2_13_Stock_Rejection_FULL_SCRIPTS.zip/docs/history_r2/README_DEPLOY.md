> **Bản hiện tại 3.0.4-r2:** sửa đường nạp JavaScript bằng RPC và kiểm tra SHA-256. Với Index từ Boot Fix 3.0.4, chỉ cần thay Code.gs và deploy New version. Đọc `README_TRANSPORT_FIX.md` trước.

> **Sửa thông báo marker ở bản 3.0.4-r1:** với Index từ Boot Fix 3.0.4, chỉ cần cập nhật Code.gs. Thiếu marker không còn chặn trang. Xem `README_MARKER_FIX.md`.

> **Bản cập nhật 3.0.4:** sửa luồng khởi động/trang trắng. Project đã cài chỉ thay `Code.gs` và `Index.html`, chạy `moriFrontendCheck`, rồi deploy New version. Xem `README_BLANK_PAGE_FIX.md` và `VERIFICATION.md`.

# Mori POS v3.0.1 — Google Apps Script + 7 Google Spreadsheet files

**Trạng thái:** Bản triển khai QC / staging. Mã nguồn đã có API và giao diện kết nối; **chưa chạy trên tài khoản Google của bạn trong cuộc trò chuyện này**. Không dùng trực tiếp cho giao dịch thật trước khi QC.

## 1. Những thành phần trong ZIP

- `Index.html`: giao diện Mori v2.9.1 tích hợp API Google Apps Script.
- `Code.gs`: `doGet`, giao diện Admin và Publish Site.
- `Config.gs`, `Setup.gs`, `Data.gs`, `Security.gs`, `Inventory.gs`, `Billing.gs`, `Operations.gs`, `ApiRead.gs`, `Media.gs`, `Archive.gs`: backend.
- `appsscript.json`: manifest, V8, timezone Asia/Ho_Chi_Minh, scopes.
- `Original_UI_Offline.html`: mockup cũ để đối chiếu; **không deploy**.
- `tests/business.test.js`: kiểm thử logic cục bộ, không cần upload.

## 2. Triển khai lần đầu (không cần tạo Spreadsheet thủ công)

1. Vào [script.google.com](https://script.google.com/) bằng Google account **chủ hệ thống**, tạo một Apps Script project mới: `Mori POS QC`.
2. Trong editor, thay nội dung `Code.gs` mặc định bằng file `Code.gs` trong ZIP. Tạo các file Script có tên tương ứng cho **tất cả** file `.gs` còn lại và chép mã nguồn của chúng vào. Mỗi file tên là `Config`, `Setup`, ... (Apps Script tự thêm `.gs`).
3. Thêm 1 file **HTML** tên `Index`, dán toàn bộ nội dung `Index.html`. Không thêm các file HTML demo khác.
4. Project Settings → bật **Show `appsscript.json` manifest file in editor**, thay nội dung bằng `appsscript.json` trong ZIP. Nếu Google hỏi consent do dùng Mail/Drive/Sheet, đăng nhập bằng tài khoản chủ và cấp quyền.
5. File `Installer.gs` **đã có sẵn hàm `moriInstallOnce()`**. Chọn hàm này ở dropdown **Run** trong Apps Script editor và chạy bằng chính tài khoản Google chủ hệ thống. Không cần chỉnh email trong mã. Email chủ được xác định từ tài khoản đang chạy script.

6. Authorize; sau khi chạy, xem **Execution log** (hoặc chạy `moriHealthCheck()`): `ready:true`, 7 file spreadsheet, không có warning. Drive có thư mục `MoriPOS_Data` chứa file và các thư mục con `ProductImages`, `StockInProof`, `AttendancePhotos`, `Branding`, `Archive`...
7. Có thể chạy `moriSeedQC()` để tạo **4 mặt hàng giả lập**, không tạo bill giả. Nên thử trên môi trường QC mới.
8. Deploy → **New deployment** → **Web app**. **Execute as: Me (chủ project)**. **Who has access: Anyone** chỉ nếu cần Publish Site công khai; nếu chưa QC an toàn, ưu tiên chỉ người được cấp quyền truy cập và chưa bật Publish Site. Lưu ý: dù Web App public, API quản trị vẫn yêu cầu email OTP và AccessControl phía server.
9. Mở URL `/exec` để vào **Mori Admin**. Nhập email đã được whitelist, bấm Gửi mã, nhận OTP trên Gmail, nhập mã 6 chữ số.
10. Sau khi xác nhận UI ổn, bật `Modules → Publish Site`, cấu hình `Publish Site → Online Order/Booking`, bấm lưu. Website khách: **`/exec?view=shop&tab=home`**; danh mục: `?view=shop&tab=catalog`; Booking: `?view=shop&tab=booking`.

**Quan trọng:** mỗi lần sửa mã, vào Deploy → Manage deployments → Edit → chọn **New version** → Deploy để URL `/exec` cập nhật. URL `/dev` chỉ dành cho người có quyền chỉnh sửa project.

## 3. Google Sheets/Drive được tạo

| Spreadsheet | Các tab chính |
|---|---|
| POS_Master | Stores, Branches, Employees, AccessControl, Resources, Promotions, Customers, Settings, PublishSite |
| POS_Items | Items |
| POS_StockIn | StockIn |
| POS_Bills | SalesBills |
| POS_Booking | Booking |
| POS_Attendance | Attendance |
| POS_Audit | Audit |

Mỗi tab dùng cấu trúc `id | branch_id | email | status | created_at | updated_at | version | data_json`. `data_json` giữ các item/snapshot để hạn chế JOIN. Các cột chỉ mục hỗ trợ lọc và đọc nhanh. Không sửa nội dung JSON trực tiếp trong Sheets khi Web App hoạt động.

Tài khoản nhân viên **không cần quyền trực tiếp trên Google Spreadsheet**. API chạy dưới tài khoản chủ, kiểm tra session token, role và branch trước thao tác. Số tiền, giá và stock được kiểm tra lại ở phía server. Các ảnh riêng tư giữ trong Drive của chủ; sản phẩm/logo được phép đặt chế độ public để website hiển thị.

## 4. Thao tác đầu tiên cho QC

- Tại Settings, đặt tên cửa hàng, chi nhánh và thông tin ngân hàng; lưu lại rồi reload để kiểm tra persistence.
- Nhập vài sản phẩm, thêm ảnh, tạo 1 Stock In, xác nhận (nếu nhân viên gửi yêu cầu, Manager/Admin phải duyệt).
- Tạo Bill tại quầy và thanh toán; kiểm tra dòng trên `POS_Bills → SalesBills` và `POS_Audit → Audit`. Sau đó thử sửa tip/nhân viên sau thanh toán.
- Bật Publish Site và Online Order, đặt thử trên link công khai từ **trình duyệt khác**; vào Admin xác nhận/chuẩn bị/đang giao/đã giao; xác nhận nhận tiền riêng.
- Bật Booking, đặt thử từ website; kiểm tra `POS_Booking`.
- Chấm công bằng OTP gửi mail + ảnh (nhân viên dùng camera trên điện thoại qua file picker).
- Nếu có nhiều thiết bị, bấm **↻ Làm mới** hoặc chờ polling 60 giây cho Bills/Booking.

## 5. Performance và độ chính xác

- `LockService` khóa ghi nhằm chống 2 lượt duyệt cùng giữ phần tồn cuối.
- Mỗi phiếu nhập dùng trạng thái `SUBMITTED → APPLYING → CONFIRMED`; mỗi dòng có idempotency marker trong Item để tránh cộng tồn hai lần nếu retry.
- Đơn online xác nhận sẽ giữ số tồn khả dụng; khi chuyển sang `SHIPPED`, trừ số tồn thật. Khi `DELIVERED`, tiền vẫn `PENDING` cho đến khi chủ xác nhận.
- Bill đã thanh toán giữ snapshot giá/khách/đơn; chỉnh tip & nhân viên có CAS version, audit before/after.
- Master/Items cache khoảng 45 giây, invalidation sau mỗi ghi; UI sử dụng delta refresh tránh reload toàn bộ 7 Sheets sau mỗi action.
- Ảnh Drive (không nhúng base64 vào Google Sheets), giới hạn khoảng 2MB sau nén. Ảnh chứng từ và ảnh chấm công private; ảnh sản phẩm/logo công khai khi cần.
- `moriPerformanceProbe()` đo thời gian truy xuất từng loại sheet theo môi trường thực tế.

## 6. Backup / archive

Có `moriArchiveRun` và `moriInstallArchiveTrigger`. **KHÔNG bật trigger trước khi QC xong**: job chuyển dữ liệu đã kết thúc quá retention sang Spreadsheet backup trong thư mục `Archive`, kiểm tra ID đích trước khi xóa dòng khỏi active. Batches tối đa 500 dòng/mỗi loại/mỗi lần chạy. Đơn online chưa thu tiền hoặc chưa hoàn thành KHÔNG được chuyển. Hãy sao lưu cả folder trước khi chạy thử archive.

Cấu hình `shipping` retention được lưu trong Settings. Tuy nhiên dữ liệu giao hàng đang embedded trong Bill JSON; vòng đời Shipping riêng **chưa tách logic dọn chi tiết giao hàng ra khỏi vòng đời Bill**. Không hứa retention riêng độc lập cho bản QC này.

## 7. Giới hạn của phiên bản QC / những việc cần xác minh tiếp

- **Chưa kiểm thử trên Google Apps Script chạy thật trong tài khoản của bạn**; cần chạy QC các bước trên trước khi ghi nhận hoàn thành triển khai. Không có cam kết mọi UI action đã được nối; các nút chính đã có adapter nhưng một số tiện ích nâng cao vẫn còn chế độ mockup.
- Đăng nhập Admin/Employee hiện là **email OTP gửi Gmail**, không phải Google OAuth SSO / Google One Tap. Không nên gọi đây là Google Sign-in chính thức.
- Customer history xuyên nhiều thiết bị chưa được bật bằng email/SĐT đơn thuần vì dễ lộ dữ liệu cá nhân. Guest theo dõi đơn gần nhất bằng token lưu trong phiên duyệt.
- Báo cáo nhiều năm, đối soát các file archive, chi phí phụ trợ và logic kế toán/thanh toán thực tế cần kiểm chứng thêm; dashboard hiện chủ yếu tính trên tập Bill đang active/được tải vào client.
- Không có webhook bên thứ ba để xác nhận tiền VietQR, không kết nối hãng vận chuyển; nhân viên xác nhận thủ công.
- QR ngân hàng/ảnh công khai trên Drive có thể không hiển thị đồng nhất trên mọi trình duyệt; cần thử đúng thiết bị và mạng QC.
- Việc tạo/đổi công thức combo, xóa/hủy phiếu và phục hồi từng phần khi Apps Script timeout cần test nghiêm túc. Google Sheets không cung cấp multi-sheet database transaction.
- Apps Script chịu hạn mức theo tài khoản và giới hạn thời gian chạy. Không vận hành sản lượng lớn nếu chưa benchmark trên dữ liệu thực tế.

## 8. Khi gặp lỗi

Mở **Apps Script → Executions** để xem lỗi. Chạy `moriHealthCheck()` nếu thiếu file/tab. Dùng `moriPerformanceProbe()` để kiểm tra thời gian đọc. Mã lỗi `VERSION_CONFLICT` nghĩa dữ liệu đã được cập nhật ở nơi khác: reload thay vì ghi đè. Nếu Job archive dở dang, **không tự xóa/khôi phục dữ liệu bằng tay** trước khi đối chiếu file Archive và active.

## 9. Các bản vá chất lượng ở v3.0.1

- Sửa lỗi mở/sửa/thanh toán một Bill đã tồn tại: dùng `moriPut_` thay vì chèn trùng dòng.
- Thêm kiểm tra riêng cho employee trong bootstrap, delta refresh và trang phân trang; không trả giá vốn/chi phí nhạy cảm khi role không có quyền.
- Giữ nguyên giá online đã chiết khấu khi hiển thị trên Publish Site; backend vẫn tính lại giá theo cấu hình.
- Ghi `requestId` ngay lúc tạo order/booking để giảm rủi ro tạo trùng khi retry.
- Sửa giá vốn bình quân ở cấp Store khi chi nhánh dùng kho dự phòng cấp Store.
- Nén ảnh JPEG ở trình duyệt trước upload khi ảnh lớn; chặn ảnh không đọc được hoặc quá dung lượng.
- Sửa chuẩn hóa tên danh mục có dấu `Đ/đ` để kiểm tra trùng ổn định.
- Thêm `Installer.gs`, hàm `moriInstallOnce()`, không cần sửa email thủ công.

**Cảnh báo QC:** Không sử dụng chung thư mục Google Drive với dữ liệu thật. Đừng bật archive tự động trước khi kiểm tra số liệu. Không nên công khai website với người dùng thực trước khi hoàn thành các bước trong `QC_CHECKLIST.md`.
