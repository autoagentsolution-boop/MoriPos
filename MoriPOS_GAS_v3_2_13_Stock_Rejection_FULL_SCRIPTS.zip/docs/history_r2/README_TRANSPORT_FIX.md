# 3.0.4-r2 — Sửa bước nạp runtime khi Document.write báo SyntaxError

Lỗi được người dùng cung cấp:

```
Build 3.0.4 · Khởi tạo giao diện
Failed to execute 'write' on 'Document': Invalid or unexpected token
```

## Kết luận và giới hạn bằng chứng

Bộ bắt lỗi ngắn đã chạy, nhưng JavaScript chính không hoàn tất khởi động. Mã hiện có một `doc.write()` trong hàm `printBillDirect()`, chỉ được gọi khi in bill; không có lời gọi hàm in ở bước mở trang. Vì vậy không có cơ sở quy lỗi khởi động này cho chức năng in bill.

Bản Index đang lưu có hai khối script: khối bắt lỗi ngắn 1.389 ký tự và khối ứng dụng 267.740 ký tự (274.008 byte UTF-8). Cả hai qua kiểm tra cú pháp Node. Lỗi trên deployment vẫn có thể do nội dung đã dán khác file đã kiểm tra, hoặc do cách HTML/JS được xử lý lúc nạp qua HtmlService. Chưa có raw response hoặc stack đầy đủ từ deployment để chốt tác nhân chính xác.

Có báo cáo công khai tương tự trên Google Issue Tracker về JavaScript hợp lệ nhưng lỗi trong userCodeAppPanel khi payload lớn: https://issuetracker.google.com/issues/545486500 . Đây là báo cáo để tham khảo, không phải xác nhận Google gây ra lỗi cụ thể của Mori.

## Thay đổi có thể kiểm chứng

- Giữ nguyên byte của Index.html từ bộ Boot Fix 3.0.4; không cần tạo MoriRuntime.html.
- Code.gs đọc một khối JavaScript chính, thay vị trí đó trong HTML gửi đi bằng bộ tải nhỏ.
- Sau khi khung trang mở, `google.script.run.moriFrontendRuntime()` trả mã nguồn tĩnh ở dạng Base64. Hàm này chỉ đọc mã giao diện; không đọc dữ liệu Sheets hoặc trả token/quyền truy cập.
- Trình duyệt kiểm tra SHA-256 của byte tải về so với digest của chính nguồn dùng để dựng khung trang. Nếu truyền sai/thiếu hoặc nguồn thay đổi giữa hai lượt gọi, sẽ báo lỗi trước khi chạy.
- Giải mã UTF-8 và gắn script bằng DOM; không dùng document.write để nạp runtime chính.
- Tên `MoriRuntime_3.0.4-r2.js` chỉ là tên nguồn ảo trong Console, không phải file cần tạo trong Apps Script.
- Nếu chính mã nguồn bị lỗi cú pháp, bộ tải hiển thị thông báo kèm source/line/column khi trình duyệt cung cấp. Không che giấu lỗi đó.
- Timeout 20 giây cho việc tải runtime. Không tự retry thao tác ghi dữ liệu.
- Cơ chế xác thực, quyền truy cập và xử lý dữ liệu giữ nguyên.

Số đo từ bộ file này (chưa tính nén HTTP):

| Thành phần | Kích thước |
| --- | ---: |
| Index nguồn | 381.295 byte |
| HTML ban đầu sau thay đổi | 110.956 byte |
| Script nội tuyến lớn nhất trong HTML mới | 3.361 ký tự |
| Runtime chuyển qua RPC | 274.008 byte trước Base64 |

Đổi lại, mỗi lần mở trang có thêm một RPC đọc mã tĩnh và phần mã có overhead Base64. Đây là thay đổi đường nạp để tránh đặt khối script lớn vào HTML ban đầu, không phải tuyên bố giảm tổng dung lượng mạng hay bảo đảm tốc độ thực tế nhanh hơn.

## Cập nhật

1. Nếu đang dùng Index từ Boot Fix 3.0.4 đã gửi, dán đè toàn bộ Code.gs bằng `MoriPOS_Code_3_0_4_r2.gs` hoặc Code.gs trong ZIP mới. Giữ đúng một hàm doGet; dán vào file Code.gs hiện tại.
2. Giữ nguyên Index và các file nghiệp vụ. Bộ ZIP đầy đủ chứa đúng Index đã kiểm tra nếu cần đối chiếu.
3. Save → Deploy → Manage deployments → Edit → New version → Deploy, rồi mở lại /exec.
4. Không chạy lại setup, không tạo Sheets mới, không cần bật dịch vụ/API mới.

`moriFrontendCheck()` hiện báo `build:3.0.4-r2`, `runtimeTransport`, `runtimeCharacters`, `runtimeSha256` và `exactFileMatch`. Hash/marker của toàn file chỉ dùng đối chiếu; không chặn website. SHA-256 của payload runtime là kiểm tra tính toàn vẹn byte cho mỗi lần tải.

Dòng “Build 3.0.4” trong lớp bắt lỗi của Index là nhãn frontend tĩnh. Code loader mới thêm `Loader 3.0.4-r2` vào lỗi của bước tải runtime. Không dùng riêng nhãn frontend để suy ra version của Code.gs.

## Nếu còn lỗi

Gửi toàn bộ dòng lỗi mới, đặc biệt `Loader`, `Source`, `Line`, `Column`. Nếu vẫn chỉ hiện lỗi Document.write cũ ở “Khởi tạo giao diện”, gửi thêm kết quả `moriFrontendCheck()` để đối chiếu mã nguồn và revision đang dùng; không cần gửi dữ liệu bán hàng.

## Kiểm thử

36 nhóm kiểm tra startup bằng Node VM/DOM/RPC giả lập và bộ test nghiệp vụ hiện có đã pass. Đã kiểm tra: mã qua RPC trùng byte với nguồn; thiếu/sai Base64 hoặc digest bị chặn trước khi chạy; metadata/phiên bản giữa hai lượt tải không khớp; timeout; lỗi đọc nguồn; admin/public startup; mã nguồn có lỗi cú pháp; lưu phiên bị chặn.

Chưa kiểm thử trên deployment Google thật, CSP thực tế, email OTP thật, thiết bị hoặc mạng của bạn. Bản này thay đổi đúng bước nạp bị lỗi và cung cấp kiểm tra tính toàn vẹn, nhưng chưa phải xác nhận lỗi ở tài khoản của bạn đã hết.

Tài liệu chính thức:
- https://developers.google.com/apps-script/guides/html/communication
- https://developers.google.com/apps-script/reference/html/html-template#getRawContent()
- https://developers.google.com/apps-script/guides/html/best-practices
