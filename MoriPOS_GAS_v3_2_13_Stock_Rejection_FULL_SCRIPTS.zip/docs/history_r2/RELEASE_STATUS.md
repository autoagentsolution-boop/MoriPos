# Mori POS 3.0.4-r2 — Verified runtime transport

The observed error now occurs while the main JavaScript is being loaded. The initial HTML no longer embeds the 274,008-byte runtime. A small loader obtains static source through google.script.run, verifies SHA-256, decodes UTF-8 and inserts a script element. The source remains in the same Index.html, unchanged. One additional static-code RPC is required per visit; Base64 increases total transfer size.

36 local startup groups and the existing business suite pass. Actual Google deployment remains unverified. This is a transport change targeting the observed failure, not proof of its underlying platform/source cause. See README_TRANSPORT_FIX.md.

# Mori POS 3.0.4-r1 — Correct marker validation

The previous server code blocked delivery when optional source marker comments were absent or mismatched. The screenshot confirms this guard ran, but does not establish why a marker was absent. r1 reads unprocessed template content and treats marker/hash mismatches as diagnostic warnings. The frontend Index.html is byte-identical to the previous Boot Fix 3.0.4 release. Only Code.gs changes at runtime for this revision.

29 startup groups pass locally using the VM/DOM/RPC fixtures. Real Google deployment is still pending. See README_MARKER_FIX.md.

# Mori POS 3.0.4 — Startup patch

Sửa việc chờ auth trước khi hiện login, bổ sung loading/error/timeout, loại bỏ đọc dữ liệu demo khi khởi động live, dự phòng sessionStorage và kiểm tra SHA-256 của Index. Chỉ Code.gs và Index.html thay đổi trong mã chạy ứng dụng.

Local Node VM startup tests và business tests đã pass; chưa kiểm thử Google deployment thật. Chi tiết và giới hạn: `README_BLANK_PAGE_FIX.md`, `VERIFICATION.md`. Các mục chưa hoàn thiện của bản 3.0.1 bên dưới vẫn áp dụng.

# Mori POS 3.0.1 — Release status for QC

## Implemented in Apps Script source

- One-click setup for 7 Spreadsheet files + Drive folders; one master sheet for low-growth entities.
- Spreadsheet JSON payload and lightweight indexed columns; 45-second cache for master & product catalog; delta refresh from UI; 60-second foreground poll for Bill and Booking.
- Server-side staff allowlist, email OTP login with max 3 attempts, six-hour session token, server-side role/branch validation.
- CRUD store, branch, product, customer, employee; controls for Settings, Publish Site, receipt layout, bank info.
- Product image, store logo, Stock In evidence, attendance photo storage on Google Drive (separate folders).
- Create offline Bill, pay/lock, postpaid tip and employee attribution only, audit history, version conflicts.
- Stock In with unit conversion, weighted-average cost, branch-first stock, combo ingredients, priority on confirmed reservations; retry markers.
- Public website bootstrap and public order/booking creation with server-computed item prices; owner email notifications, client idempotency key.
- Online order state transitions, shipping stock deduction, delivery != payment, later confirm payment.
- Booking creation/status, conflict checks on assigned resource.
- Attendance email challenge, first IN / last OUT, minute-level OT, employee photo requirement.
- Configurable archive worker for closed Bills/StockIn/Booking/Attendance/Audit, verified copy-before-delete; manual run and optional daily trigger.

## Verified locally

- All `*.gs` files and the generated UI JavaScript passed Node V8 syntax checks.
- In-memory business logic tests passed: server price snapshot, no oversell, stock receipt idempotence, paid tip safety, CAS version, payment idempotence, shipping/payment split.
- **Not verified against actual Google Apps Script, Google Sheets, Drive, MailApp, camera, Chrome/iPhone/iPad or real thermal printer.** The browser integration automation was blocked by the execution environment; no PASS claim for end-to-end deployment.

## Explicitly incomplete / must test before production

- Some older UI secondary actions are still local-only in the connected screen; core workflows were adapted but whole-app UI QC is outstanding.
- Archive reads in historical financial report; shipping metadata lifecycle independent from bill archive.
- Customer account history across devices: deliberately not exposed by raw email/phone without verification.
- Live Google OAuth SSO; currently allowlisted Gmail OTP (email possession) rather than Google Identity Services sign-in.
- Automatic tax-compliant e-invoice, bank settlement webhook, third-party shipping status, live facial authentication.
- Multi-file transaction consistency is best-effort through idempotency/retry; Google Sheets does not supply an ACID transaction across files.
- Throughput/performance and data growth need measurement in merchant-specific Google account before real deployment.

## 3.0.1 corrective patch
- Fixed re-saving an open Bill without duplicating the row.
- Tightened server-side read projection for Employee and Manager: sensitive cost, salary and settings are not passed to unauthorized roles.
- Fixed order/booking idempotency token persistence, online discount display, store-level average cost.
- Added browser-side image compression for mobile camera uploads; synchronized image media audit under lock.
- `Installer.gs` provides a one-run editor setup function with no hard-coded email.
- Local Node regression tests extended; **actual deployed Google Apps Script concurrency and quota tests remain pending**.
