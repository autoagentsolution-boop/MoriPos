> Note: the current release is 3.0.4-r2. Use Code.gs from this ZIP. For the later Document.write error see README_TRANSPORT_FIX.md. The marker explanation below documents the earlier r1 correction.

# Sửa thông báo “Index.html chưa đủ nội dung hoặc không cùng phiên bản”

Thông báo trong ảnh được tạo bởi Code.gs 3.0.4 ở điều kiện kiểm tra hai marker:

- MORI_FRONTEND_BUILD:3.0.4
- MORI_FRONTEND_END:3.0.4

Ít nhất một marker không được tìm thấy trong nội dung mà code đọc được. Ảnh không chứng minh file thiếu nội dung, cũng không chứng minh Google đã loại bỏ comment. Điều kiện marker được đặt quá cứng trong bản vá trước và ngăn giao diện chạy.

Bản 3.0.4-r1:

- Bỏ việc throw/dừng trang chỉ vì thiếu hoặc khác marker.
- Đọc nguyên nội dung file bằng HtmlService.createTemplateFromFile('Index').getRawContent(), sau đó dựng HtmlOutput một lần.
- Giữ marker và SHA-256 trong hàm moriFrontendCheck để đối chiếu, không dùng làm điều kiện chặn.
- Nhận diện thẻ head/body của tài liệu, bỏ qua các chuỗi giống thẻ trong JavaScript/CSS/comment.
- Không thay đổi Index.html của Boot Fix 3.0.4 hoặc các file nghiệp vụ.

Cập nhật:

1. Nếu đang dùng Index từ bộ Boot Fix 3.0.4 đã gửi trước đó, chỉ thay toàn bộ nội dung Code.gs bằng Code.gs trong ZIP này hoặc file MoriPOS_Code_3_0_4_r1.gs được gửi kèm. Giữ tên file trong Apps Script là Code.gs; không thêm một file khác chứa doGet trùng.
2. Lưu rồi Deploy → Manage deployments → Edit → New version → Deploy. Không cần chạy lại setup hoặc tạo Sheets.
3. Mở lại /exec. Màn hình chặn marker cũ không còn là kết quả của code r1.
4. Nếu vẫn thấy thông báo cũ với “Build 3.0.4”, kiểm tra deployment đang dùng phiên bản đã sửa. moriFrontendCheck trong editor của bản sửa trả build:3.0.4-r1; editor và deployment có thể đang ở hai version khác nhau.
5. Nếu xuất hiện một lỗi khác, gửi đúng nội dung lỗi mới. Điều đó giúp tiếp tục kiểm tra thay vì kết luận mọi lỗi đều do marker.

Bộ ZIP đầy đủ đi kèm chứa Index 3.0.4 nguyên vẹn; chỉ cần thay cả hai file khi bản Index hiện tại không phải bản từ bộ Boot Fix đã gửi. Dùng bộ này như một cặp thống nhất, không ghép thêm MoriRuntime.

Kiểm thử: toàn bộ 29 nhóm startup mô phỏng và bộ test nghiệp vụ đã pass. Chưa xác nhận trên deployment Google thật của bạn. Bản sửa giải quyết bước chặn mà ảnh cho thấy, không phải bằng chứng toàn bộ POS đã chạy thành công.

Tài liệu API: https://developers.google.com/apps-script/reference/html/html-template#getRawContent()
