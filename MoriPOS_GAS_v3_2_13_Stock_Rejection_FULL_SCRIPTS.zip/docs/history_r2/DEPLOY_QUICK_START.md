# Mori POS v3.0.4-r2 — Deploy nhanh trên Google Apps Script

**Đang thấy `Document.write: Invalid or unexpected token`:** thay Code.gs bằng bản r2; giữ Index từ Boot Fix 3.0.4. Xem `README_TRANSPORT_FIX.md`.

**Đang thấy lỗi “Index.html chưa đủ nội dung hoặc không cùng phiên bản”:** chỉ thay `Code.gs` bằng bản r1 và deploy New version nếu đã dùng Index từ bản Boot Fix 3.0.4. Xem `README_MARKER_FIX.md`.

**Đã cài bản 3.0.1 và bị trắng trang:** chỉ thay `Code.gs` + `Index.html`, chạy `moriFrontendCheck`, rồi deploy **New version**. Xem `README_BLANK_PAGE_FIX.md`. Không cài lại Sheets.

**Đây là bản QC/staging, không dùng cho giao dịch thật trước khi kiểm thử.** Bản này tạo **7 Google Spreadsheet** và thư mục ảnh trên **Drive của tài khoản chạy cài đặt**.

1. Giải nén ZIP. Vào [script.google.com](https://script.google.com/) → **New project** → đặt tên `Mori POS QC`.
2. Thay nội dung `Code.gs` mặc định và tạo các file **Script** khác đúng tên: `Config.gs`, `Setup.gs`, `Installer.gs`, `Data.gs`, `Security.gs`, `Inventory.gs`, `Billing.gs`, `Operations.gs`, `ApiRead.gs`, `Media.gs`, `Archive.gs`. Dán nội dung tương ứng từ ZIP.
3. Tạo file **HTML** tên `Index`, dán `Index.html` (duy nhất). `Original_UI_Offline.html` và các file trong `tests/` **không phải file Apps Script cần upload**.
4. Vào **Project Settings** → bật hiện `appsscript.json`, dán manifest đi kèm. Xác nhận múi giờ `Asia/Ho_Chi_Minh`.
5. Chọn hàm **`moriInstallOnce`** ở thanh Run và chạy **bằng tài khoản chủ hệ thống**. Đồng ý các quyền do Google hiển thị. Hàm tự nhận email tài khoản chủ, không cần sửa code.
6. Chạy **`moriHealthCheck`**. Xem Execution log: `ready:true`, đủ bảy file `MASTER, ITEMS, STOCKIN, BILLS, BOOKING, ATTENDANCE, AUDIT`, không có warnings. Trong Drive xuất hiện `MoriPOS_Data`.
7. Chỉ ở bản QC mới, chạy **`moriSeedQC`** nếu cần 4 sản phẩm thử. Hàm không tạo Bill giả.
8. Chọn **Deploy → New deployment → Web app**. `Execute as = Me`; `Who has access` = theo phạm vi QC (khi cần web khách công khai mới dùng `Anyone`). Mở link `/exec` để đăng nhập Admin bằng **email OTP**.
9. Sau đăng nhập, tạo Bill thử, nhập kho có ảnh, cập nhật tip và kiểm tra dữ liệu lưu trong Sheets. Khi cho khách đặt trên Publish Site thì bật module liên quan và cấu hình trước tại Settings.
10. Mỗi lần thay code, vào **Manage deployments → Edit → New version** và deploy lại. Không phải cài mới bảy Sheets.

**Đường dẫn website khách:** `/exec?view=shop&tab=home` • danh mục `/exec?view=shop&tab=catalog` • booking `/exec?view=shop&tab=booking`.

**QC rất quan trọng:** tách môi trường QC khỏi dữ liệu thật; không bật archive tự động trước khi đối chiếu; Apps Script Web App chạy quyền chủ nên phải kiểm tra email OTP và role ở **API server**. Người dùng không được chia sẻ trực tiếp file Sheets. Xem `QC_CHECKLIST.md` (38 tình huống) và `RELEASE_STATUS.md`.

**Vấn đề đã biết:** Bộ mã chưa được chạy trên tài khoản Google thật trong phiên này; tính năng ít dùng trên UI chưa chắc đã được nối hoàn toàn; báo cáo lịch sử sau archive và shipping retention riêng cần hoàn thiện trước production. Login nhân viên hiện là **Gmail OTP**, chưa phải Google SSO.
