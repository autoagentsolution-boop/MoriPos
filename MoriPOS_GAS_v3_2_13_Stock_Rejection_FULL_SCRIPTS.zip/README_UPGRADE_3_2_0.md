# MoriPOS v3.2.0 — Staff Access, Verified Customer Identity & Customer Analytics

## 0. Phạm vi bản cập nhật

- **A · Staff Access:** Admin thêm/sửa/khoá tài khoản Manager/Employee tại Cài đặt → Nhân sự & quyền truy cập, cấp quyền nhiều chi nhánh và thu hồi quyền ngay cả khi phiên đăng nhập vẫn còn. Không cấp được ADMIN qua giao diện; Owner được bảo vệ.
- **B · Customer Identity:** Publish Site xác thực email khách qua OTP riêng biệt với Staff. Checkout vẫn có thể tiến hành không cần tài khoản; email trên đơn **chưa được coi là đã xác minh** cho đến khi khách OTP. Khách đã xác minh xem lịch sử đơn thuộc danh tính của mình. Nhân viên quầy có thể tạo Member mới; Admin/Manager có thể chỉnh hồ sơ Member và liên kết danh tính bằng OTP. Đơn online trước khi có xác thực phải có **mã theo dõi bí mật** và email đã xác minh mới được nhận về một tài khoản.
- **C · Customer Analytics:** CustomerDayIndex/CustomerOrderLinks được cập nhật tăng dần; CustomerDaily tổng hợp theo ngày/chi nhánh/Guest-Member. API phân quyền `moriCustomerAnalyticsQuery()`; trang Khách hàng hiển thị KPI 30 ngày cho Admin/Manager. Không đọc raw Bills khi mở dashboard; worker đồng bộ 5 phút/lần.

## 1. Workbook sau nâng cấp

| Google Spreadsheet | Tabs liên quan | Ghi chú |
|---|---|---|
| `POS_Master` | `AccessControl`, `Employees`, `Settings`, `Branches` | Nguồn phân quyền cho nhân sự, giữ nguyên |
| `POS_Customers` **mới** | `Customers`, `GuestIdentities`, `CustomerIdentityLinks`, `CustomerOrderLinks`, `CustomerDayIndex` | Customer master và customer identity; tự tạo khi install |
| `POS_Dashboard` | `AnalyticsLedger`, `AnalyticsDaily`, `CustomerDaily` **mới** | Tầng báo cáo đã tổng hợp |
| `POS_Bills` | `SalesBills` | Nguồn chứng từ, không thay đổi cấu trúc cột |

`Customers` cũ trong `POS_Master` được sao chép và **không xóa**. Chỉ khi toàn bộ dữ liệu sao chép được đối chiếu thì `MORI_CUSTOMERS_READY=1` và routing mới trỏ đến `POS_Customers`. Dữ liệu mới sau khi chuyển **không tự ghi ngược** về bản sao cũ.

## 2. Trình tự deploy production

1. Backup toàn bộ Apps Script project và các Google Sheets (đặc biệt `POS_Master`, `POS_Bills`, `POS_Dashboard`). Kiểm tra bạn đang có bản MoriPOS v3.1.7, nếu từ bản cũ hơn thì kiểm tra migration trước.
2. Copy **tất cả** file `.gs` và `Index.html` từ ZIP mới; giữ nguyên các **Script Properties** về ID workbook và Owner. Những file mới bắt buộc gồm `StaffAccess.gs`, `CustomerIdentity.gs`, `CustomerAnalytics.gs`, `MoriPreflight320.gs`.
3. Trong Apps Script Editor (đăng nhập bằng tài khoản Owner), chạy `moriPreflight320()`: `ok: true`, `version: 3.2.0`, và `frontend.exactFileMatch: true`. Chạy thêm `moriFrontendCheck()` nếu cần.
4. **Deploy → Manage deployments → Edit → New version → Deploy**. Không tạo project mới, không chạy lại `moriSetup()` trên production.
5. Nếu `POS_Dashboard` chưa có/Analytics cũ chưa được cài: chạy `moriAnalyticsInstall()` và đồng bộ Analytics v3.1.6 trước. Khi đã có `MORI_FILE_DASHBOARD`, chạy **`moriCustomerInstall()`** bằng Owner trong Editor. Hàm tạo riêng `POS_Customers`, thêm `CustomerDaily` vào `POS_Dashboard`, migrate Customers, tạo worker 5 phút.
6. Chạy **`moriCustomerSyncNow()`** để bắt đầu nạp Bills hiện còn hoạt động theo lô. Trigger sẽ tiếp tục tự chạy. Chạy `moriCustomerStatus()` đến khi có `installed: true`, `initialReady: true`, `backfillComplete: true`, `pending: 0`, `dirtyDays: 0`, `repairRequired: false`.
7. Kiểm tra Staff Access; đăng nhập thử một tài khoản Manager/Employee được cấp và một email chưa được cấp, sau đó thử vô hiệu hoá và gọi lại API. Thử Publish Site OTP và liên kết Member. Kiểm tra dashboard đối chiếu với đơn có gắn identity.

**Chú ý archive:** Bản v3.2.0 tạm chặn archive Bills ngay sau deploy cho đến khi `POS_Customers` được cài và đồng bộ xong, nhằm tránh mất dữ liệu nguồn trong lúc nạp.

## 3. Thao tác A — Staff

- Vào **Cài đặt → Nhân sự & quyền truy cập → Thêm nhân sự**.
- Nhập họ tên, email đăng nhập, vai trò Manager/Employee, một hay nhiều chi nhánh, đánh dấu Được phép đăng nhập. Chỉ Admin được thao tác.
- Đăng nhập bằng email OTP như trước. Backend đọc quyền từ `AccessControl` ở mỗi request, kể cả sau khi đã có phiên; vô hiệu hoá có hiệu lực ngay.
- Nhân viên không được tự tạo Admin. `Employees` là hồ sơ nhân sự; `AccessControl` mới là nguồn cấp quyền.

## 4. Thao tác B — Guest / Member

- **Khách online:** Publish Site → mua hàng, khai báo email; không bắt buộc đăng ký thành viên. Để có lịch sử riêng, khách gửi/nhập mã OTP email từ mục đăng nhập khách. Phiên Guest không được truy cập POS nội bộ.
- **Member tại quầy:** POS → Khách hàng → Đăng ký thành viên → nhập họ tên và điện thoại. Email chỉ được **liên kết chính thức khi khách xác thực OTP**. Nếu chưa chứng thực, lưu `pendingEmail` chứ không liên kết bằng cách đoán email.
- **Đơn online cũ chưa xác thực:** Khách cần email OTP và mã theo dõi đơn để nhận đơn vào Guest/Member. Chỉ trùng email **không đủ** để lấy lịch sử của người khác.
- **Phân quyền Member:** Nhân viên có thể tạo Member mới trong chi nhánh; Admin/Manager có thể cập nhật Member hiện có, nhưng vẫn phải có OTP trước khi liên kết email.
- Các đăng ký marketing cần sự đồng ý riêng, không suy ra từ email OTP.

## 5. Thao tác C — Customer Dashboard

- `CustomerDaily` chứa số đơn, doanh thu, lượng khách duy nhất theo **từng ngày**, khách mới/quay lại theo ngày, tách `GUEST`/`MEMBER`.
- Trong trang **Khách hàng**, Admin/Manager nhìn thấy KPI 30 ngày của chi nhánh đang chọn. Nhân viên chỉ thấy dữ liệu tác nghiệp phù hợp chi nhánh; không thấy tổng hợp tài chính.
- Dữ liệu báo cáo **chỉ gồm đơn gắn Guest xác thực hoặc Member**. Tổng này có thể nhỏ hơn toàn bộ doanh số POS do nhiều đơn khách lẻ không có identity. KPI mới sẽ có độ trễ theo worker, thường tối đa vài chu kỳ nếu có backlog.
- Số khách quay lại được cộng theo số lượt khách từng ngày; không tương đương số người duy nhất toàn kỳ.

## 6. Khắc phục và đối soát

- Nếu Customer Analytics báo chưa sẵn sàng: chạy `moriCustomerStatus()`, tiếp tục `moriCustomerSyncNow()` hoặc xem lỗi Trigger Executions.
- Nếu worker mất sự kiện, queue vượt giới hạn, hay kết quả lệch: Owner chạy **`moriCustomerRepairStart()`** một lần, sau đó `moriCustomerSyncNow()` theo lô cho tới khi `initialReady: true` và `repairRequired: false`. Công việc replay dùng upsert idempotent, không tạo bill mới.
- Nếu `moriCustomerInstall()` lỗi giữa chừng, kiểm tra workbook đích và chạy lại; không xóa `POS_Master/Customers`.
- Không đưa quyền truy cập trực tiếp Google Sheets `POS_Customers` cho nhân viên/quản lý hay khách hàng; họ chỉ truy cập qua API đã phân quyền.

## 7. Giới hạn cần lưu ý

- Tất cả kiểm thử là **Node VM/Sheets giả lập**, không phải E2E chạy trên Google Apps Script thật. Cần staging với tài khoản/email thử và các đơn test trước production.
- Worker Customer backfill hiện quét **Bills đang hoạt động**. Một số đơn đã chuyển vào archive từ trước khi nâng cấp sẽ **chưa được nạp tự động vào CustomerOrderLinks**; nếu cần lịch sử cũ, phải triển khai nhập archive riêng có đối soát.
- Với Guest checkout chưa OTP, đơn sẽ không vào CustomerDaily cho đến khi được khách nhận bằng OTP email + tracking token. Đây là nguyên tắc quyền riêng tư, không phải thất thoát doanh thu; doanh thu tổng tiếp tục theo `AnalyticsDaily` cũ.
- Apps Script/Google Sheets không phải hệ thống xác thực/CRM doanh nghiệp quy mô lớn; cần xem hạn mức MailApp, thời gian trigger, số dòng và đồng thời trước khi nâng quy mô.
- Rollback sau khi có khách/member mới: bản Master cũ không có bản ghi mới từ `POS_Customers`. **Sao lưu/đối soát dữ liệu mới trước khi rollback**; chỉ đổi source về v3.1.7 có thể làm ẩn các khách mới ở giao diện cũ.
