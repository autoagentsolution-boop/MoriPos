# MoriPOS v3.2.0 — Test report

Local Node VM / simulated Sheets and RPC, not live Google Apps Script.

PASS: Cache cannot bypass server-side role authorization
PASS: Catalog writes invalidate cached forecast across requests
PASS: A staff allowlist, 2 branches, ADMIN-only changes, no role escalation, live revocation
PASS: B customer email OTP and verified-only customer session, no staff-token escalation
PASS: C daily sales materialization, Guest-to-Member reclassification, no double counting, authorized dashboard
PASS: migration/repair state prevents incomplete dashboard publication and blocks unsafe archive during replay
COMPLETE: 14 suites, 122 reported groups passed. All tests are local simulations.
