# MoriPOS 3.2.10 — Sửa đơn vị, loại mặt hàng và lọc theo danh mục

## Cập nhật từ v3.2.9

Thay toàn bộ nội dung **3 file**: **Index.html**, **Code.gs**, **Operations.gs**.
`Operations.gs` bắt buộc phải được cập nhật để server cho phép lưu đơn vị mới.

1. Lưu bản sao project hiện tại.
2. Thay ba file trên trong Apps Script và lưu.
3. Chạy `moriFrontendCheck()`; kiểm tra build `3.2.10` và `exactFileMatch: true`.
4. **Deploy → Manage deployments → Edit → New version → Deploy**.
5. Tải lại trang Web App.

Không cần chạy lại Setup/Installer hoặc đổi cấu trúc Google Sheets.

## Các thay đổi

- **Chỉnh sửa mặt hàng:** mở chọn Đơn vị gốc bán/tồn; thêm trường Loại bên cạnh, với Sản phẩm, Dịch vụ, Combo và Nguyên liệu.
- Form mở lại hiển thị đúng loại và đơn vị đã lưu. Giữ nguyên các dòng định lượng khi chuyển giữa Sản phẩm, Dịch vụ và Combo hợp lệ.
- **Danh mục hiện tại:** thêm dropdown Danh mục dùng cùng Mori Style; có Tất cả danh mục và Chưa phân loại nếu có dữ liệu tương ứng.
- Danh mục và trạng thái bán lọc kết hợp, cập nhật số kết quả và đưa phân trang về trang 1. Lọc ngay trên dữ liệu đã tải, không gọi server.
- Giữ các sửa lỗi v3.2.9: dropdown tìm kiếm cho mọi dòng định lượng, một loading tại nút, giữ form đang nhập và lưu mặt hàng bằng một lượt API.

## Ý nghĩa của việc sửa đơn vị

Đây là **sửa thông tin đơn vị đã khai báo**, ví dụ sửa `cái` thành `phần` cho món bán theo phần.
Số lượng tồn, giá bán, giá vốn và các lượng đã nhập được giữ nguyên; không tự chuyển đổi toàn bộ số liệu khi đổi tên đơn vị. Form hiển thị nhắc kiểm tra các giá trị theo đơn vị mới trước khi lưu.

Ví dụ: sửa đơn vị của món Khổ qua cà ớt từ `cái` sang `phần` vẫn giữ giá bán 30.000đ và từng dòng nguyên liệu đã nhập. Đổi `kg` thành `g` theo cách sửa thông tin này **không** tự nhân tồn lên 1.000 lần hoặc chia giá xuống 1.000 lần.

Đối với tên đơn vị đếm tương đương 1:1, tên cũ được giữ như một quy đổi để các công thức đang tham chiếu tên cũ tiếp tục dùng được. Server báo rõ lỗi nếu chọn một đơn vị đóng gói đã có hệ số khác 1, hoặc nếu thay đơn vị làm công thức tham chiếu không còn quy đổi được.

Các quy tắc loại mặt hàng vẫn áp dụng: Combo cần thành phần; Nguyên liệu không có công thức thành phần. Không tự xóa công thức để đổi loại.

## Kiểm tra nhanh

1. Mở món có định lượng, đổi Đơn vị từ cái sang phần và Loại từ Sản phẩm sang Combo. Lưu, mở lại, kiểm tra hai trường và định lượng.
2. Thử chuyển món có thành phần sang Nguyên liệu: form cần báo lỗi và giữ dữ liệu để chỉnh lại.
3. Chọn Danh mục và kết hợp Đang bán/Ngừng bán; kiểm tra số kết quả và phân trang.

Chi tiết kiểm tra tự động: `TEST_REPORT_3_2_10.md`.
